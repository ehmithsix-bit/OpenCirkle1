# OpenCirkle v53 — Member Categories, Avatar Layering & Faster Startup

## Changes
- Added an optional category selector to the normal member text-post composer. It is available to every signed-in member, not only virtual community profiles.
- Categories are saved on the Firestore post document as `communityCategory` and rendered as a post label.
- Category choices include News & Updates, Sports, Technology, Entertainment, Education, Business & Career, Lifestyle, Food, Travel, Health & Fitness, Books & Ideas, Photography, Questions, Opinion, Personal Update, Community Discussion and Other.
- Isolated the collaborative avatar stack in its own stacking context so uploader/collaborator avatars cannot float over the sticky app header or mobile navigation/footer. Uploader remains the foremost/first avatar, collaborators follow behind it.
- Cached the global service-mode settings locally and render the app shell while the live Firestore snapshot refreshes in the background, reducing cold-start blocking after the first successful load.
- Reduced the splash-only delay from 1.6 seconds to 450 milliseconds.
- Changed each post card's accepted-collaborator profile resolution from multiple permanent realtime listeners to one-time reads. The post author profile remains live-subscribed; collaborator details refresh when the post card is mounted/reloaded. This lowers persistent Firestore listener/read pressure in long feeds.

## Important
- The category field is optional for backward compatibility; old posts without a category continue to display normally.
- App responsiveness still depends on device speed, network quality, Firestore region/rules/indexes and feed size. No source change can guarantee fast loading on a poor connection.
- Build/lint/runtime validation must be run in an environment with dependencies installed.
