# OpenCirkle v71 — Feed Spinner, Retry Backend Check, Post Options Layout

- Kept post-options trigger from shrinking in the post header; reserved a fixed 40px touch target and spacing so it stays visible beside long author names.
- Replaced the “Load more posts / Loading more posts…” footer button and text with a compact animated spinner while infinite scroll fetches more posts. Existing IntersectionObserver auto-loading remains in place.
- Made the offline “Try again” action verify a real Firestore server request (`posts`, limited to one document) rather than relying only on `navigator.onLine`. It reloads only after the backend responds and stays on the offline screen if the probe fails.
- Kept previous functionality and virtual/dummy community users intact.

Validation: source edits inspected and ZIP integrity checked. No dependency install, production build, or device test was available in this workspace. Firestore connectivity check assumes the app's existing security rules permit reading the public posts collection; if not, use an explicitly readable health/config document instead.
