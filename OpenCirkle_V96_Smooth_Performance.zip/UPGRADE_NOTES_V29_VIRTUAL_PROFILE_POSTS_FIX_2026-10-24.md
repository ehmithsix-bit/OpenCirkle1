# OpenCirkle v29 — Virtual Community Profile Posts Fix

## Fixed
- Virtual community usernames generated in the Home feed (for example `rahim.hasan`) now resolve to a local profile instead of failing the old underscore/suffix matcher.
- Virtual community profile pages now show six deterministic, source-linked community posts instead of an empty Discourses tab.
- Virtual profile posts use the same author username, display name, and avatar identity as the profile page.
- The virtual Saved/Vault tab remains empty because virtual profiles do not have Firebase bookmarks.
- No virtual user accounts or posts are written into Firebase; these are locally generated demonstration/community profiles.

## Validation
- ZIP archive integrity checked after packaging.
- Android APK build and full TypeScript/Vite build were not run in this environment; validate with `npm install` then `npm run build` before release.
