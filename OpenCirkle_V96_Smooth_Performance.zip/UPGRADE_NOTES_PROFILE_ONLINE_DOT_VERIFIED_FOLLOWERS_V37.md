# OpenCirkle v37 — Profile Online Dot + Verified Follower List

## Changes
- Ensured the profile active/online indicator is stacked above Google profile photos and custom logo/avatar images. The dot is positioned over the lower-right edge of the avatar and has a stronger green glow while online.
- Replaced the generic Lucide check icon in Followers/Following lists with the app's shared `VerifiedBadge` component, so verified accounts show the same current badge artwork and respect admin badge customization settings.
- Preserved existing user data, profile photos, follow-list behavior, and navigation.

## Validation
- Source files updated and ZIP archive integrity checked. A full app build was not run in this environment.
