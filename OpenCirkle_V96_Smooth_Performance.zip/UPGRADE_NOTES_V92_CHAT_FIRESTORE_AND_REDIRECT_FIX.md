# OpenCirkle V92 – Direct Message Fix

## Fixed
- Prevented Firestore `setDoc()` failures caused by `participantData.<uid>.avatarUrl` being `undefined`. Optional avatar URLs are now omitted unless they are non-empty strings.
- Added safe participant display-name and avatar fallbacks when creating a direct conversation.
- Made the profile Message action reliably switch to the Messages section and open the selected recipient's conversation.
- Clear the previous chat while a new recipient's conversation is being resolved, and ignore stale async results when recipients change.
- Remount ChatView when the selected recipient changes so an old conversation cannot remain selected.

## Scope
- No Firestore collection names, document IDs, message schema, Firebase authentication, or visual theme changes.
- Existing conversation documents remain readable; new documents no longer write undefined avatarUrl fields.

## Verification
- Source-level patch and ZIP packaging completed.
- Production build, automated tests, live Firestore tests, and Android APK build were not run in this environment. Run `npm ci`, `npm run lint`, `npm test`, and `npm run build`; then test two real accounts on Android/web.
