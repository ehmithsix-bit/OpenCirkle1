# OpenCirkle v63 — Restore virtual community users

- Restored the locally generated virtual community posts in Home and Trending feeds.
- Retained the existing 20,000 locally generated community profile directory and varied text-post generator.
- Virtual users/posts remain local demo content; they are not Firebase Auth accounts and are not written to Firestore.
- Following feed remains based on actual followed users.
- Kept current post card/counter implementation from v62.

Validation: source-level restoration only. Full dependency install, TypeScript/Vite build, and device tests have not been run.
