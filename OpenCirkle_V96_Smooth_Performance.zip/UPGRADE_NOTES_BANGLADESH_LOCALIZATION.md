# Bangladesh-focused update (English UI)

This update keeps OpenCirkle's UI in English and adds Bangladesh-specific regional behavior:
- English (Bangladesh) metadata and site theme metadata.
- User-facing dates/times in Asia/Dhaka time zone for feed, comments, notifications, chat, verification review, profile join date and mobile status clock.
- Regional Preferences card in Settings (English, BDT ৳, Dhaka UTC+6, bKash/Nagad).
- Bangladesh mobile number validation for monetization applications and cash-out requests (`01XXXXXXXXX` or `+8801XXXXXXXXX`).
- Existing Firebase configuration, Firestore collections, auth flow, app UI theme and features retained.

## Payment limitation
This is localization and payout-method support, not a payment gateway integration. Existing admin-configured bKash/Nagad details and manual review flow remain. Do not present transfers as automatic; real automatic payouts require an approved provider API and secure server-side integration.

## Deploy
Upload the updated project ZIP to your existing Netlify deployment flow, preserving the same Firebase project. Set `VITE_FIREBASE_VAPID_KEY` if using push notifications, then rebuild. Firebase Functions and Firestore rules from the push-notification upgrade still need their own deployment if not already deployed.
