# OpenCirkle Community Username & Feed Refresh Fix v4

## Changes
- Replaced adjective+noun handles such as `bright river` with natural `first.last` handles.
- De-duplicated the given-name and surname pools before generating profiles.
- The first 20,000 generated virtual profiles have unique handles without numeric serial suffixes; uniqueness was checked by a local script (20,000 generated / 20,000 unique).
- Increased the variety of Quran/surah/recitation/translation reading prompts, hadith source-check prompts, and news source-reading prompts. Each item links to a source page; these are not represented as live-scraped news or verified hadith quotations.
- Refresh now advances to a new virtual community batch, clears the previous Firestore pagination cursor, and reloads the feed.

## Important limitations
- These are client-side virtual community profiles, not 20,000 Firebase Auth accounts or persisted Firestore user documents.
- Content is varied source-linked educational prompts, not a live Quran/hadith/news ingestion pipeline. Verify hadith references and translations at the linked source before treating them as quotations.
- This source ZIP was not built or tested on an Android device in this environment. `node_modules` is absent, so TypeScript/Vite/Gradle build status remains unverified.
