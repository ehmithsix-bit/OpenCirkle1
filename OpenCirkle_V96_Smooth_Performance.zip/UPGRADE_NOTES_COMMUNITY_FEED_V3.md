# OpenCirkle Community Feed Upgrade v3 — 2026-10-24

## Changes
- Virtual community handles now use readable adjective+noun combinations after a familiar name (e.g. `rahim_hasan_brightriver`) rather than numeric suffixes.
- ProfileView recognizes the new virtual handle format and opens a normal-looking virtual profile without creating Firebase Auth users.
- Home/Trending community posts now rotate through separate Quran/Surah/recitation-and-meaning, hadith-reference, and news-source prompts with varied copy, references, and tags.
- Feed refresh resets pagination state and rotates the local community batch while re-fetching Firestore posts.
- Infinite scroll continues to append additional virtual community batches.

## Explicit limitations
- The 20,000 profiles are still local virtual identities, not 20,000 Firebase Auth accounts or Firestore user documents.
- Religious posts link to source pages and provide reading prompts; they do not claim to fetch live source content or reproduce verified Quran/hadith text automatically.
- News entries are source links/prompts, not a live news API integration.
- Build/test status is unverified because dependencies were not installed in this environment. Run `npm install`, `npm run lint`, `npm run build`, then `npx cap sync android` before opening/building in Android Studio.
