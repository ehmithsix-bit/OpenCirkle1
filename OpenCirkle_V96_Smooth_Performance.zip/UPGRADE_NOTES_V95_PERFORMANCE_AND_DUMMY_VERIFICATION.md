# OpenCirkle V95 — responsiveness and dummy verified-account ratio

## Changes
- Removed unnecessary React state updates from the one-second service-schedule clock while the app is in normal mode. The clock still evaluates schedule transitions every second, but the main application tree no longer rerenders each second for an invisible countdown.
- Kept the live countdown updates while the app is actually in a scheduled maintenance/closed state.
- Changed the 20,000 locally generated dummy community profiles from 60 verified accounts per 1,000 to exactly 5 per 1,000 (100 verified profiles total). Selection is deterministic and evenly distributed through the generated profile list.
- Added a regression test asserting exactly 100 verified dummy profiles out of 20,000.

## Scope
- Real user verification remains based on the existing Firestore `verified: true` value and is not changed by the dummy-profile ratio.
- No Firebase Auth accounts are created for virtual community profiles.

## Verification
- Source-level changes and ZIP packaging completed.
- Automated test/build/type-check and Android device profiling were not run because this archive has no installed dependencies/lockfile in the working environment. Run `npm install`, `npm test`, `npm run lint`, and `npm run build`, then profile on a target Android device.
