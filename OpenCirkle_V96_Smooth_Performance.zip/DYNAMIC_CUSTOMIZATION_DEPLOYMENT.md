# Dynamic App Customization Studio — deployment notes

## Included
- `ADMIN_CONTROL_CENTER_UPGRADED.html`: adds App Design Studio with branding, splash, typography, color/theme, header/footer, navigation JSON editor, representative mobile preview, local draft save/reset, and confirmed Firebase publishing.
- `src/App.tsx`: reads the published `platformSettings/global.appCustomization`, applies validated CSS variables, caches the last valid configuration in localStorage, and synchronizes updates.
- `src/components/common/Header.tsx`: reads cached/live branding for header logo and app name.
- `src/index.css`: centralized customization variables and supported visibility hooks.
- `firestore.rules`: restricts customization-only writes to Admin/Super Admin and keeps other platform setting writes on the existing moderator/admin policy.

## Firestore schema
`platformSettings/global.appCustomization` uses `schemaVersion: 1`, nested `branding`, `splash`, `typography`, `colors`, `header`, `footer`, `navigation`, `layout`, plus `status`, `publishedAt`, `updatedAt`, and `updatedBy`. Admin publishes only that nested field via `updateDoc`; unrelated platform settings are not replaced.

## Deployment
1. Review the rules diff against your currently deployed production rules before deploying; merge rather than blindly replacing any newer rules.
2. Deploy the React app using the existing build command and hosting pipeline.
3. Host `ADMIN_CONTROL_CENTER_UPGRADED.html` on HTTPS (not `file://`) with the same Firebase project configuration and existing admin profile roles.
4. Test with a real authorized admin and a non-admin account. Firebase rules are authoritative; client-side checks are UX only.
5. Confirm the current project rules support `platformSettings/global` reads. If the document does not yet exist, initialize it with existing platform settings before publishing (the editor uses `updateDoc` to preserve unrelated fields).

## Current scope / honest limitations
- The editor offers a representative mobile preview and a navigation JSON editor; the current app runtime applies theme variables, typography, splash branding, header branding, and supported visibility flags. It does not dynamically rebuild React route architecture or guarantee arbitrary custom navigation items will route without corresponding app code. Only existing routes should be used until route mapping is implemented.
- The preview is representative, not a pixel-perfect browser render of every component.
- Cached startup customization is best-effort; browser storage may be cleared or unavailable. Invalid/unpublished settings fall back to the existing design.
- No Firebase Storage or arbitrary script execution was added.
