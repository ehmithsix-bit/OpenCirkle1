# OpenCirkle v48 — Edit Post Collaborator Management

## Changes
- Added a Manage Collaborators section to the existing Edit Post modal, available from the post menu on the profile/feed post card.
- The edit modal uses the same username-prefix autocomplete and user selection flow as the post composer.
- Existing collaborators are shown with their invitation status; the post author can add new collaborators or remove existing ones before saving.
- New collaborators receive a collaboration invitation notification and start with `pending` status. Existing accepted/pending states are preserved when they remain selected.
- Removed collaborators are removed from the post's `collaborators` and `collaboratorIds`; their response record and any still-pending collaboration invite notification are also cleared.
- Admin collaboration enablement and maximum collaborator settings are enforced for newly added collaborators. Existing posts remain editable when collaboration is disabled or when an administrator later lowers the limit.

## Notes
- Only the post author can manage the collaborator list.
- Invitees still need to accept an invitation before they are represented as accepted collaborators.
- Full production build and live Firebase rules/integration tests require the project's dependencies and a configured Firebase environment.
