# OpenCirkle v47 — Post publishing and collaboration picker fixes

## Fixes
- Fixed Firestore `setDoc()` failures when a user has no profile photo. Optional `authorAvatarUrl` and notification `senderAvatarUrl` fields are now omitted unless they contain a valid non-empty string.
- Applied the same optional-avatar protection to comments and notifications so missing profile photos do not break post/comment publishing or related notifications.
- Added username-prefix search for post collaboration. As the author types the first letters of a username, the composer searches active users and displays matching accounts with avatar, display name, and username.
- Collaborators must be selected from the suggestions. Selected accounts appear as removable chips and only their verified usernames are passed to the post creation service.
- Existing server-side validation remains in place: self-invites, suspended/banned users, admin-disabled collaboration, and admin-configured collaborator limits are checked before publishing.

## Deployment
- Deploy the updated app build/source from this package.
- No Firestore rules change is required for username suggestions; the current `users` read rule allows the prefix lookup.
- Run the project build and test suite in the deployment environment after installing dependencies and configuring the Firebase environment.
