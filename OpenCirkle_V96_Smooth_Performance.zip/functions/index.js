const { onDocumentCreated, onDocumentUpdated } = require('firebase-functions/v2/firestore');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const { getMessaging } = require('firebase-admin/messaging');

initializeApp();
const db = getFirestore();
const messaging = getMessaging();
const DAY = 24 * 60 * 60 * 1000;

function toMillis(value) {
  if (typeof value === 'number') return value > 0 && value < 1e12 ? value * 1000 : value;
  if (value && typeof value.toMillis === 'function') return value.toMillis();
  if (value && typeof value.seconds === 'number') return value.seconds * 1000;
  return 0;
}
function userName(user) { return user?.displayName || user?.username || 'OpenCirkle user'; }
function enabled(user, pref) {
  const prefs = user?.pushPreferences || {};
  return user && user.pushNotificationsEnabled !== false && user.notificationsEnabled !== false && prefs[pref] !== false;
}
async function isBlocked(a, b) {
  if (!a || !b) return true;
  const [aSnap, bSnap] = await Promise.all([db.collection('users').doc(a).get(), db.collection('users').doc(b).get()]);
  return (Array.isArray(aSnap.data()?.blockedUsers) && aSnap.data().blockedUsers.includes(b)) ||
    (Array.isArray(bSnap.data()?.blockedUsers) && bSnap.data().blockedUsers.includes(a));
}
async function isEligibleRecipient(recipientId, actorId, pref, { requireFollow = false, story = false } = {}) {
  if (!recipientId || recipientId === actorId || await isBlocked(recipientId, actorId)) return false;
  const [recipientSnap, actorSnap] = await Promise.all([
    db.collection('users').doc(recipientId).get(), db.collection('users').doc(actorId).get()
  ]);
  if (!recipientSnap.exists || !actorSnap.exists) return false;
  const recipient = recipientSnap.data() || {}, actor = actorSnap.data() || {};
  if (!enabled(recipient, pref)) return false;
  if (actor.isPrivate === true && requireFollow) {
    const follow = await db.collection('follows').doc(`${recipientId}_${actorId}`).get();
    if (!follow.exists) return false;
  }
  if (requireFollow) {
    const follow = await db.collection('follows').doc(`${recipientId}_${actorId}`).get();
    if (!follow.exists) return false;
  }
  if (story && story.privacy === 'followers' && requireFollow) {
    const follow = await db.collection('follows').doc(`${recipientId}_${actorId}`).get();
    if (!follow.exists) return false;
  }
  return true;
}
async function followersOf(authorId, pref, options = {}) {
  const snap = await db.collection('follows').where('followingId', '==', authorId).limit(500).get();
  const ids = [...new Set(snap.docs.map(d => d.data().followerId).filter(Boolean))];
  const eligible = await Promise.all(ids.map(async uid => await isEligibleRecipient(uid, authorId, pref, { ...options, requireFollow: true }) ? uid : null));
  return eligible.filter(Boolean);
}
async function removeInvalidTokens(tokens) {
  const invalidCodes = new Set(['messaging/registration-token-not-registered', 'messaging/invalid-registration-token']);
  const invalid = new Set(tokens.filter(x => x && x.code && invalidCodes.has(x.code)).map(x => x.token));
  if (!invalid.size) return;
  const chunks = [...invalid];
  for (let i = 0; i < chunks.length; i += 10) {
    const snap = await db.collection('pushTokens').where('token', 'in', chunks.slice(i, i + 10)).get();
    await Promise.all(snap.docs.map(d => d.ref.delete()));
  }
}
async function deliverToRecipient(recipientId, { actorId, pref, eventId, type, title, body, url, targetPostId = '', storyId = '', messageId = '' }) {
  if (!(await isEligibleRecipient(recipientId, actorId, pref))) return;
  const userSnap = await db.collection('users').doc(recipientId).get();
  const user = userSnap.data() || {};
  // Stable event+recipient ID makes Firestore notification records idempotent across trigger retries.
  const notificationId = `${String(type).replace(/[^a-zA-Z0-9_-]/g, '_')}_${String(eventId).replace(/[^a-zA-Z0-9_-]/g, '_')}_${recipientId}`.slice(0, 1400);
  const notifRef = db.collection('notifications').doc(notificationId);
  const actorSnap = await db.collection('users').doc(actorId).get();
  const actorProfile = actorSnap.data() || {};
  const notif = {
    id: notificationId, recipientId, senderId: actorId,
    senderUsername: actorProfile.username || 'user',
    senderDisplayName: userName(actorProfile),
    senderAvatarSymbol: actorProfile.avatarSymbol || 'gem', senderAvatarColor: actorProfile.avatarColor || 'electric',
    ...(actorProfile.avatarUrl ? { senderAvatarUrl: actorProfile.avatarUrl } : {}), type,
    targetPostId: targetPostId || '', storyId: storyId || '', messageId: messageId || '',
    textSnippet: String(body || '').slice(0, 100), read: false, createdAt: Date.now(),
    createdAtServer: FieldValue.serverTimestamp(), eventId: String(eventId),
  };
  const deliveryId = `${String(type).replace(/[^a-zA-Z0-9_-]/g, '_')}_${String(eventId).replace(/[^a-zA-Z0-9_-]/g, '_')}_${recipientId}`.slice(0, 1400);
  const deliveryRef = db.collection('notificationDeliveries').doc(deliveryId);
  const firstDelivery = await db.runTransaction(async tx => {
    const existing = await tx.get(deliveryRef);
    if (existing.exists && existing.data()?.status === 'sent') return false;
    tx.set(deliveryRef, { recipientId, actorId, type, eventId: String(eventId), status: 'sending', updatedAt: Date.now(), createdAtServer: FieldValue.serverTimestamp() }, { merge: true });
    return true;
  });
  if (!firstDelivery) return;
  // Existing client-side interaction handlers may already have written a notification.
  // Reuse that record instead of showing a duplicate, while still sending this event's push.
  const recentSnap = await db.collection('notifications').where('recipientId', '==', recipientId).limit(50).get();
  const duplicateRecent = recentSnap.docs.some(d => {
    const data = d.data();
    return data.senderId === actorId && data.type === type && Date.now() - (Number(data.createdAt) || 0) < 2 * 60 * 1000 &&
      (targetPostId ? data.targetPostId === targetPostId : true);
  });
  if (!duplicateRecent) {
    await db.runTransaction(async tx => {
      const existing = await tx.get(notifRef);
      if (!existing.exists) tx.create(notifRef, notif);
    });
  }
  if (user.pushNotificationsEnabled === false || user.notificationsEnabled === false) { await deliveryRef.set({ status: 'sent', completedAt: Date.now() }, { merge: true }); return; }
  const tokenSnap = await db.collection('pushTokens').where('uid', '==', recipientId).get();
  const tokenDocs = tokenSnap.docs.filter(d => typeof d.data().token === 'string' && d.data().token.length > 10);
  if (!tokenDocs.length) { await deliveryRef.set({ status: 'sent', completedAt: Date.now(), noTokens: true }, { merge: true }); return; }
  // FCM sendEach accepts at most 500 messages. Keep each token/device independent.
  for (let i = 0; i < tokenDocs.length; i += 500) {
    const docs = tokenDocs.slice(i, i + 500);
    const messages = docs.map(d => ({
      token: d.data().token,
      notification: { title: String(title).slice(0, 100), body: String(body || '').slice(0, 220) },
      data: { type: String(type), eventId: String(eventId), url: String(url || '/#/'), targetPostId: String(targetPostId || ''), storyId: String(storyId || ''), messageId: String(messageId || ''), notificationId },
      android: { priority: 'high', notification: { channelId: 'opencirkle_updates', tag: notificationId.slice(0, 100), clickAction: 'FCM_PLUGIN_ACTIVITY' } },
    }));
    try {
      const response = await messaging.sendEach(messages);
      const invalid = [];
      const transientFailures = [];
      response.responses.forEach((r, idx) => { if (!r.success) { const failure = { token: docs[idx].data().token, code: r.error?.code }; invalid.push(failure); if (!['messaging/registration-token-not-registered', 'messaging/invalid-registration-token'].includes(failure.code)) transientFailures.push(failure); } });
      await removeInvalidTokens(invalid);
      if (transientFailures.length) throw new Error(`FCM rejected ${transientFailures.length} message(s); first=${transientFailures[0].code || 'unknown'}`);
    } catch (err) { await deliveryRef.set({ status: 'failed', lastError: String(err.message || err).slice(0, 300), failedAt: Date.now() }, { merge: true }); console.error('FCM batch send failed', { recipientId, type, message: err.message }); throw err; }
  }
  await deliveryRef.set({ status: 'sent', completedAt: Date.now() }, { merge: true });
}
async function notifyRecipients(ids, payload) {
  // Bound concurrency to reduce Firestore/FCM bursts for large accounts.
  for (let i = 0; i < ids.length; i += 20) {
    const results = await Promise.all(ids.slice(i, i + 20).map(async uid => { try { await deliverToRecipient(uid, payload); return null; } catch (err) { console.error('Notification recipient failed', uid, payload.type, err.message); return uid; } }));
    const failed = results.filter(Boolean);
    if (failed.length) throw new Error(`Notification delivery failed for ${failed.length} recipient(s)`);
  }
}

exports.notifyNewPost = onDocumentCreated({ document: 'posts/{postId}', retry: true }, async event => {
  const post = event.data?.data();
  if (!post?.authorId || post.isScheduled === true || post.scheduledAt && toMillis(post.scheduledAt) > Date.now() || post.privacy === 'private') return;
  const recipients = await followersOf(post.authorId, 'posts');
  const authorSnap = await db.collection('users').doc(post.authorId).get();
  const author = userName(authorSnap.data() || post);
  await notifyRecipients(recipients, { actorId: post.authorId, pref: 'posts', eventId: event.params.postId, type: 'post', title: `${author} নতুন পোস্ট করেছে`, body: String(post.content || 'নতুন পোস্ট দেখুন').slice(0, 120), url: `/#post-${event.params.postId}`, targetPostId: event.params.postId });
});

exports.notifyNewStory = onDocumentCreated({ document: 'stories/{storyId}', retry: true }, async event => {
  const story = event.data?.data();
  if (!story?.authorId) return;
  const created = toMillis(story.createdAt) || (event.time ? Date.parse(event.time) : Date.now());
  const expires = toMillis(story.expiresAt) || created + DAY;
  if (expires <= Date.now() || Date.now() - created > DAY || story.privacy === 'private') return;
  const recipients = await followersOf(story.authorId, 'stories', { story: true });
  const authorSnap = await db.collection('users').doc(story.authorId).get();
  const author = userName(authorSnap.data() || story);
  await notifyRecipients(recipients, { actorId: story.authorId, pref: 'stories', eventId: event.params.storyId, type: 'story', title: `${author} নতুন Story দিয়েছে`, body: String(story.thought || 'নতুন Story দেখুন').slice(0, 120), url: `/#story-${event.params.storyId}`, storyId: event.params.storyId });
});

exports.notifyNewDirectMessage = onDocumentCreated({ document: 'conversations/{conversationId}/messages/{messageId}', retry: true }, async event => {
  const message = event.data?.data();
  if (!message?.senderId) return;
  const conv = await db.collection('conversations').doc(event.params.conversationId).get();
  const participants = conv.data()?.participantIds || [];
  const recipients = participants.filter(uid => uid && uid !== message.senderId);
  const senderSnap = await db.collection('users').doc(message.senderId).get();
  const sender = userName(senderSnap.data());
  for (const uid of recipients) {
    const muted = conv.data()?.mutedBy?.[uid] === true || (Array.isArray(conv.data()?.mutedBy) && conv.data().mutedBy.includes(uid));
    if (muted) continue;
    await deliverToRecipient(uid, { actorId: message.senderId, pref: 'messages', eventId: event.params.messageId, type: 'message', title: `${sender} আপনাকে মেসেজ পাঠিয়েছে`, body: String(message.text || message.content || 'আপনার নতুন মেসেজ এসেছে').slice(0, 120), url: `/#messages`, messageId: event.params.messageId });
  }
});

exports.notifyOnlineFollowers = onDocumentUpdated({ document: 'users/{userId}', retry: true }, async event => {
  const before = event.data?.before.data(), after = event.data?.after.data();
  if (!before || !after || before.isOnline === true || after.isOnline !== true || after.onlineVisibility === false || after.showOnlineStatus === false) return;
  // Cooldown prevents notification spam when app reconnects repeatedly.
  const cooldownRef = db.collection('onlineNotificationCooldowns').doc(event.params.userId);
  const now = Date.now();
  const allowed = await db.runTransaction(async tx => {
    const snap = await tx.get(cooldownRef);
    if (snap.exists && now - (Number(snap.data().lastSentAt) || 0) < 30 * 60 * 1000) return false;
    tx.set(cooldownRef, { lastSentAt: now, updatedAt: FieldValue.serverTimestamp() });
    return true;
  });
  if (!allowed) return;
  const recipients = await followersOf(event.params.userId, 'online');
  const author = userName(after);
  await notifyRecipients(recipients, { actorId: event.params.userId, pref: 'online', eventId: `online-${event.params.userId}-${Math.floor(now / (30 * 60 * 1000))}`, type: 'online', title: `${author} এখন অনলাইনে`, body: 'আপনার বন্ধু OpenCirkle-এ অনলাইন হয়েছে।', url: '/#home' });
});

exports.notifyNewFollow = onDocumentCreated({ document: 'follows/{followId}', retry: true }, async event => {
  const follow = event.data?.data();
  if (!follow?.followerId || !follow?.followingId || follow.followerId === follow.followingId) return;
  const actorSnap = await db.collection('users').doc(follow.followerId).get();
  const actor = userName(actorSnap.data());
  await deliverToRecipient(follow.followingId, { actorId: follow.followerId, pref: 'follows', eventId: event.params.followId, type: 'follow', title: `${actor} আপনাকে ফলো করেছে`, body: 'আপনার নতুন follower হয়েছে।', url: `/#user-${actorSnap.data()?.username || ''}` });
});

exports.notifyNewLike = onDocumentCreated({ document: 'likes/{likeId}', retry: true }, async event => {
  const like = event.data?.data();
  if (!like?.userId || !like?.postId) return;
  const postSnap = await db.collection('posts').doc(like.postId).get();
  const post = postSnap.data();
  if (!post?.authorId || post.authorId === like.userId) return;
  const actorSnap = await db.collection('users').doc(like.userId).get();
  const actor = userName(actorSnap.data());
  await deliverToRecipient(post.authorId, { actorId: like.userId, pref: 'likes', eventId: event.params.likeId, type: 'like', title: `${actor} আপনার পোস্টে Like দিয়েছে`, body: String(post.content || '').slice(0, 100), url: `/#/post/${like.postId}`, targetPostId: like.postId });
});

exports.notifyNewComment = onDocumentCreated({ document: 'comments/{commentId}', retry: true }, async event => {
  const comment = event.data?.data();
  if (!comment?.authorId || !comment?.postId) return;
  const postSnap = await db.collection('posts').doc(comment.postId).get();
  const post = postSnap.data();
  if (!post?.authorId) return;
  const actorSnap = await db.collection('users').doc(comment.authorId).get();
  const actor = userName(actorSnap.data());
  const isReply = Boolean(comment.parentCommentId || comment.replyToCommentId);
  const targetUid = isReply ? (comment.parentAuthorId || comment.replyToUserId) : post.authorId;
  if (!targetUid || targetUid === comment.authorId) return;
  await deliverToRecipient(targetUid, { actorId: comment.authorId, pref: 'comments', eventId: event.params.commentId, type: isReply ? 'reply' : 'comment', title: isReply ? `${actor} আপনার comment-এর reply দিয়েছে` : `${actor} আপনার পোস্টে comment করেছে`, body: String(comment.content || '').slice(0, 100), url: `/#/post/${comment.postId}`, targetPostId: comment.postId });
});

// Maintenance-screen email subscriptions and authoritative retry checks.
const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { onSchedule } = require('firebase-functions/v2/scheduler');
const crypto = require('node:crypto');

function resolveServiceState(settings, now = Date.now()) {
  const message = typeof settings.serviceModeMessage === 'string' && settings.serviceModeMessage.trim()
    ? settings.serviceModeMessage.trim()
    : 'We are improving OpenCirkle. Please try again shortly.';
  if (settings.dailyScheduleEnabled === true && /^([01]\d|2[0-3]):[0-5]\d$/.test(settings.dailyCloseTime || '') && /^([01]\d|2[0-3]):[0-5]\d$/.test(settings.dailyOpenTime || '') && settings.dailyCloseTime !== settings.dailyOpenTime) {
    const timezone = typeof settings.dailyTimezone === 'string' && settings.dailyTimezone ? settings.dailyTimezone : 'UTC';
    let localClock = '00:00:00';
    try { localClock = new Intl.DateTimeFormat('en-GB', { timeZone: timezone, hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }).format(new Date(now)); }
    catch { localClock = new Intl.DateTimeFormat('en-GB', { timeZone: 'UTC', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }).format(new Date(now)); }
    const [hour, minute, second] = localClock.split(':').map(Number);
    const currentMinute = hour * 60 + minute;
    const [closeHour, closeMinutePart] = settings.dailyCloseTime.split(':').map(Number);
    const [openHour, openMinutePart] = settings.dailyOpenTime.split(':').map(Number);
    const closeMinute = closeHour * 60 + closeMinutePart;
    const openMinute = openHour * 60 + openMinutePart;
    const isClosed = closeMinute < openMinute
      ? currentMinute >= closeMinute && currentMinute < openMinute
      : currentMinute >= closeMinute || currentMinute < openMinute;
    if (isClosed) {
      const minutesUntilOpen = (openMinute - currentMinute + 1440) % 1440;
      return { mode: settings.scheduledServiceMode === 'closed' ? 'closed' : 'maintenance', targetAt: now + minutesUntilOpen * 60000 - second * 1000, message };
    }
    return { mode: 'normal', targetAt: 0, message };
  }
  if (settings.scheduledServiceEnabled === true) {
    const closeAt = Number(settings.serviceCloseAt) || 0;
    const mode = settings.scheduledServiceMode === 'closed' ? 'closed' : 'maintenance';
    const targetAt = mode === 'closed'
      ? (Number(settings.appClosedReopenAt) || Number(settings.serviceOpenAt) || 0)
      : (Number(settings.maintenanceEndAt) || Number(settings.serviceOpenAt) || 0);
    if (closeAt > 0 && targetAt > closeAt && now >= closeAt && now < targetAt) {
      return { mode, targetAt, message };
    }
    return { mode: 'normal', targetAt: 0, message };
  }
  const manualMode = settings.serviceMode || (settings.maintenanceMode === true ? 'maintenance' : 'normal');
  if (manualMode === 'maintenance' || manualMode === 'closed') {
    const targetAt = manualMode === 'closed'
      ? (Number(settings.appClosedReopenAt) || Number(settings.serviceOpenAt) || 0)
      : (Number(settings.maintenanceEndAt) || Number(settings.serviceOpenAt) || 0);
    if (targetAt > 0 && now >= targetAt) return { mode: 'normal', targetAt: 0, message };
    return { mode: manualMode, targetAt, message };
  }
  return { mode: ['server_error', 'not_found', 'try_again'].includes(manualMode) ? manualMode : 'normal', targetAt: 0, message };
}

exports.subscribeMaintenanceNotifications = onCall(async request => {
  const email = String(request.data?.email || '').trim().toLowerCase();
  if (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw new HttpsError('invalid-argument', 'Enter a valid email address.');
  }
  const emailHash = crypto.createHash('sha256').update(email).digest('hex');
  const ref = db.collection('serviceNotificationSubscribers').doc(emailHash);
  const existing = await ref.get();
  if (existing.exists && ['pending', 'queued'].includes(existing.data()?.status)) {
    return { success: true, alreadySubscribed: true };
  }
  await ref.set({
    email,
    status: 'pending',
    notifyWhen: 'service_restored',
    createdAt: existing.exists ? (existing.data()?.createdAt || new Date()) : new Date(),
    updatedAt: new Date(),
    source: 'maintenance_screen'
  }, { merge: true });
  return { success: true, alreadySubscribed: false };
});

exports.checkServiceAvailability = onCall(async () => {
  const snap = await db.collection('platformSettings').doc('global').get();
  const state = resolveServiceState(snap.exists ? snap.data() : {});
  return { ...state, serverNow: Date.now() };
});

// Poll the admin-controlled schedule. When the app transitions from locked to
// available, queue one email per subscriber in the Firebase Trigger Email `mail` collection.
exports.notifyMaintenanceRestored = onSchedule('every 1 minutes', async () => {
  const settingsSnap = await db.collection('platformSettings').doc('global').get();
  const current = resolveServiceState(settingsSnap.exists ? settingsSnap.data() : {});
  const locked = current.mode === 'maintenance' || current.mode === 'closed';
  const stateRef = db.collection('platformSettings').doc('serviceNotificationState');
  const stateSnap = await stateRef.get();
  const wasLocked = stateSnap.exists ? stateSnap.data()?.locked === true : locked;
  if (!wasLocked || locked) {
    await stateRef.set({ locked, mode: current.mode, checkedAt: new Date() }, { merge: true });
    return;
  }

  const subscribers = await db.collection('serviceNotificationSubscribers').where('status', '==', 'pending').get();
  if (subscribers.empty) {
    await stateRef.set({ locked: false, mode: current.mode, checkedAt: new Date() }, { merge: true });
    return;
  }
  const now = new Date();
  for (let offset = 0; offset < subscribers.docs.length; offset += 400) {
    const batch = db.batch();
    for (const subscriber of subscribers.docs.slice(offset, offset + 400)) {
      const email = subscriber.data().email;
      if (!email) continue;
      const mailRef = db.collection('mail').doc(`service-restored-${subscriber.id}`);
      batch.set(mailRef, {
        to: [email],
        message: {
          subject: 'OpenCirkle is back online',
          text: 'Good news! OpenCirkle maintenance is complete and the app is available again. Open OpenCirkle to continue.',
          html: '<p>Good news! <strong>OpenCirkle is back online.</strong></p><p>Maintenance is complete. You can open the app and continue.</p>'
        },
        createdAt: now
      }, { merge: true });
      batch.update(subscriber.ref, { status: 'queued', notifiedAt: now });
    }
    await batch.commit();
  }
  await stateRef.set({ locked: false, mode: current.mode, checkedAt: new Date() }, { merge: true });
});
