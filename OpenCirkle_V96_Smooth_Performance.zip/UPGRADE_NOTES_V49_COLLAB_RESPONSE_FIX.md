# OpenCirkle v49 — Collaboration Accept/Reject Fix

- Hardened collaboration response writes so optional profile/avatar fields never send `undefined` to Firestore.
- Accept/reject response is saved as the primary action; author notification delivery is handled as a secondary best-effort operation.
- Added visible success/error feedback and busy-state protection to notification Accept/Reject controls.
- Marking the invitation notification as read no longer makes a successfully saved response appear to have failed.
- Fixed a React hook-order issue in NotificationsView during authentication hydration, which could prevent notification controls from rendering reliably.
- Updated Firestore rules so a post author can delete a former invitee's response record only after removing that user from the post's collaborator list; this supports clean re-invitations.
- Deploy the updated Firestore rules together with the rebuilt app for the full fix to take effect.

Validation: source-level TypeScript/TSX transpilation and ZIP integrity checks. A full production build and live Firebase rules/integration test require project dependencies and a configured Firebase environment.
