# V80 — 8 Ball Pool Theme and Post Options Safe Area

- Replaced the burgundy Light Mode appearance with a billiards-inspired 8 Ball Pool palette: green felt surfaces, dark table-rail backgrounds, ivory text and subtle gold accents.
- Updated the profile appearance toggle labels to name the 8 Ball Pool theme.
- Constrained post three-dot menus to the safe area below the app header and above the fixed bottom navigation dock; the menu flips above its trigger when there is insufficient room below.
- Reduced menu height to the available viewport area so it does not cover the bottom profile/navigation dock.
