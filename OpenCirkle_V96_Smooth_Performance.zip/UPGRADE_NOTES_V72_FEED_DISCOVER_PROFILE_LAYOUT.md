# OpenCirkle v72 — Feed, Discover and Profile Layout Fix

- Feed pagination now appends the next local virtual-community batch immediately rather than waiting for Firestore first, while remote posts load in parallel afterward.
- Added a synchronous ref lock to prevent duplicate overlapping infinite-scroll requests and increased the observer prefetch margin.
- Discover renders suggested users as soon as the main results are ready; follow-state lookups run in the background and are capped to the first four suggestions to avoid blocking the whole section.
- Search effects now rerun when the active Discover tab changes.
- Post header now gives the author section a shrinkable, min-width-safe layout and protects the options button from being pushed/cropped on narrow profile screens.

Validation: ZIP integrity checked. App build/device test not run because dependencies are not installed in this workspace.
