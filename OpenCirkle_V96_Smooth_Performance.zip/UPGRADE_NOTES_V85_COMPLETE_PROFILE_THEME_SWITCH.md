# V85 — Complete Profile Theme Toggle Fix

- The Profile > More profile settings > 8 Ball Pool Theme switch is the single control for the appearance.
- ON sets `data-oc-theme="moonlight"` on the document and applies the supplied Moonlight Manor wallpaper plus a coordinated dark teal/green skin to app surfaces, text, inputs, menus, buttons and navigation.
- OFF sets the existing `crystal_dark` preference; no Moonlight selector matches, so the original Crystal Crypt blue/purple appearance is restored without replacing its original styles.
- Existing localStorage and Firestore preference persistence is retained.
- The previous light-surface Moonlight CSS overrides are superseded by a final, explicit dark green Moonlight skin layer.
- Post composer/navigation safe-area behavior remains unchanged.
