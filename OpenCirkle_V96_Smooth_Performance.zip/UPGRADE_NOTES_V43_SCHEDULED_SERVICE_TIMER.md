# OpenCirkle v43 — Scheduled Service Close/Open Timer

## Added
- Admin Control Center > Platform Parameters now has a Scheduled App Server / Service Timer section.
- Standalone `ADMIN_CONTROL_CENTER_UPGRADED.html` has matching scheduled availability fields.
- Admin can enable/disable the schedule and set close and reopen date/time.
- Settings are stored in `platformSettings/global` as `scheduledServiceEnabled`, `serviceCloseAt`, and `serviceOpenAt` (epoch milliseconds).
- Reopen time must be later than close time; the admin form validates this before saving.
- The main app listens to Firestore and evaluates the schedule every second.
- Before close time, the app remains open; between close and reopen time, non-admin users see the maintenance screen; at/after reopen time, the app opens automatically.
- Admin/Super Admin accounts continue to bypass the app lock.
- Maintenance screen displays a live reopen countdown; admin UI displays a live countdown to close or reopen.
- If the schedule is disabled, the existing manual service mode continues to work.

## Important limitation
This feature schedules the app's client-side global maintenance/lock screen. It does not shut down Netlify hosting, Firebase, Cloud Functions, or directly block every backend/API request. Actual server-side enforcement requires trusted backend controls and compatible Firestore/Storage Rules. The app's displayed timer uses the device clock, so device clock changes can affect the client-side display.

## Verification
- TypeScript/TSX syntax transpilation checks passed for the changed app, admin, types, and service files.
- Standalone admin HTML module JavaScript syntax check passed.
- Full Vite/TypeScript build was not run because dependency installation timed out in the environment.
