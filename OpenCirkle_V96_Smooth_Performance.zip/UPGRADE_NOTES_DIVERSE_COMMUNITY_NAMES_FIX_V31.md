# OpenCirkle — Diverse Community Names Fix v31

- Fixed community-name ordering: first names are interleaved rather than grouping the entire first batch under Rahim.
- Expanded first-name variety and added international name options; the 20,000 profile names use distinct first/last combinations.
- Usernames use varied formats (dot, underscore, joined, its, writes, bd, x, the, reverse, daily) and collision-safe uniqueness.
- ProfileView now accepts every handle style when its virtual profile exists, including joined/its-style handles.
- Preserved the 20,000 virtual profile size and exactly 60 verified profiles per 1,000 (1,200 total).
- These are virtual community/demo profiles, not real Firebase accounts.
