# OpenCirkle Android package & Firebase signing certificate

## Android package identity

The Android package/application ID is:

`com.opencirkle.app`

This is already aligned in:
- `android/app/build.gradle` (`namespace` and `defaultConfig.applicationId`)
- `capacitor.config.json` (`appId`)
- `android/app/google-services.json` (`client_info.android_client_info.package_name`)

Do not change one of these independently; all must remain exactly `com.opencirkle.app`.

## Requested signing certificate fingerprints

SHA-1:

`2A:E8:15:B4:6A:5E:70:14:C5:FA:DD:C2:75:F7:F7:A8:54:05:5C:4C`

SHA-256:

`B9:D4:CB:AB:8F:DF:34:BA:45:3A:55:8E:C2:2B:A8:18:B8:60:23:AC:D5:91:30:D8:FF:5D:1F:36:FC:DE:2E:02`

These are the fingerprints supplied for the intended Android signing certificate. Fingerprints are derived from the actual signing certificate/private keystore; they cannot be made true by writing the strings into Gradle or the APK. Confirm that the release keystore used to sign the APK produces these exact values.

## Firebase Console action required

1. Open Firebase Console → project `echo-bb04c` → Project settings → Your apps → Android app `com.opencirkle.app`.
2. Add the SHA-1 and SHA-256 fingerprints above under SHA certificate fingerprints.
3. Download the refreshed `google-services.json` for this Android app and replace `android/app/google-services.json` in this project.
4. Rebuild and sign the APK/AAB with the matching release keystore.
5. If Google Sign-In is used, verify the OAuth Android client in Google Cloud/Firebase is generated for this package and signing SHA-1.

The current checked-in `google-services.json` already has package name `com.opencirkle.app`, but its Android OAuth client's existing `certificate_hash` is `a959613839eaf554db8425245c890c1a26a0e0da`, which differs from the supplied SHA-1. Therefore this file should be refreshed from Firebase Console after adding the new fingerprint; do not manually edit the generated JSON's OAuth client/hash fields.

## Verify the release keystore

Run this against the actual release keystore (replace the path and alias with your own values):

```bash
keytool -list -v -keystore /path/to/release-keystore.jks -alias YOUR_KEY_ALIAS
```

Compare the displayed SHA1 and SHA256 values exactly with the fingerprints above. Keep the keystore and passwords private; never commit them to the source ZIP or public repository.
