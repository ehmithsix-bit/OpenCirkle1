# OpenCirkle Mobile Profile / Menu Fix

- Reduced profile card padding on narrow viewports and added `min-w-0`/horizontal clipping to prevent the profile section from pushing beyond the screen.
- Profile metadata and follower counters wrap on narrow screens.
- Profile action row can wrap rather than forcing buttons off-screen.
- On mobile, the three-dot menu opens as a bottom sheet with a dim backdrop, close control, safe-area padding, scrollable content, and larger tap targets. On larger screens it remains an anchored dropdown.
- Update-link unavailable/invalid messages now close the menu first so the message is not hidden behind the menu overlay.
- Added global mobile viewport overflow safeguards.

Note: Production build should be run with project dependencies installed before deploying.
