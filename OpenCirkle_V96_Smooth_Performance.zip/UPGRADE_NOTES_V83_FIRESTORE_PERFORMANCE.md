# OpenCirkle v83 – Firestore Loading Performance Improvements

## Changes
- Added a 20-second in-memory cache and in-flight request deduplication for the signed-in user's Following IDs. Follow/unfollow and accepted follow requests invalidate the cache immediately.
- Replaced sequential profile document reads in Followers/Following lists with parallel, chunked Firestore `documentId() in [...]` queries (30 IDs per request), preserving follow-list order.
- Removed the optional random Home-feed request that fetched the signed-in user's profile posts after the main feed query. This was an unnecessary extra Firestore read path and delayed completion of Home loading.
- Added short-lived in-memory caches and in-flight deduplication for per-post like/bookmark state; successful like/bookmark changes update the cache immediately.
- Changed saved-post loading from sequential per-post reads to concurrent reads.
- Skipped the collaboration-response query for ordinary posts that have no collaborator IDs or collaborator records.
- Reused the existing latest-profile cache for collaborator profile lookups instead of issuing a separate `users where uid == ...` query for each collaborator.
- Started Explore's first user-page read and Following-ID read concurrently.
- Kept Firestore persistent local cache enabled in `src/lib/firebase.ts`; no database documents or user accounts were deleted.

## Validation
- TypeScript transpile syntax check: 62 `.ts`/`.tsx` files processed, 0 syntax errors.
- Full `tsc --noEmit` and production Vite build could not be run in this environment because dependencies are not installed (`vite/client` types unavailable). Run `npm install`, `npm run lint`, and `npm run build` before Android packaging.
- Live Firestore latency and production behavior still need testing against the deployed Firebase project and real devices.
