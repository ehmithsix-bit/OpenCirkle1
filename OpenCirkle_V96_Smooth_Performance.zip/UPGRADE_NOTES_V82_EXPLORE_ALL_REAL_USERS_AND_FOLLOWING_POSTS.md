# OpenCirkle v82 – Explore people directory and following posts

## What was causing the 8-user limit?
The Explore screen called `fetchSuggestedUsers()`. That helper queried Firestore with `limit(8)`, and its fallback also used `.slice(0, 8)`. Therefore Explore could never show more than eight people even when more real user profiles existed.

## Changes
- Added `fetchExploreUsers()` with Firestore document-ID pagination (50 user documents per page).
- Explore now displays up to 50 valid active profiles initially and provides **Load more users** to continue through the complete users collection.
- The directory filters out records with blank UID, username, or display name; excludes the signed-in user; and excludes banned/suspended accounts. Legacy profiles without a status field are treated as active.
- The query no longer depends on `followersCount` being present, so older/real profiles without that field are not silently skipped.
- Follow state is derived from the already-fetched following IDs, avoiding two extra Firestore reads per visible user.
- Explore Posts now loads recent public posts from followed accounts even when the search field is empty. Firestore `in` query groups are split into batches of 30 IDs, then deduplicated and sorted by newest first.
- When searching posts or hashtags, results remain restricted to accounts the signed-in user follows, consistent with the requested Explore behavior.
- Fixed the Explore imports to include the functions actually used.

## Validation
- TypeScript/TSX transpilation syntax checks passed for the two changed source files.
- A full Vite/TypeScript build was not run because this extracted project has no `node_modules` directory in the environment. Please install dependencies and run `npm run lint` and `npm run build` before release.
