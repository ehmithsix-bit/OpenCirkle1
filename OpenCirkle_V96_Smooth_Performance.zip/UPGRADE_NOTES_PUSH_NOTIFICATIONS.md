# OpenCirkle Push Notifications Upgrade

## Included
- Settings > Push Notifications panel with browser permission prompt and separate preferences for direct messages, posts, stories and online alerts.
- Firebase Cloud Messaging token registration in Firestore `pushTokens` collection.
- Root-scope `public/firebase-messaging-sw.js` for background notifications and notification-click navigation.
- Firebase Functions triggers for newly created public posts, stories and direct messages, plus a conditional online-presence trigger.
- Firestore rules allowing users to manage only their own push token records.
- `functions/package.json`, `firebase.json`, and `.env.example` for deployment setup.

## Required setup before push can work
1. Firebase Console > Project settings > Cloud Messaging: generate/get the Web Push certificate public VAPID key.
2. Set `VITE_FIREBASE_VAPID_KEY` to that key in Netlify Site configuration > Environment variables, and locally in `.env` when building.
3. Install Firebase CLI, sign in to the correct project (`echo-bb04c`), and deploy Firestore rules and Functions. From project root: `firebase deploy --only firestore:rules,functions`.
4. Functions need a billing-enabled Firebase project/Blaze plan in many regions and a supported runtime; check current Firebase requirements before deployment.
5. Rebuild and redeploy the web app to Netlify over HTTPS. Users must visit the site in a supported browser and press Allow.

## Important limitations
- Push notifications are not guaranteed on every browser/device. iOS web push requires the site to be installed as a Home Screen web app and supported iOS/iPadOS version; browser notification permission must be granted.
- `online` notification trigger only fires if the app actually updates `users/{uid}.isOnline`. Current app code did not contain an online presence heartbeat, so Online Alerts require a separate presence implementation before they can work reliably.
- New post/story notifications go to followers; direct messages go to the other conversation participants. Respect users' push preferences.
- App-side notification records and push delivery are separate: notification UI may still work even if browser push setup is incomplete.


## Android permission popup fix (2026-10-25)
The updated app requests native Android notification permission once after sign-in. Rebuild and reinstall the APK to receive this change. Web browsers still require the user to press Settings > Push Notifications > Allow. If Android permission was previously denied, enable it in Android Settings > Apps > OpenCirkle > Notifications.
