# OpenCirkle update notes — 2026-10-23

## Implemented in this upgrade
- Configurable verified badge image URL (HTTPS), pixel size, spacing beside the display name, and vertical offset through App Design Studio.
- Photo + text story composer. Photos are resized/compressed to a small inline JPEG data URL because Firebase Storage remains intentionally unused. Story UI hides stories after 24 hours based on expiresAt/createdAt.
- Announcement card appearance reads appCustomization.announcementCard settings.
- Post composer shows uploader-local processing state and plays a short success chime where browser audio is permitted.
- Author-only Boost Post action with target audience slider, estimated price, bKash/Nagad/SSLCommerz artwork, transaction ID, pending order, and in-app confirmation notification.
- Admin Boost Ad Orders queue supports review, approve/reject, user notification, and audit logging.
- Firestore rules restrict boost-order submission to the authenticated owner and review to moderator/admin roles.

## Important limitations
- The app intentionally does NOT create 1,100+ fake people, fake engagement counts, or autonomous fake accounts that imitate real Bangladeshi users. Those would mislead users. If seeded sample profiles are needed for testing, use clearly labelled demo accounts in a separate staging environment.
- No fake human chatbot was added. A future assistant should be explicitly labelled as an automated OpenCirkle bot and follow transparent, limited conversation rules.
- Story photos are stored inline in Firestore documents, not Firebase Storage. This is a constrained fallback and may increase Firestore reads/writes; deploy and test with your rules before production. UI expiry is 24 hours, but physical deletion requires a trusted scheduled Cloud Function or Firestore TTL policy configured on the expiresAt field.
- Boost payments are manual instructions and transaction-ID collection, not an actual SSLCommerz/bKash/Nagad payment API. Admin must verify the transaction independently before approving. Estimated reach is not guaranteed.
- Run a production build, deploy Firestore rules, and test the full flow in Firebase staging before release. This archive has not been successfully built or end-to-end tested in this environment.
