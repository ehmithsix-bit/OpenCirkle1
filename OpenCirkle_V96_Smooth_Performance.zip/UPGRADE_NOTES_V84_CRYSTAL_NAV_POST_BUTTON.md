# V84 — Crystal Navigation Post Button

- Added the supplied raised, cyan Crystal-style **Post** button to the center of the mobile bottom navigation.
- Connected the button to the app's existing `PostComposer` modal flow; signed-out users are prompted to sign in first.
- Preserved existing Home, Explore, Messages, Profile navigation, unread-message badge, immersive return behavior, and the existing post publishing flow.
- Updated the five-button opening animation layout.
