import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, initializeFirestore, persistentLocalCache, persistentMultipleTabManager } from 'firebase/firestore';

// OpenCirkle Firebase Configuration
// NOTE: Firebase Storage is STRICTLY PROHIBITED in OpenCirkle.
// Only Authentication and Cloud Firestore are initialized.
const firebaseConfig = {
  apiKey: "AIzaSyBqcAKT35gt8b5QwcY8hoL6kT_ndBJsDCE",
  authDomain: "echo-bb04c.firebaseapp.com",
  projectId: "echo-bb04c",
  storageBucket: "echo-bb04c.firebasestorage.app",
  messagingSenderId: "45625028258",
  appId: "1:45625028258:web:2cd2502e408ea6f94b71fb"
};

// Initialize Firebase App singleton
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

export const auth = getAuth(app);
// Shared persistent cache keeps the same Firestore data model available offline and
// reconciles cached documents with server snapshots after connectivity returns.
export const db = (() => {
  try { return initializeFirestore(app, { localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }) }); }
  catch { return getFirestore(app); }
})();

export default app;
