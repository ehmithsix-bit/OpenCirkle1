import {
  collection,
  doc,
  setDoc,
  getDoc,
  updateDoc,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  deleteField,
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Conversation, DirectMessage, UserProfile } from '../types';
import { sanitizeTextOnlyContent } from './postService';

export const getOrCreateConversation = async (
  currentUser: UserProfile,
  otherUser: UserProfile
): Promise<Conversation> => {
  // Deterministic ID for 1-to-1 conversations
  const sortedIds = [currentUser.uid, otherUser.uid].sort();
  const convId = `${sortedIds[0]}_${sortedIds[1]}`;

  const convRef = doc(db, 'conversations', convId);
  const snap = await getDoc(convRef);

  if (snap.exists()) {
    return snap.data() as Conversation;
  }

  // Firestore rejects `undefined` anywhere in a document. Some older or
  // partially completed profiles do not have an avatarUrl, so only persist
  // optional profile fields when they contain a real string.
  const toConversationParticipant = (profile: UserProfile): Conversation['participantData'][string] => ({
    username: profile.username || 'unknown',
    displayName: profile.displayName || profile.username || 'OpenCirkle member',
    avatarSymbol: profile.avatarSymbol || 'gem',
    avatarColor: profile.avatarColor || 'electric',
    verified: profile.verified === true,
    ...(typeof profile.avatarUrl === 'string' && profile.avatarUrl.trim()
      ? { avatarUrl: profile.avatarUrl.trim() }
      : {}),
  });

  const newConversation: Conversation = {
    id: convId,
    participantIds: [currentUser.uid, otherUser.uid],
    participantData: {
      [currentUser.uid]: toConversationParticipant(currentUser),
      [otherUser.uid]: toConversationParticipant(otherUser),
    },
    lastMessageText: '',
    lastMessageTimestamp: Date.now(),
    lastSenderId: '',
    unreadCount: {
      [currentUser.uid]: 0,
      [otherUser.uid]: 0,
    },
    updatedAt: Date.now(),
  };

  await setDoc(convRef, newConversation);
  return newConversation;
};

export const subscribeToConversations = (
  uid: string,
  onUpdate: (conversations: Conversation[]) => void
) => {
  // Query conversations by participantIds array-contains without compound orderBy,
  // preventing any composite index requirement or index error.
  const q = query(
    collection(db, 'conversations'),
    where('participantIds', 'array-contains', uid),
    limit(50)
  );

  return onSnapshot(
    q,
    (snapshot) => {
      const list = snapshot.docs
        .map((d) => ({ ...(d.data() as Conversation), id: d.id }))
        .sort((a, b) => {
          const timeA = typeof a.updatedAt === 'number' ? a.updatedAt : (a.lastMessageTimestamp || 0);
          const timeB = typeof b.updatedAt === 'number' ? b.updatedAt : (b.lastMessageTimestamp || 0);
          return timeB - timeA;
        });
      onUpdate(list);
    },
    (err) => {
      console.warn('Conversations subscription status:', err);
    }
  );
};

export const subscribeToMessages = (
  conversationId: string,
  onUpdate: (messages: DirectMessage[]) => void
) => {
  const messagesCol = collection(db, 'conversations', conversationId, 'messages');
  try {
    const q = query(messagesCol, orderBy('createdAt', 'asc'), limit(100));

    return onSnapshot(
      q,
      (snapshot) => {
        const list = snapshot.docs.map((d) => d.data() as DirectMessage);
        onUpdate(list);
      },
      (err) => {
        console.warn('Direct message subscription falling back:', err);
        // Resilient fallback query without ordering
        const fallbackQ = query(messagesCol, limit(100));
        return onSnapshot(fallbackQ, (fallbackSnap) => {
          const list = fallbackSnap.docs
            .map((d) => d.data() as DirectMessage)
            .sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
          onUpdate(list);
        });
      }
    );
  } catch (err) {
    console.warn('Error setting up message subscription:', err);
    return () => {};
  }
};

export const sendTextMessage = async (
  conversationId: string,
  sender: UserProfile,
  recipientId: string,
  rawText: string
): Promise<DirectMessage> => {
  // Strictly enforce text-only messaging
  const text = sanitizeTextOnlyContent(rawText);
  if (text.length > 2000) {
    throw new Error('Message length exceeds 2000 characters limit.');
  }

  const messagesCol = collection(db, 'conversations', conversationId, 'messages');
  const msgRef = doc(messagesCol);
  const now = Date.now();

  const msgData: DirectMessage = {
    id: msgRef.id,
    conversationId,
    senderId: sender.uid,
    senderUsername: sender.username,
    text,
    createdAt: now,
    read: false,
    readBy: [],
  };

  await setDoc(msgRef, msgData);

  // Update conversation summary
  const convRef = doc(db, 'conversations', conversationId);
  const convSnap = await getDoc(convRef);
  const existingUnread = convSnap.exists() ? (convSnap.data().unreadCount?.[recipientId] || 0) : 0;

  await updateDoc(convRef, {
    lastMessageText: text.slice(0, 80),
    lastMessageTimestamp: now,
    lastSenderId: sender.uid,
    updatedAt: now,
    [`unreadCount.${recipientId}`]: existingUnread + 1,
  });

  return msgData;
};

export const markConversationRead = async (
  conversationId: string,
  currentUserUid: string
): Promise<void> => {
  const convRef = doc(db, 'conversations', conversationId);
  await updateDoc(convRef, {
    [`unreadCount.${currentUserUid}`]: 0,
  });
};


/** Realtime typing indicator stored on the private conversation document. */
export const setTypingStatus = async (
  conversationId: string,
  uid: string,
  username: string,
  isTyping: boolean
): Promise<void> => {
  const convRef = doc(db, 'conversations', conversationId);
  await updateDoc(convRef, {
    [`typing.${uid}`]: isTyping ? { username, updatedAt: Date.now() } : deleteField(),
  });
};

export const subscribeToTyping = (
  conversationId: string,
  onUpdate: (typing: Record<string, { username: string; updatedAt: number }>) => void
) => onSnapshot(doc(db, 'conversations', conversationId), (snapshot) => {
  const data = snapshot.data();
  const now = Date.now();
  const typing = (data?.typing || {}) as Record<string, { username: string; updatedAt: number }>;
  // Ignore stale indicators if a browser closes unexpectedly.
  onUpdate(Object.fromEntries(Object.entries(typing).filter(([, v]) => v && now - (v.updatedAt || 0) < 5000)));
});

/** Mark messages from the other participant as seen by the current user. */
export const markMessagesSeen = async (
  conversationId: string,
  currentUserUid: string,
  messages: DirectMessage[]
): Promise<void> => {
  const pending = messages.filter((m) => m.senderId !== currentUserUid && !(m.readBy || []).includes(currentUserUid));
  await Promise.all(pending.map((m) => updateDoc(doc(db, 'conversations', conversationId, 'messages', m.id), {
    read: true,
    readBy: [...(m.readBy || []), currentUserUid],
  })));
};
