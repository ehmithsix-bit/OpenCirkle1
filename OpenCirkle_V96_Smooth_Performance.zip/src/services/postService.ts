import {
  collection,
  doc,
  getDoc,
  getDocs,
  getCountFromServer,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  startAfter,
  increment,
  runTransaction,
  DocumentSnapshot,
} from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { Post, UserProfile } from '../types';
import { createNotification } from './notificationService';

export const MAX_POST_LENGTH = 5000;

const interactionStatusCache = new Map<string, { value: boolean; expiresAt: number }>();
const interactionStatusPending = new Map<string, Promise<boolean>>();
const INTERACTION_CACHE_MS = 20_000;
const invalidateInteractionStatus = (kind: 'like' | 'bookmark', uid: string, postId: string) => {
  const key = `${kind}:${uid}:${postId}`;
  interactionStatusCache.delete(key);
  interactionStatusPending.delete(key);
};

/** Count at most one view per browser session for each post. */
export const recordPostView = async (postId: string): Promise<boolean> => {
  if (!postId || typeof window === 'undefined') return false;
  const key = `oc_post_view_${postId}`;
  try {
    if (window.sessionStorage.getItem(key)) return false;
    window.sessionStorage.setItem(key, '1');
    await updateDoc(doc(db, 'posts', postId), { viewsCount: increment(1) });
    return true;
  } catch (err) {
    try { window.sessionStorage.removeItem(key); } catch {}
    console.warn('Could not record post view. Check Firestore rules.', err);
    return false;
  }
};

export const parseTagsAndMentions = (text: string) => {
  if (!text || typeof text !== 'string') {
    return { tags: [], mentions: [] };
  }

  const hashtagRegex = /#([a-zA-Z0-9_]+)/g;
  const mentionRegex = /@([a-zA-Z0-9_]+)/g;
  
  const tags: string[] = [];
  const mentions: string[] = [];

  let match;
  while ((match = hashtagRegex.exec(text)) !== null) {
    const tag = match[1].toLowerCase();
    if (!tags.includes(tag)) tags.push(tag);
  }

  while ((match = mentionRegex.exec(text)) !== null) {
    const user = match[1].toLowerCase();
    if (!mentions.includes(user)) mentions.push(user);
  }

  return { tags, mentions };
};

export const sanitizeTextOnlyContent = (raw: string): string => {
  if (!raw || typeof raw !== 'string') {
    throw new Error('Post content cannot be empty.');
  }

  const trimmed = raw.trim();
  if (trimmed.length === 0) {
    throw new Error('Post content cannot be empty.');
  }
  if (trimmed.length > MAX_POST_LENGTH) {
    throw new Error(`Post exceeds the limit of ${MAX_POST_LENGTH} characters.`);
  }

  // Reject any embedded HTML tags or media syntax to strictly enforce text-only rules
  const htmlTagRegex = /<[^>]*>/g;
  const sanitized = trimmed.replace(htmlTagRegex, '');

  if (sanitized.length === 0) {
    throw new Error('Post content must be valid plain text.');
  }

  return sanitized;
};

export const mapPostDoc = (d: DocumentSnapshot): Post => {
  const data = d.data() || {};
  return {
    id: d.id,
    authorId: data.authorId || '',
    authorUsername: data.authorUsername || 'thinker',
    authorDisplayName: data.authorDisplayName || 'Crystalline Node',
    authorVerified: Boolean(data.authorVerified),
    authorAvatarSymbol: data.avatarSymbol || data.authorAvatarSymbol || 'gem',
    authorAvatarColor: data.avatarColor || data.authorAvatarColor || 'electric',
    ...(typeof data.authorAvatarUrl === 'string' && data.authorAvatarUrl.trim() ? { authorAvatarUrl: data.authorAvatarUrl } : {}),
    privacy: data.privacy === 'private' ? 'private' : 'public',
    scheduledAt: typeof data.scheduledAt === 'number' ? data.scheduledAt : null,
    isScheduled: Boolean(data.isScheduled),
    content:
      typeof data.content === 'string'
        ? data.content
        : typeof data.text === 'string'
        ? data.text
        : typeof data.body === 'string'
        ? data.body
        : '',
    tags: Array.isArray(data.tags) ? data.tags : [],
    mentions: Array.isArray(data.mentions) ? data.mentions : [],
    createdAt:
      typeof data.createdAt === 'number'
        ? data.createdAt
        : data.createdAt?.toMillis?.() || Date.now(),
    editedAt: data.editedAt || null,
    likesCount: Math.max(0, Number.isFinite(Number(data.likesCount)) ? Number(data.likesCount) : 0),
    commentsCount: Math.max(0, Number.isFinite(Number(data.commentsCount)) ? Number(data.commentsCount) : 0),
    repostsCount: Math.max(0, Number.isFinite(Number(data.repostsCount)) ? Number(data.repostsCount) : 0),
    bookmarksCount: Math.max(0, Number.isFinite(Number(data.bookmarksCount)) ? Number(data.bookmarksCount) : 0),
    viewsCount: Math.max(0, Number.isFinite(Number(data.viewsCount)) ? Number(data.viewsCount) : 0),
    isPinned: Boolean(data.isPinned),
    isRepost: Boolean(data.isRepost),
    collaborators: Array.isArray(data.collaborators) ? data.collaborators : [],
    collaboratorIds: Array.isArray(data.collaboratorIds) ? data.collaboratorIds : [],
    repostOf: data.repostOf || null,
  };
};

/** Prefix search for the collaboration picker. Usernames are stored lowercase. */
export const searchCollaboratorUsers = async (rawPrefix: string, currentUid: string, maxResults = 8): Promise<UserProfile[]> => {
  const prefix = rawPrefix.trim().replace(/^@/, '').toLowerCase();
  if (!prefix || prefix.length < 1) return [];
  const usersQuery = query(
    collection(db, 'users'),
    where('username', '>=', prefix),
    where('username', '<=', `${prefix}\uf8ff`),
    orderBy('username'),
    limit(Math.min(12, Math.max(1, maxResults + 3)))
  );
  const snap = await getDocs(usersQuery);
  return snap.docs
    .map(d => ({ ...(d.data() as UserProfile), uid: (d.data() as UserProfile).uid || d.id }))
    .filter(user => user.uid !== currentUid && user.username && (!user.status || user.status === 'active'))
    .slice(0, maxResults);
};

export const createPost = async (
  author: UserProfile,
  rawContent: string,
  quotePost?: Post | null,
  options: { privacy?: 'public' | 'private'; scheduledAt?: number | null; collaboratorUsernames?: string[]; communityCategory?: string } = {}
): Promise<Post> => {
  const content = sanitizeTextOnlyContent(rawContent);
  const { tags, mentions } = parseTagsAndMentions(content);
  const category = typeof options.communityCategory === 'string' ? options.communityCategory.trim().slice(0, 48) : '';
  
  const postsCollection = collection(db, 'posts');
  const newPostRef = doc(postsCollection);
  const now = Date.now();
  const requestedNames = [...new Set((options.collaboratorUsernames || []).map(v => v.trim().replace(/^@/, '').toLowerCase()).filter(Boolean))];
  let collaborationEnabled = true;
  let maxCollaborators = 6;
  if (requestedNames.length > 0) {
    try {
      const platformSettingsSnap = await getDoc(doc(db, 'platformSettings', 'global'));
      if (platformSettingsSnap.exists()) {
        const platformSettings = platformSettingsSnap.data();
        collaborationEnabled = platformSettings.collaborationEnabled !== false;
        const configuredMax = Number(platformSettings.maxCollaborators);
        if (Number.isInteger(configuredMax)) maxCollaborators = Math.min(6, Math.max(1, configuredMax));
      }
    } catch (settingsError) {
      console.warn('Could not read collaboration settings; using safe defaults:', settingsError);
    }
  }
  if (requestedNames.length && !collaborationEnabled) throw new Error('Post collaboration is currently disabled by OpenCirkle administration.');
  if (requestedNames.length > maxCollaborators) throw new Error(`You can invite up to ${maxCollaborators} collaborators per post.`);
  const collaborators: NonNullable<Post['collaborators']> = [];
  for (const username of requestedNames) {
    if (username === author.username.toLowerCase()) throw new Error('You cannot invite yourself as a collaborator.');
    const userSnap = await getDocs(query(collection(db, 'users'), where('username', '==', username), limit(1)));
    if (userSnap.empty) throw new Error(`Could not find @${username}. Check the username and try again.`);
    const invitee = userSnap.docs[0].data() as UserProfile;
    if (invitee.uid === author.uid) throw new Error('You cannot invite yourself as a collaborator.');
    if (invitee.status === 'banned' || invitee.status === 'suspended') throw new Error(`@${username} cannot be invited right now.`);
    collaborators.push({ uid: invitee.uid, username: invitee.username, displayName: invitee.displayName || invitee.username, status: 'pending', invitedAt: now });
  }

  const postData: Post = {
    id: newPostRef.id,
    authorId: author.uid,
    authorUsername: author.username,
    authorDisplayName: author.displayName,
    authorVerified: Boolean(author.verified),
    authorAvatarSymbol: author.avatarSymbol || 'gem',
    authorAvatarColor: author.avatarColor || 'electric',
    ...(typeof author.avatarUrl === 'string' && author.avatarUrl.trim() ? { authorAvatarUrl: author.avatarUrl.trim() } : {}),
    content,
    ...(category ? { communityCategory: category } : {}),
    privacy: options.privacy || 'public',
    scheduledAt: options.scheduledAt || null,
    isScheduled: Boolean(options.scheduledAt && options.scheduledAt > now),
    tags,
    mentions,
    createdAt: now,
    editedAt: null,
    likesCount: 0,
    commentsCount: 0,
    repostsCount: 0,
    bookmarksCount: 0,
    viewsCount: 0,
    isPinned: false,
    collaborators,
    collaboratorIds: collaborators.map(c => c.uid),
    isRepost: Boolean(quotePost),
    repostOf: quotePost
      ? {
          id: quotePost.id,
          authorUsername: quotePost.authorUsername,
          authorDisplayName: quotePost.authorDisplayName,
          authorVerified: quotePost.authorVerified,
          content: (quotePost.content || '').slice(0, 300),
          createdAt: quotePost.createdAt,
        }
      : null,
  };

  await setDoc(newPostRef, postData);
  for (const collaborator of collaborators) {
    try { await createNotification({ recipientId: collaborator.uid, senderId: author.uid, senderUsername: author.username, senderDisplayName: author.displayName, senderAvatarSymbol: author.avatarSymbol, senderAvatarColor: author.avatarColor, senderAvatarUrl: author.avatarUrl, type: 'collab_invite', targetPostId: newPostRef.id, textSnippet: content.slice(0, 100) }); }
    catch (e) { console.warn('Could not send collaboration invitation:', e); }
  }

  // Increment author post count
  try {
    await updateDoc(doc(db, 'users', author.uid), {
      postsCount: increment(1),
    });
  } catch (err) {
    console.warn('Could not increment user post count:', err);
  }

  // If quote-posting, increment reposts count and notify original author
  if (quotePost && quotePost.authorId !== author.uid) {
    try {
      await updateDoc(doc(db, 'posts', quotePost.id), {
        repostsCount: increment(1),
      });
      await createNotification({
        recipientId: quotePost.authorId,
        senderId: author.uid,
        senderUsername: author.username,
        senderDisplayName: author.displayName,
        senderAvatarSymbol: author.avatarSymbol,
        senderAvatarColor: author.avatarColor,
      senderAvatarUrl: author.avatarUrl,
        type: 'repost',
        targetPostId: newPostRef.id,
        textSnippet: content.slice(0, 100),
      });
    } catch (e) {
      console.warn('Failed quote notification:', e);
    }
  }

  // Handle mention notifications
  for (const mentionedUsername of mentions) {
    try {
      const userQ = query(collection(db, 'users'), where('username', '==', mentionedUsername));
      const uSnap = await getDocs(userQ);
      if (!uSnap.empty) {
        const targetUser = uSnap.docs[0].data() as UserProfile;
        if (targetUser.uid !== author.uid) {
          await createNotification({
            recipientId: targetUser.uid,
            senderId: author.uid,
            senderUsername: author.username,
            senderDisplayName: author.displayName,
            senderAvatarSymbol: author.avatarSymbol,
            senderAvatarColor: author.avatarColor,
      senderAvatarUrl: author.avatarUrl,
            type: 'mention',
            targetPostId: newPostRef.id,
            textSnippet: content.slice(0, 100),
          });
        }
      }
    } catch (e) {
      console.warn('Failed to process mention:', e);
    }
  }

  return postData;
};

export const editPost = async (postId: string, authorId: string, newRawContent: string): Promise<string> => {
  const content = sanitizeTextOnlyContent(newRawContent);
  const { tags, mentions } = parseTagsAndMentions(content);
  
  const postRef = doc(db, 'posts', postId);
  const postSnap = await getDoc(postRef);
  if (!postSnap.exists()) {
    throw new Error('Post not found.');
  }

  const post = mapPostDoc(postSnap);
  if (post.authorId !== authorId) {
    throw new Error('Unauthorized to edit this post.');
  }

  await updateDoc(postRef, {
    content,
    tags,
    mentions,
    editedAt: Date.now(),
  });

  return content;
};

/** Update the invited collaborator list while preserving existing acceptance states. */
export const updatePostCollaborators = async (postId: string, author: UserProfile, desiredUsernames: string[]): Promise<Post['collaborators']> => {
  const postRef = doc(db, 'posts', postId);
  const postSnap = await getDoc(postRef);
  if (!postSnap.exists()) throw new Error('Post not found.');
  const post = mapPostDoc(postSnap);
  if (post.authorId !== author.uid) throw new Error('Only the post author can manage collaborators.');

  const requestedNames = [...new Set((desiredUsernames || []).map(v => String(v || '').trim().replace(/^@/, '').toLowerCase()).filter(Boolean))];
  let collaborationEnabled = true;
  let maxCollaborators = 6;
  try {
    const settingsSnap = await getDoc(doc(db, 'platformSettings', 'global'));
    if (settingsSnap.exists()) {
      const settings = settingsSnap.data();
      collaborationEnabled = settings.collaborationEnabled !== false;
      const configuredMax = Number(settings.maxCollaborators);
      if (Number.isInteger(configuredMax)) maxCollaborators = Math.min(6, Math.max(1, configuredMax));
    }
  } catch (e) { console.warn('Could not read collaboration settings; using safe defaults:', e); }

  const current = post.collaborators || [];
  const currentByUsername = new Map(current.map(c => [c.username.toLowerCase(), c]));
  const desired: NonNullable<Post['collaborators']> = [];
  const newlyInvited: NonNullable<Post['collaborators']> = [];

  for (const username of requestedNames) {
    if (username === author.username.toLowerCase()) throw new Error('You cannot invite yourself as a collaborator.');
    const existing = currentByUsername.get(username);
    if (existing) { desired.push(existing); continue; }
    if (!collaborationEnabled) throw new Error('Post collaboration is currently disabled by OpenCirkle administration.');
    const userSnap = await getDocs(query(collection(db, 'users'), where('username', '==', username), limit(1)));
    if (userSnap.empty) throw new Error(`Could not find @${username}. Check the username and try again.`);
    const data = userSnap.docs[0].data() as UserProfile;
    const invitee = { ...data, uid: data.uid || userSnap.docs[0].id };
    if (invitee.uid === author.uid) throw new Error('You cannot invite yourself as a collaborator.');
    if (invitee.status === 'banned' || invitee.status === 'suspended') throw new Error(`@${username} cannot be invited right now.`);
    const item = { uid: invitee.uid, username: invitee.username, displayName: invitee.displayName || invitee.username, status: 'pending' as const, invitedAt: Date.now() };
    desired.push(item);
    newlyInvited.push(item);
  }

  if (newlyInvited.length > 0 && desired.length > maxCollaborators) throw new Error(`You can have up to ${maxCollaborators} collaborators per post.`);
  if (newlyInvited.length > 0 && !collaborationEnabled) throw new Error('Post collaboration is currently disabled by OpenCirkle administration.')

  const desiredIds = new Set(desired.map(c => c.uid));
  const removed = current.filter(c => !desiredIds.has(c.uid));
  await updateDoc(postRef, { collaborators: desired, collaboratorIds: desired.map(c => c.uid), editedAt: Date.now() });

  // Remove stale acceptance/rejection records for collaborators removed by the author.
  for (const collaborator of removed) {
    try { await deleteDoc(doc(db, 'postCollaborationResponses', `${postId}_${collaborator.uid}`)); }
    catch (e) { console.warn('Could not clear removed collaborator response:', e); }
    try {
      const inviteNotifs = await getDocs(query(collection(db, 'notifications'), where('recipientId', '==', collaborator.uid), limit(100)));
      for (const notification of inviteNotifs.docs) {
        const data = notification.data() as any;
        if (data.type === 'collab_invite' && data.targetPostId === postId) await deleteDoc(notification.ref);
      }
    } catch (e) { console.warn('Could not clear removed collaborator invitation notification:', e); }
  }
  for (const collaborator of newlyInvited) {
    try {
      await createNotification({
        recipientId: collaborator.uid, senderId: author.uid, senderUsername: author.username,
        senderDisplayName: author.displayName, senderAvatarSymbol: author.avatarSymbol || 'gem',
        senderAvatarColor: author.avatarColor || 'electric',
        ...(typeof author.avatarUrl === 'string' && author.avatarUrl.trim() ? { senderAvatarUrl: author.avatarUrl.trim() } : {}),
        type: 'collab_invite', targetPostId: postId, textSnippet: post.content.slice(0, 100),
      });
    } catch (e) { console.warn('Could not send collaboration invitation:', e); }
  }
  return desired;
};

export const deletePost = async (postId: string, requesterUid: string, isModOrAdmin = false): Promise<void> => {
  const postRef = doc(db, 'posts', postId);
  const postSnap = await getDoc(postRef);
  if (!postSnap.exists()) return;

  const post = mapPostDoc(postSnap);
  if (post.authorId !== requesterUid && !isModOrAdmin) {
    throw new Error('Unauthorized to delete this post.');
  }

  await deleteDoc(postRef);

  // Decrement user post count
  try {
    await updateDoc(doc(db, 'users', post.authorId), {
      postsCount: increment(-1),
    });
  } catch (err) {
    console.warn('Could not decrement user post count:', err);
  }
};

export const toggleLikePost = async (
  postId: string,
  user: UserProfile
): Promise<boolean> => {
  const likeRef = doc(db, 'likes', `${user.uid}_${postId}`);
  const postRef = doc(db, 'posts', postId);
  const liked = await runTransaction(db, async (tx) => {
    const likeSnap = await tx.get(likeRef);
    const postSnap = await tx.get(postRef);
    if (!postSnap.exists()) throw new Error('Post no longer exists.');
    const postData = mapPostDoc(postSnap);
    const authorRef = doc(db, 'users', postData.authorId);
    if (likeSnap.exists()) {
      tx.delete(likeRef);
      tx.update(postRef, { likesCount: increment(-1) });
      if (postData.authorId) tx.update(authorRef, { likesCount: increment(-1) });
      return false;
    }
    tx.set(likeRef, { userId: user.uid, postId, createdAt: Date.now() });
    tx.update(postRef, { likesCount: increment(1) });
    if (postData.authorId) tx.update(authorRef, { likesCount: increment(1) });
    return true;
  });
  invalidateInteractionStatus('like', user.uid, postId);
  interactionStatusCache.set(`like:${user.uid}:${postId}`, { value: liked, expiresAt: Date.now() + INTERACTION_CACHE_MS });
  if (liked) {
    try {
      const postSnap = await getDoc(postRef);
      if (postSnap.exists()) {
        const postData = mapPostDoc(postSnap);
        if (postData.authorId !== user.uid) await createNotification({
          recipientId: postData.authorId, senderId: user.uid, senderUsername: user.username,
          senderDisplayName: user.displayName, senderAvatarSymbol: user.avatarSymbol || 'gem',
          senderAvatarColor: user.avatarColor || 'electric', senderAvatarUrl: user.avatarUrl, type: 'like', targetPostId: postId,
          textSnippet: (postData.content || '').slice(0, 100),
        });
      }
    } catch (err) { console.warn('Like notification failed:', err); }
  }
  return liked;
};

export const checkIsLiked = async (postId: string, uid: string): Promise<boolean> => {
  const key = `like:${uid}:${postId}`;
  const cached = interactionStatusCache.get(key);
  if (cached && cached.expiresAt > Date.now()) return cached.value;
  const pending = interactionStatusPending.get(key);
  if (pending) return pending;
  const request = getDoc(doc(db, 'likes', `${uid}_${postId}`)).then((snap) => {
    const value = snap.exists();
    interactionStatusCache.set(key, { value, expiresAt: Date.now() + INTERACTION_CACHE_MS });
    return value;
  }).finally(() => interactionStatusPending.delete(key));
  interactionStatusPending.set(key, request);
  return request;
};

export const toggleBookmarkPost = async (postId: string, uid: string): Promise<boolean> => {
  const bookmarkDocId = `${uid}_${postId}`;
  const bookmarkRef = doc(db, 'bookmarks', bookmarkDocId);
  const bookmarkSnap = await getDoc(bookmarkRef);
  const postRef = doc(db, 'posts', postId);

  if (bookmarkSnap.exists()) {
    await deleteDoc(bookmarkRef);
    await updateDoc(postRef, { bookmarksCount: increment(-1) });
    invalidateInteractionStatus('bookmark', uid, postId);
    interactionStatusCache.set(`bookmark:${uid}:${postId}`, { value: false, expiresAt: Date.now() + INTERACTION_CACHE_MS });
    return false;
  } else {
    await setDoc(bookmarkRef, {
      userId: uid,
      postId,
      createdAt: Date.now(),
    });
    await updateDoc(postRef, { bookmarksCount: increment(1) });
    invalidateInteractionStatus('bookmark', uid, postId);
    interactionStatusCache.set(`bookmark:${uid}:${postId}`, { value: true, expiresAt: Date.now() + INTERACTION_CACHE_MS });
    return true;
  }
};

export const checkIsBookmarked = async (postId: string, uid: string): Promise<boolean> => {
  const key = `bookmark:${uid}:${postId}`;
  const cached = interactionStatusCache.get(key);
  if (cached && cached.expiresAt > Date.now()) return cached.value;
  const pending = interactionStatusPending.get(key);
  if (pending) return pending;
  const request = getDoc(doc(db, 'bookmarks', `${uid}_${postId}`)).then((snap) => {
    const value = snap.exists();
    interactionStatusCache.set(key, { value, expiresAt: Date.now() + INTERACTION_CACHE_MS });
    return value;
  }).finally(() => interactionStatusPending.delete(key));
  interactionStatusPending.set(key, request);
  return request;
};

export const togglePinPost = async (postId: string, authorId: string): Promise<boolean> => {
  const userRef = doc(db, 'users', authorId);
  const userSnap = await getDoc(userRef);
  if (!userSnap.exists()) return false;

  const userData = userSnap.data() as UserProfile;
  const isCurrentlyPinned = userData.pinnedPostId === postId;

  if (isCurrentlyPinned) {
    await updateDoc(userRef, { pinnedPostId: null });
    await updateDoc(doc(db, 'posts', postId), { isPinned: false });
    return false;
  } else {
    if (userData.pinnedPostId) {
      try {
        await updateDoc(doc(db, 'posts', userData.pinnedPostId), { isPinned: false });
      } catch (err) {
        console.warn('Could not unpin previous post:', err);
      }
    }
    await updateDoc(userRef, { pinnedPostId: postId });
    await updateDoc(doc(db, 'posts', postId), { isPinned: true });
    return true;
  }
};

export const fetchPostsFeed = async ({
  feedType = 'latest',
  followedUserIds = [],
  pageSize = 20,
  lastDoc = null,
}: {
  feedType: 'latest' | 'following' | 'popular';
  followedUserIds?: string[];
  pageSize?: number;
  lastDoc?: DocumentSnapshot | null;
}): Promise<{ posts: Post[]; lastVisible: DocumentSnapshot | null }> => {
  const postsCollection = collection(db, 'posts');

  try {
    let q;

    if (feedType === 'following') {
      if (followedUserIds.length === 0) {
        return { posts: [], lastVisible: null };
      }
      const queryIds = followedUserIds.slice(0, 30);
      try {
        q = query(
          postsCollection,
          where('authorId', 'in', queryIds),
          where('privacy', '==', 'public'),
          orderBy('createdAt', 'desc'),
          limit(pageSize)
        );
        if (lastDoc) q = query(q, startAfter(lastDoc));
        const snap = await getDocs(q);
        const posts = snap.docs.map(mapPostDoc);
        const lastVisible = snap.docs[snap.docs.length - 1] || null;
        return { posts, lastVisible };
      } catch (err) {
        // Fallback without orderBy to prevent missing index errors
        let fallbackQ = query(
          postsCollection,
          where('authorId', 'in', queryIds),
          where('privacy', '==', 'public'),
          orderBy('createdAt', 'desc'),
          limit(pageSize)
        );
        if (lastDoc) fallbackQ = query(fallbackQ, startAfter(lastDoc));
        let snap;
        try { snap = await getDocs(fallbackQ); }
        catch {
          let unorderedQ = query(postsCollection, where('authorId', 'in', queryIds), where('privacy', '==', 'public'), limit(pageSize));
          if (lastDoc) unorderedQ = query(unorderedQ, startAfter(lastDoc));
          snap = await getDocs(unorderedQ);
        }
        const posts = snap.docs.map(mapPostDoc).sort((a, b) => b.createdAt - a.createdAt);
        return { posts, lastVisible: snap.docs[snap.docs.length - 1] || null };
      }
    } else {
      // Query all ordered posts, then apply privacy client-side. Older posts created
      // before the privacy field existed were silently excluded by where(privacy == public),
      // making a busy community appear to contain only one or two posts.
      q = query(postsCollection, orderBy('createdAt', 'desc'), limit(pageSize));
    }

    if (lastDoc) q = query(q, startAfter(lastDoc));

    const snap = await getDocs(q);
    let posts = snap.docs.map(mapPostDoc);
    if (feedType !== 'following') posts = posts.filter((post: any) => post.privacy !== 'private');
    if (feedType === 'popular') posts.sort((a, b) => b.likesCount - a.likesCount);
    const lastVisible = snap.docs[snap.docs.length - 1] || null;
    return { posts, lastVisible };
  } catch (err) {
    console.warn('Error querying posts feed, attempting safe fallback:', err);
    // Ultimate graceful fallback: load posts without order and sort client side
    let fallbackQ = query(postsCollection, orderBy('createdAt', 'desc'), limit(pageSize));
    if (lastDoc) fallbackQ = query(fallbackQ, startAfter(lastDoc));
    let snap;
    try {
      snap = await getDocs(fallbackQ);
    } catch {
      // If the ordered query needs an index, retain a pageable fallback instead of silently stopping after page one.
      let unorderedQ = query(postsCollection, limit(pageSize));
      if (lastDoc) unorderedQ = query(unorderedQ, startAfter(lastDoc));
      snap = await getDocs(unorderedQ);
    }
    const posts = snap.docs.map(mapPostDoc).filter((post: any) => post.privacy !== 'private').sort((a, b) => b.createdAt - a.createdAt);
    const lastVisible = snap.docs[snap.docs.length - 1] || null;
    return { posts, lastVisible };
  }
};

export const fetchPostsByHashtag = async (tag: string, pageSize = 20): Promise<Post[]> => {
  const cleanTag = tag.toLowerCase().replace(/^#/, '');
  try {
    const q = query(
      collection(db, 'posts'),
      where('privacy', '==', 'public'),
      where('tags', 'array-contains', cleanTag),
      orderBy('createdAt', 'desc'),
      limit(pageSize)
    );
    const snap = await getDocs(q);
    return snap.docs.map(mapPostDoc);
  } catch (err) {
    // Fallback without orderBy
    const fallbackQ = query(
      collection(db, 'posts'),
      where('privacy', '==', 'public'),
      where('tags', 'array-contains', cleanTag),
      limit(pageSize)
    );
    const snap = await getDocs(fallbackQ);
    return snap.docs.map(mapPostDoc).sort((a, b) => b.createdAt - a.createdAt);
  }
};

/** Returns the authoritative number of posts authored by a user without downloading every post document. */
export const fetchUserPostCount = async (authorId: string): Promise<number | null> => {
  try {
    const postsQuery = query(collection(db, 'posts'), where('authorId', '==', authorId));
    const result = await getCountFromServer(postsQuery);
    const count = Number(result.data().count);
    return Number.isFinite(count) ? Math.max(0, count) : null;
  } catch (error) {
    console.warn('Could not fetch authoritative discourse count:', error);
    return null;
  }
};

export const fetchUserPosts = async (authorId: string, pageSize = 30): Promise<Post[]> => {
  const isOwnProfile = auth.currentUser?.uid === authorId;
  const visible = (post: Post) => isOwnProfile || post.privacy !== 'private';
  // Fetch posts authored by this user and posts for which this user accepted a collaboration.
  // The response document is the source of truth; pending/rejected invitations never appear.
  const authoredQuery = query(collection(db, 'posts'), where('authorId', '==', authorId), orderBy('createdAt', 'desc'), limit(pageSize));
  const authoredFallback = query(collection(db, 'posts'), where('authorId', '==', authorId), limit(pageSize));
  const acceptedQuery = query(collection(db, 'postCollaborationResponses'), where('userId', '==', authorId), limit(pageSize * 3));
  // Independent reads run together instead of making profile rendering wait for each query in turn.
  const [authoredResult, acceptedResult] = await Promise.allSettled([getDocs(authoredQuery), getDocs(acceptedQuery)]);
  let authoredDocs: Awaited<ReturnType<typeof getDocs>>['docs'];
  if (authoredResult.status === 'fulfilled') authoredDocs = authoredResult.value.docs;
  else {
    try { authoredDocs = (await getDocs(authoredFallback)).docs; }
    catch { authoredDocs = []; }
  }
  let acceptedDocs = [] as Awaited<ReturnType<typeof getDocs>>['docs'];
  if (acceptedResult.status === 'fulfilled') acceptedDocs = acceptedResult.value.docs;
  else console.warn('Could not load accepted collaboration profile entries:', acceptedResult.reason);

  const postIds = [...new Set(acceptedDocs.filter((item) => item.data().status === 'accepted').map((item) => String(item.data().postId || '')).filter(Boolean))];
  const collaboratorDocs = await Promise.all(postIds.map(async (id) => {
    try { const snap = await getDoc(doc(db, 'posts', id)); return snap.exists() ? snap : null; }
    catch (error) { console.warn('Could not load collaborated post:', id, error); return null; }
  }));
  const acceptedPostIds = new Set(postIds);
  const allDocs = [...authoredDocs, ...collaboratorDocs.filter((item): item is NonNullable<typeof item> => Boolean(item))];
  const unique = new Map<string, Post>();
  allDocs.forEach((snapshot) => { const post = mapPostDoc(snapshot); if (visible(post) || acceptedPostIds.has(post.id)) unique.set(post.id, post); });
  return [...unique.values()].sort((a, b) => b.createdAt - a.createdAt).slice(0, pageSize);
};

export const fetchBookmarkedPosts = async (uid: string): Promise<Post[]> => {
  try {
    const bookmarksQ = query(
      collection(db, 'bookmarks'),
      where('userId', '==', uid),
      orderBy('createdAt', 'desc'),
      limit(40)
    );
    const bSnap = await getDocs(bookmarksQ);
    const postIds = bSnap.docs.map((d) => d.data().postId);
    if (postIds.length === 0) return [];

    const snapshots = await Promise.all(postIds.map((id) => getDoc(doc(db, 'posts', id)).catch(() => null)));
    return snapshots.filter((snap): snap is NonNullable<typeof snap> => Boolean(snap?.exists()))
      .map((snap) => mapPostDoc(snap));
  } catch (err) {
    const fallbackQ = query(
      collection(db, 'bookmarks'),
      where('userId', '==', uid),
      limit(40)
    );
    const bSnap = await getDocs(fallbackQ);
    const postIds = bSnap.docs.map((d) => d.data().postId);
    if (postIds.length === 0) return [];

    const snapshots = await Promise.all(postIds.map((id) => getDoc(doc(db, 'posts', id)).catch(() => null)));
    return snapshots.filter((snap): snap is NonNullable<typeof snap> => Boolean(snap?.exists()))
      .map((snap) => mapPostDoc(snap)).sort((a, b) => b.createdAt - a.createdAt);
  }
};

export const searchPosts = async (queryText: string): Promise<Post[]> => {
  const clean = queryText.trim().toLowerCase();
  if (!clean) return [];

  if (clean.startsWith('#')) {
    return fetchPostsByHashtag(clean.slice(1), 25);
  }

  try {
    const q = query(collection(db, 'posts'), where('privacy', '==', 'public'), orderBy('createdAt', 'desc'), limit(100));
    const snap = await getDocs(q);
    const allPosts = snap.docs.map(mapPostDoc);

    return allPosts.filter(
      (p) =>
        (p.content || '').toLowerCase().includes(clean) ||
        (p.authorUsername || '').toLowerCase().includes(clean) ||
        (p.authorDisplayName || '').toLowerCase().includes(clean) ||
        p.tags.some((t) => t.toLowerCase().includes(clean))
    );
  } catch (err) {
    const fallbackQ = query(collection(db, 'posts'), where('privacy', '==', 'public'), limit(100));
    const snap = await getDocs(fallbackQ);
    const allPosts = snap.docs.map(mapPostDoc);

    return allPosts.filter(
      (p) =>
        (p.content || '').toLowerCase().includes(clean) ||
        (p.authorUsername || '').toLowerCase().includes(clean) ||
        (p.authorDisplayName || '').toLowerCase().includes(clean) ||
        p.tags.some((t) => t.toLowerCase().includes(clean))
    );
  }
};


/** Accept or reject a pending post collaboration invitation. */
export const respondToPostCollaboration = async (postId: string, user: UserProfile, accept: boolean): Promise<void> => {
  const postRef = doc(db, 'posts', postId);
  const snap = await getDoc(postRef);
  if (!snap.exists()) throw new Error('Post not found.');
  const post = mapPostDoc(snap);
  const collaborators = post.collaborators || [];
  const invite = collaborators.find(c => c.uid === user.uid);
  if (!invite || invite.status !== 'pending') throw new Error('No pending collaboration invitation found.');
  const responseRef = doc(db, 'postCollaborationResponses', `${postId}_${user.uid}`);
  const existingResponse = await getDoc(responseRef);
  if (existingResponse.exists()) throw new Error('You have already responded to this invitation.');
  // Keep the response document free of undefined values so Firestore accepts
  // profiles that do not have every optional profile field populated.
  await setDoc(responseRef, {
    id: responseRef.id,
    postId,
    userId: user.uid,
    username: typeof user.username === 'string' ? user.username : '',
    displayName: typeof user.displayName === 'string' && user.displayName.trim() ? user.displayName.trim() : (user.username || 'OpenCirkle user'),
    status: accept ? 'accepted' : 'rejected',
    respondedAt: Date.now(),
  });

  // A response must remain successful even if the follow-up notification cannot
  // be delivered; the invitee's response is the source of truth.
  try {
    await createNotification({
      recipientId: post.authorId,
      senderId: user.uid,
      senderUsername: user.username || 'user',
      senderDisplayName: user.displayName || user.username || 'OpenCirkle user',
      senderAvatarSymbol: user.avatarSymbol || 'gem',
      senderAvatarColor: user.avatarColor || 'electric',
      ...(typeof user.avatarUrl === 'string' && user.avatarUrl.trim() ? { senderAvatarUrl: user.avatarUrl.trim() } : {}),
      type: accept ? 'collab_accepted' : 'collab_rejected',
      targetPostId: postId,
      textSnippet: (post.content || '').slice(0, 100),
    });
  } catch (notificationError) {
    console.warn('Collaboration response saved, but author notification could not be sent:', notificationError);
  }
};
