import {
  collection,
  doc,
  setDoc,
  getDocs,
  updateDoc,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  writeBatch,
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { NotificationItem, NotificationType, UserProfile } from '../types';

export const createNotification = async ({
  recipientId,
  senderId,
  senderUsername,
  senderDisplayName,
  senderAvatarSymbol,
  senderAvatarColor,
  senderAvatarUrl,
  type,
  targetPostId,
  textSnippet,
}: {
  recipientId: string;
  senderId: string;
  senderUsername: string;
  senderDisplayName: string;
  senderAvatarSymbol: UserProfile['avatarSymbol'];
  senderAvatarColor: UserProfile['avatarColor'];
  senderAvatarUrl?: string;
  type: NotificationType;
  targetPostId?: string;
  textSnippet?: string;
}): Promise<void> => {
  if (recipientId === senderId) return; // Don't notify self

  const notifRef = doc(collection(db, 'notifications'));
  const notification: NotificationItem = {
    id: notifRef.id,
    recipientId,
    senderId,
    senderUsername,
    senderDisplayName: typeof senderDisplayName === 'string' && senderDisplayName.trim() ? senderDisplayName.trim() : senderUsername,
    senderAvatarSymbol: senderAvatarSymbol || 'gem',
    senderAvatarColor: senderAvatarColor || 'electric',
    ...(typeof senderAvatarUrl === 'string' && senderAvatarUrl.trim() ? { senderAvatarUrl: senderAvatarUrl.trim() } : {}),
    type,
    targetPostId: targetPostId || '',
    textSnippet: textSnippet ? textSnippet.slice(0, 100) : '',
    read: false,
    createdAt: Date.now(),
  };

  await setDoc(notifRef, notification);
};

export const subscribeToNotifications = (
  recipientId: string,
  onUpdate: (notifications: NotificationItem[], unreadCount: number) => void
) => {
  const qWithOrder = query(
    collection(db, 'notifications'),
    where('recipientId', '==', recipientId),
    orderBy('createdAt', 'desc'),
    limit(40)
  );

  const fallbackQ = query(
    collection(db, 'notifications'),
    where('recipientId', '==', recipientId),
    limit(40)
  );

  let fallbackActive = false;
  let unsubFallback: (() => void) | null = null;

  const unsubPrimary = onSnapshot(
    qWithOrder,
    (snapshot) => {
      const list = snapshot.docs.map((d) => ({
        ...(d.data() as NotificationItem),
        id: d.id,
      }));
      const unread = list.filter((n) => !n.read).length;
      onUpdate(list, unread);
    },
    (err) => {
      console.warn('Notification ordered snapshot error, switching to safe fallback:', err);
      if (!fallbackActive) {
        fallbackActive = true;
        unsubFallback = onSnapshot(fallbackQ, (fallbackSnap) => {
          const list = fallbackSnap.docs
            .map((d) => ({ ...(d.data() as NotificationItem), id: d.id }))
            .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
          const unread = list.filter((n) => !n.read).length;
          onUpdate(list, unread);
        });
      }
    }
  );

  return () => {
    unsubPrimary();
    if (unsubFallback) unsubFallback();
  };
};

export const markNotificationRead = async (notificationId: string): Promise<void> => {
  const ref = doc(db, 'notifications', notificationId);
  await updateDoc(ref, { read: true });
};

export const markCollaborationInvitationResponded = async (notificationId: string, response: 'accepted' | 'rejected'): Promise<void> => {
  const ref = doc(db, 'notifications', notificationId);
  await updateDoc(ref, { read: true, collaborationResponse: response });
};

export const markAllNotificationsRead = async (recipientId: string): Promise<void> => {
  const q = query(
    collection(db, 'notifications'),
    where('recipientId', '==', recipientId),
    where('read', '==', false)
  );
  const snap = await getDocs(q);
  if (snap.empty) return;

  const batch = writeBatch(db);
  snap.docs.forEach((d) => {
    batch.update(d.ref, { read: true });
  });
  await batch.commit();
};
