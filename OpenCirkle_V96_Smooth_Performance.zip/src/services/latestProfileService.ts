import { doc, getDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { UserProfile } from '../types';

const cache = new Map<string, { profile: UserProfile | null; expiresAt: number }>();
const pending = new Map<string, Promise<UserProfile | null>>();
const CACHE_MS = 30_000;

export const getLatestUserProfile = async (uid: string): Promise<UserProfile | null> => {
  if (!uid) return null;
  const cached = cache.get(uid);
  if (cached && cached.expiresAt > Date.now()) return cached.profile;
  const inFlight = pending.get(uid);
  if (inFlight) return inFlight;
  const request = getDoc(doc(db, 'users', uid)).then((snap) => {
    const profile = snap.exists() ? ({ ...snap.data(), uid: snap.data().uid || snap.id } as UserProfile) : null;
    cache.set(uid, { profile, expiresAt: Date.now() + CACHE_MS });
    return profile;
  }).catch((error) => {
    console.warn('Could not refresh latest user identity:', error);
    return null;
  }).finally(() => pending.delete(uid));
  pending.set(uid, request);
  return request;
};
