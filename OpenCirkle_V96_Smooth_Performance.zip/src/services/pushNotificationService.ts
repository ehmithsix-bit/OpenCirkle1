import { Capacitor } from '@capacitor/core';
import { PushNotifications, Token, PushNotificationSchema, ActionPerformed } from '@capacitor/push-notifications';
import { deleteDoc, doc, getDocs, collection, query, where, addDoc, serverTimestamp, updateDoc } from 'firebase/firestore';
import { getMessaging, getToken, isSupported, onMessage } from 'firebase/messaging';
import app, { db } from '../lib/firebase';

const VAPID_KEY = import.meta.env.VITE_FIREBASE_VAPID_KEY as string | undefined;
export type PushPreferences = { messages: boolean; posts: boolean; stories: boolean; online: boolean; likes: boolean; comments: boolean; follows: boolean };
export const DEFAULT_PUSH_PREFERENCES: PushPreferences = { messages: true, posts: true, stories: true, online: false, likes: true, comments: true, follows: true };

let nativeListenersInstalled = false;
let nativeListenerPromises: Promise<unknown>[] = [];
let activeUid: string | null = null;
let resolveNativeToken: ((token: string) => void) | null = null;
let rejectNativeToken: ((error: Error) => void) | null = null;

function isNativeAndroid() { return Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android'; }

async function saveToken(uid: string, token: string, platform: string) {
  const existing = await getDocs(query(collection(db, 'pushTokens'), where('uid', '==', uid), where('token', '==', token)));
  if (existing.empty) await addDoc(collection(db, 'pushTokens'), { uid, token, platform, createdAt: Date.now(), updatedAt: Date.now(), createdAtServer: serverTimestamp() });
  else await Promise.all(existing.docs.map(item => updateDoc(item.ref, { platform, updatedAt: Date.now(), lastSeenAt: Date.now() })));
}

/** Installs native event handlers and requests Android's runtime permission only when explicitly enabled. */
export async function enablePushNotifications(uid: string): Promise<string> {
  if (isNativeAndroid()) {
    activeUid = uid;
    if (!nativeListenersInstalled) {
      nativeListenersInstalled = true;
      nativeListenerPromises = [
        PushNotifications.addListener('registration', async (token: Token) => {
          const targetUid = activeUid;
          if (targetUid && token.value) {
            try { await saveToken(targetUid, token.value, 'android'); resolveNativeToken?.(token.value); resolveNativeToken = null; rejectNativeToken = null; }
            catch (error) { console.error('Could not save native FCM token to Firestore:', error); rejectNativeToken?.(new Error('FCM token Firestore-এ save করা যায়নি।')); resolveNativeToken = null; rejectNativeToken = null; }
          }
        }),
        PushNotifications.addListener('registrationError', error => { console.error('Native push registration failed:', error); rejectNativeToken?.(new Error('Native FCM registration ব্যর্থ হয়েছে। Firebase/Google Services configuration দেখুন।')); resolveNativeToken = null; rejectNativeToken = null; }),
        PushNotifications.addListener('pushNotificationReceived', (notification: PushNotificationSchema) => {
          window.dispatchEvent(new CustomEvent('opencirkle:push-received', { detail: notification }));
        }),
        PushNotifications.addListener('pushNotificationActionPerformed', (action: ActionPerformed) => {
          const data = action.notification.data || {};
          const url = typeof data.url === 'string' ? data.url : '';
          if (url.startsWith('/#')) window.location.hash = url.slice(1);
          else if (url.startsWith('/')) window.location.hash = url;
          window.dispatchEvent(new CustomEvent('opencirkle:push-action', { detail: action }));
        }),
      ];
      await Promise.all(nativeListenerPromises);
    }
    await PushNotifications.createChannel({ id: 'opencirkle_updates', name: 'OpenCirkle updates', description: 'Posts, stories and messages', importance: 4, visibility: 1, vibration: true });
    const permission = await PushNotifications.checkPermissions();
    const result = permission.receive === 'granted' ? permission : await PushNotifications.requestPermissions();
    if (result.receive !== 'granted') throw new Error('Android Settings থেকে OpenCirkle notification permission Allow করুন।');
    const tokenPromise = new Promise<string>((resolve, reject) => { resolveNativeToken = resolve; rejectNativeToken = reject; setTimeout(() => { if (resolveNativeToken) { resolveNativeToken = null; rejectNativeToken = null; reject(new Error('FCM token পেতে দেরি হচ্ছে। Internet connection ও Firebase configuration পরীক্ষা করে আবার চেষ্টা করুন।')); } }, 15000); });
    await PushNotifications.register();
    return await tokenPromise;
  }

  if (typeof Notification === 'undefined' || !('serviceWorker' in navigator)) throw new Error('এই browser-এ push notification support নেই। Chrome ব্যবহার করে আবার চেষ্টা করুন।');
  if (!(await isSupported())) throw new Error('এই browser/device-এ Firebase push notification support নেই।');
  if (!VAPID_KEY || VAPID_KEY.includes('REPLACE_WITH')) throw new Error('Firebase Console থেকে Web Push VAPID key নিয়ে VITE_FIREBASE_VAPID_KEY সেট করতে হবে।');
  const permission = await Notification.requestPermission();
  if (permission !== 'granted') throw new Error('Notification permission Allow করুন।');
  const registration = await navigator.serviceWorker.register('/firebase-messaging-sw.js');
  const token = await getToken(getMessaging(app), { vapidKey: VAPID_KEY, serviceWorkerRegistration: registration });
  if (!token) throw new Error('Push token তৈরি হয়নি। আবার চেষ্টা করুন।');
  await saveToken(uid, token, 'web');
  return token;
}

export async function initializeNativePushForUser(uid: string) {
  if (!isNativeAndroid()) return;
  if (activeUid === uid && nativeListenersInstalled) return;
  activeUid = uid;
  // Re-register only when the user has already opted in; do not prompt at sign-in.
  try {
    const profile = await (await import('firebase/firestore')).getDoc(doc(db, 'users', uid));
    if (profile.data()?.pushNotificationsEnabled === true) await enablePushNotifications(uid);
  } catch (error) { console.warn('Native push auto-restore failed:', error); }
}

export async function disablePushNotifications(uid: string): Promise<void> {
  const snap = await getDocs(query(collection(db, 'pushTokens'), where('uid', '==', uid)));
  await Promise.all(snap.docs.map(item => deleteDoc(doc(db, 'pushTokens', item.id))));
  if (isNativeAndroid()) {
    activeUid = null;
    try { await PushNotifications.removeAllListeners(); nativeListenersInstalled = false; nativeListenerPromises = []; } catch (error) { console.warn('Could not remove native push listeners:', error); }
  }
}

export async function listenForForegroundPush(onPush: (payload: { title?: string; body?: string }) => void): Promise<() => void> {
  if (isNativeAndroid()) {
    const handler = (event: Event) => { const p = (event as CustomEvent).detail || {}; onPush({ title: p.title, body: p.body }); };
    window.addEventListener('opencirkle:push-received', handler);
    return () => window.removeEventListener('opencirkle:push-received', handler);
  }
  if (!(await isSupported())) return () => {};
  return onMessage(getMessaging(app), payload => onPush({ title: payload.notification?.title, body: payload.notification?.body }));
}
