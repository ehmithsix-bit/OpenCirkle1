import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  increment,
  updateDoc,
  startAfter,
  documentId,
  type QueryDocumentSnapshot,
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { FollowRequestRecord, UserProfile } from '../types';
import { createNotification } from './notificationService';

// Short-lived in-memory cache prevents repeated follow-list reads while moving
// between feed pages and Explore. Mutations invalidate it immediately.
const followingIdsCache = new Map<string, { ids: string[]; expiresAt: number }>();
const followingIdsPending = new Map<string, Promise<string[]>>();
const FOLLOWING_IDS_CACHE_MS = 20_000;
export const invalidateFollowingIdsCache = (uid: string) => {
  followingIdsCache.delete(uid);
  followingIdsPending.delete(uid);
};

const fetchProfilesByIds = async (ids: string[]): Promise<UserProfile[]> => {
  const uniqueIds = [...new Set(ids.filter(Boolean))];
  if (!uniqueIds.length) return [];
  const chunks: string[][] = [];
  for (let i = 0; i < uniqueIds.length; i += 30) chunks.push(uniqueIds.slice(i, i + 30));
  const snapshots = await Promise.all(chunks.map((chunk) => getDocs(query(
    collection(db, 'users'), where(documentId(), 'in', chunk)
  ))));
  const profiles = new Map<string, UserProfile>();
  snapshots.flatMap((snap) => snap.docs).forEach((snap) => {
    profiles.set(snap.id, { ...snap.data(), uid: snap.id } as UserProfile);
  });
  // Keep the same order as the follow documents.
  return uniqueIds.map((id) => profiles.get(id)).filter((user): user is UserProfile => Boolean(user));
};

export const checkFollowStatus = async (
  currentUid: string,
  targetUid: string
): Promise<'not_following' | 'following' | 'requested'> => {
  if (currentUid === targetUid) return 'not_following';

  const followDocId = `${currentUid}_${targetUid}`;
  const requestDocId = `${currentUid}_${targetUid}`;
  // Read follow + request concurrently to avoid two network round trips per suggested user.
  const [followSnap, reqSnap] = await Promise.all([
    getDoc(doc(db, 'follows', followDocId)),
    getDoc(doc(db, 'followRequests', requestDocId)),
  ]);
  if (followSnap.exists()) return 'following';
  if (reqSnap.exists() && reqSnap.data().status === 'pending') return 'requested';

  return 'not_following';
};

export const toggleFollowUser = async (
  currentUser: UserProfile,
  targetUser: UserProfile
): Promise<{ status: 'following' | 'requested' | 'not_following' }> => {
  if (currentUser.uid === targetUser.uid) {
    throw new Error('You cannot follow yourself.');
  }

  const followDocId = `${currentUser.uid}_${targetUser.uid}`;
  const followRef = doc(db, 'follows', followDocId);
  const followSnap = await getDoc(followRef);

  if (followSnap.exists()) {
    // Unfollow
    await Promise.all([
      deleteDoc(followRef),
      updateDoc(doc(db, 'users', currentUser.uid), { followingCount: increment(-1) }),
      updateDoc(doc(db, 'users', targetUser.uid), { followersCount: increment(-1) }),
    ]);
    invalidateFollowingIdsCache(currentUser.uid);
    return { status: 'not_following' };
  }

  // Check if target is private account
  if (targetUser.isPrivate) {
    const reqDocId = `${currentUser.uid}_${targetUser.uid}`;
    const reqRef = doc(db, 'followRequests', reqDocId);
    const reqSnap = await getDoc(reqRef);

    if (reqSnap.exists() && reqSnap.data().status === 'pending') {
      // Cancel request
      await deleteDoc(reqRef);
      return { status: 'not_following' };
    }

    const requestData: FollowRequestRecord = {
      id: reqDocId,
      requesterId: currentUser.uid,
      targetId: targetUser.uid,
      requesterUsername: currentUser.username,
      requesterDisplayName: currentUser.displayName,
      requesterAvatarSymbol: currentUser.avatarSymbol,
      requesterAvatarColor: currentUser.avatarColor,
      status: 'pending',
      createdAt: Date.now(),
    };
    await setDoc(reqRef, requestData);

    void createNotification({
      recipientId: targetUser.uid,
      senderId: currentUser.uid,
      senderUsername: currentUser.username,
      senderDisplayName: currentUser.displayName,
      senderAvatarSymbol: currentUser.avatarSymbol,
      senderAvatarColor: currentUser.avatarColor,
      senderAvatarUrl: currentUser.avatarUrl,
      type: 'follow_request',
      textSnippet: 'requested to follow you.',
    }).catch((error) => console.warn('Follow-request notification failed:', error));

    return { status: 'requested' };
  }

  // Standard immediate follow
  await Promise.all([
    setDoc(followRef, { followerId: currentUser.uid, followingId: targetUser.uid, createdAt: Date.now() }),
    updateDoc(doc(db, 'users', currentUser.uid), { followingCount: increment(1) }),
    updateDoc(doc(db, 'users', targetUser.uid), { followersCount: increment(1) }),
  ]);
  invalidateFollowingIdsCache(currentUser.uid);

  void createNotification({
    recipientId: targetUser.uid,
    senderId: currentUser.uid,
    senderUsername: currentUser.username,
    senderDisplayName: currentUser.displayName,
    senderAvatarSymbol: currentUser.avatarSymbol,
    senderAvatarColor: currentUser.avatarColor,
      senderAvatarUrl: currentUser.avatarUrl,
    type: 'follow',
    textSnippet: 'started following you.',
  }).catch((error) => console.warn('Follow notification failed:', error));

  return { status: 'following' };
};

export const respondToFollowRequest = async (
  request: FollowRequestRecord,
  targetUser: UserProfile,
  accept: boolean
): Promise<void> => {
  const reqRef = doc(db, 'followRequests', request.id);

  if (accept) {
    await updateDoc(reqRef, { status: 'accepted' });
    const followRef = doc(db, 'follows', `${request.requesterId}_${targetUser.uid}`);
    await setDoc(followRef, {
      followerId: request.requesterId,
      followingId: targetUser.uid,
      createdAt: Date.now(),
    });

    await updateDoc(doc(db, 'users', targetUser.uid), { followersCount: increment(1) });
    await updateDoc(doc(db, 'users', request.requesterId), { followingCount: increment(1) });
    invalidateFollowingIdsCache(request.requesterId);

    await createNotification({
      recipientId: request.requesterId,
      senderId: targetUser.uid,
      senderUsername: targetUser.username,
      senderDisplayName: targetUser.displayName,
      senderAvatarSymbol: targetUser.avatarSymbol,
      senderAvatarColor: targetUser.avatarColor,
      senderAvatarUrl: targetUser.avatarUrl,
      type: 'follow',
      textSnippet: 'accepted your follow request.',
    });
  } else {
    await updateDoc(reqRef, { status: 'declined' });
  }

  // Clean up resolved request
  setTimeout(async () => {
    try {
      await deleteDoc(reqRef);
    } catch (e) {
      // Ignored
    }
  }, 1000);
};

export const fetchPendingFollowRequests = async (targetUid: string): Promise<FollowRequestRecord[]> => {
  try {
    const q = query(
      collection(db, 'followRequests'),
      where('targetId', '==', targetUid),
      where('status', '==', 'pending'),
      limit(50)
    );
    const snap = await getDocs(q);
    return snap.docs
      .map((d) => ({ ...(d.data() as FollowRequestRecord), id: d.id }))
      .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  } catch (err) {
    console.warn('Error fetching follow requests:', err);
    return [];
  }
};

export const fetchFollowingIds = async (uid: string): Promise<string[]> => {
  if (!uid) return [];
  const cached = followingIdsCache.get(uid);
  if (cached && cached.expiresAt > Date.now()) return [...cached.ids];
  const pending = followingIdsPending.get(uid);
  if (pending) return pending;
  const request = getDocs(query(collection(db, 'follows'), where('followerId', '==', uid)))
    .then((snap) => {
      const ids = [...new Set(snap.docs.map((d) => String(d.data().followingId || '')).filter(Boolean))];
      followingIdsCache.set(uid, { ids, expiresAt: Date.now() + FOLLOWING_IDS_CACHE_MS });
      return ids;
    })
    .catch((error) => { console.warn('Could not load following IDs:', error); return [] as string[]; })
    .finally(() => followingIdsPending.delete(uid));
  followingIdsPending.set(uid, request);
  return request;
};

export const fetchFollowersList = async (targetUid: string): Promise<UserProfile[]> => {
  const q = query(collection(db, 'follows'), where('followingId', '==', targetUid), limit(50));
  const snap = await getDocs(q);
  const followerIds = snap.docs.map((d) => String(d.data().followerId || '')).filter(Boolean);
  return fetchProfilesByIds(followerIds);
};

export const fetchFollowingList = async (targetUid: string): Promise<UserProfile[]> => {
  const q = query(collection(db, 'follows'), where('followerId', '==', targetUid), limit(50));
  const snap = await getDocs(q);
  const followingIds = snap.docs.map((d) => String(d.data().followingId || '')).filter(Boolean);
  return fetchProfilesByIds(followingIds);
};

/**
 * Fetch Explore people in pages. Unlike the small suggested-users widget, Explore
 * must not stop at eight accounts. We page by document ID so profiles without a
 * followersCount field are not silently skipped by an orderBy query.
 */
export const fetchExploreUsers = async (
  currentUid?: string,
  pageSize = 50,
  lastDoc: QueryDocumentSnapshot | null = null
): Promise<{ users: UserProfile[]; lastDoc: QueryDocumentSnapshot | null; hasMore: boolean }> => {
  let usersQuery = query(collection(db, 'users'), orderBy(documentId()), limit(pageSize));
  if (lastDoc) usersQuery = query(usersQuery, startAfter(lastDoc));
  const snap = await getDocs(usersQuery);
  const users = snap.docs
    .map((d) => ({ ...d.data(), uid: d.id }) as UserProfile)
    .filter((u) => {
      const status = String(u.status || 'active').toLowerCase();
      return Boolean(String(u.uid || '').trim()) &&
        Boolean(String(u.username || '').trim()) &&
        Boolean(String(u.displayName || '').trim()) &&
        u.uid !== currentUid &&
        status === 'active';
    });
  return {
    users,
    lastDoc: snap.docs.length ? snap.docs[snap.docs.length - 1] : lastDoc,
    hasMore: snap.docs.length === pageSize,
  };
};

// Keep the compact suggested-users helper for sidebar widgets; Explore uses
// fetchExploreUsers so it can page through the complete real-user directory.
export const fetchSuggestedUsers = async (currentUid?: string): Promise<UserProfile[]> => {
  try {
    const result = await fetchExploreUsers(currentUid, 8);
    return result.users.slice(0, 8);
  } catch (err) {
    console.warn('Error fetching suggested users:', err);
    return [];
  }
};
