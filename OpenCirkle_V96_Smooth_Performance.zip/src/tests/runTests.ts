import { sanitizeTextOnlyContent, parseTagsAndMentions, MAX_POST_LENGTH } from '../services/postService';
import * as fs from 'fs';
import * as path from 'path';
import { makeVirtualCommunityPostContent } from '../services/virtualCommunityContent';
import { AI_COMMUNITY_PROFILES } from '../services/virtualCommunityProfiles';

let passed = 0;
let failed = 0;

function assert(condition: boolean, testName: string) {
  if (condition) {
    console.log(`✅ PASS: ${testName}`);
    passed++;
  } else {
    console.error(`❌ FAIL: ${testName}`);
    failed++;
  }
}

console.log('--- Running OpenCirkle Architecture, Security & Community Content Verification ---');

// 1. Verify absence of Firebase Storage
const fbPath = path.resolve(process.cwd(), 'src/lib/firebase.ts');
const fbContent = fs.readFileSync(fbPath, 'utf-8');
assert(!fbContent.includes('firebase/storage'), '1. Strictly no firebase/storage imported');
assert(!fbContent.includes('getStorage'), '2. Strictly no getStorage initialized');

// 2. Verify absence of media upload inputs
const composerPath = path.resolve(process.cwd(), 'src/components/post/PostComposer.tsx');
const composerContent = fs.readFileSync(composerPath, 'utf-8');
assert(!composerContent.includes('type="file"'), '3. No type="file" upload controls');
assert(!composerContent.includes('accept="image/*"'), '4. No image pickers');
assert(!composerContent.includes('accept="video/*"'), '5. No video pickers');

// 3. Post sanitization tests
let threwEmpty = false;
try {
  sanitizeTextOnlyContent('');
} catch (e) {
  threwEmpty = true;
}
assert(threwEmpty, '6. Empty text post throws error');

const stripped = sanitizeTextOnlyContent('Testing <b>pure text</b> <script>alert(1)</script>');
assert(stripped === 'Testing pure text alert(1)', '7. Strips HTML tags');

// 4. Character limit
let threwLimit = false;
try {
  sanitizeTextOnlyContent('x'.repeat(MAX_POST_LENGTH + 1));
} catch (e) {
  threwLimit = true;
}
assert(threwLimit, '8. Exceeding 5,000 characters throws error');

// 5. Hashtags and mentions
const { tags, mentions } = parseTagsAndMentions('Hello #OpenCirkle and #CrystalBlue from @alice to @bob');
assert(tags.includes('opencirkle') && tags.includes('crystalblue'), '9. Extracts hashtags');
assert(mentions.includes('alice') && mentions.includes('bob'), '10. Extracts mentions');

// 6. Virtual community content variety
const communitySamples = Array.from({ length: 160 }, (_, i) => makeVirtualCommunityPostContent(i));
assert(new Set(communitySamples.map((sample) => sample.category)).size >= 12, '11. Virtual community spans diverse content categories');
assert(new Set(communitySamples.map((sample) => sample.content)).size >= 100, '12. Virtual community generates varied post wording');
assert(communitySamples.every((sample) => sample.content.trim().length > 20), '13. Virtual community posts contain meaningful text');
const verifiedDummyCount = AI_COMMUNITY_PROFILES.filter((profile) => profile.verified).length;
assert(verifiedDummyCount === 100, '14. Exactly 5 in every 1,000 dummy profiles are verified (100 of 20,000)');

console.log(`\nResults: ${passed} passed, ${failed} failed.`);
if (failed > 0) {
  process.exit(1);
}
