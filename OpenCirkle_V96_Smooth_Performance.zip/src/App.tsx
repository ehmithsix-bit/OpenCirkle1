import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Header } from './components/common/Header';
import { Sidebar } from './components/common/Sidebar';
import { BottomNav } from './components/common/BottomNav';
import { TrendingSidebar } from './components/common/TrendingSidebar';
import { AnnouncementBanner } from './components/common/AnnouncementBanner';
const FeedView = React.lazy(() => import('./components/feed/FeedView').then((m) => ({ default: m.FeedView })));
const ExploreView = React.lazy(() => import('./components/explore/ExploreView').then((m) => ({ default: m.ExploreView })));
const NotificationsView = React.lazy(() => import('./components/notifications/NotificationsView').then((m) => ({ default: m.NotificationsView })));
const ChatView = React.lazy(() => import('./components/messages/ChatView').then((m) => ({ default: m.ChatView })));
const BookmarksView = React.lazy(() => import('./components/bookmarks/BookmarksView').then((m) => ({ default: m.BookmarksView })));
const ProfileView = React.lazy(() => import('./components/profile/ProfileView').then((m) => ({ default: m.ProfileView })));
const SettingsView = React.lazy(() => import('./components/settings/SettingsView').then((m) => ({ default: m.SettingsView })));
const AdminControlCenter = React.lazy(() => import('./components/admin/AdminControlCenter').then((m) => ({ default: m.AdminControlCenter })));
import { AuthModal } from './components/auth/AuthModal';
import { PostComposer } from './components/post/PostComposer';
import { subscribeToNotifications } from './services/notificationService';
import { subscribeToConversations } from './services/messageService';
import { UserProfile } from './types';
import { Dots } from './components/loading-ui/dots';
import { ViewErrorBoundary } from './components/common/ViewErrorBoundary';
import { NetworkStatus } from './components/common/NetworkStatus';
import { collection, doc, getDocsFromServer, limit, onSnapshot, query, updateDoc } from 'firebase/firestore';
import { getFunctions, httpsCallable } from 'firebase/functions';
import { db } from './lib/firebase';
import { Capacitor, registerPlugin } from '@capacitor/core';
import { enablePushNotifications, initializeNativePushForUser, listenForForegroundPush } from './services/pushNotificationService';

interface AppVersionPlugin {
  getVersion(): Promise<{ versionCode: number; versionName: string }>;
}
const NativeAppVersion = registerPlugin<AppVersionPlugin>('AppVersion');

const MainLayout: React.FC = () => {
  const [networkOnline, setNetworkOnline] = useState(() => typeof navigator === 'undefined' ? true : navigator.onLine);
  const [appUpdateConfig, setAppUpdateConfig] = useState<any>(() => {
    try { return JSON.parse(localStorage.getItem('oc-app-update-cache') || 'null') || { enabled: false, url: '', version: '', versionCode: 0, notes: '' }; }
    catch { return { enabled: false, url: '', version: '', versionCode: 0, notes: '' }; }
  });
  const [installedVersionCode, setInstalledVersionCode] = useState<number>(58);
  const [updateVersionReady, setUpdateVersionReady] = useState(false);
  const [offlineRetryBusy, setOfflineRetryBusy] = useState(false);

  useEffect(() => {
    const onOffline = () => setNetworkOnline(false);
    const onOnline = () => setNetworkOnline(true);
    window.addEventListener('offline', onOffline);
    window.addEventListener('online', onOnline);
    return () => {
      window.removeEventListener('offline', onOffline);
      window.removeEventListener('online', onOnline);
    };
  }, []);

  useEffect(() => {
    let active = true;
    const readVersion = async () => {
      try {
        if (Capacitor.isNativePlatform()) {
          const info = await NativeAppVersion.getVersion();
          if (active && Number.isFinite(Number(info.versionCode))) setInstalledVersionCode(Number(info.versionCode));
        } else {
          const configured = Number(import.meta.env.VITE_APP_VERSION_CODE);
          if (active && Number.isFinite(configured) && configured > 0) setInstalledVersionCode(configured);
        }
      } catch (error) {
        console.warn('Could not read installed app version code:', error);
      } finally {
        if (active) setUpdateVersionReady(true);
      }
    };
    void readVersion();
    return () => { active = false; };
  }, []);

  const retryOfflineConnection = async () => {
    if (offlineRetryBusy) return;
    setOfflineRetryBusy(true);
    try {
      // navigator.onLine only reports local network state. Verify that the app can
      // actually reach the Firestore backend before leaving the offline screen.
      if (typeof navigator !== 'undefined' && !navigator.onLine) {
        setNetworkOnline(false);
        return;
      }
      const serverProbe = getDocsFromServer(query(collection(db, 'posts'), limit(1)));
      const timeout = new Promise<never>((_, reject) => {
        window.setTimeout(() => reject(new Error('Backend connection timed out')), 7000);
      });
      await Promise.race([serverProbe, timeout]);
      setNetworkOnline(true);
      window.location.reload();
    } catch (error) {
      console.warn('Offline retry could not reach Firestore backend:', error);
      setNetworkOnline(false);
    } finally {
      setOfflineRetryBusy(false);
    }
  };
  const { currentUserProfile, loading: authLoading, isAdmin, isSuperAdmin } = useAuth();

  // Android 13+ permission prompt: show once after a user signs in on a native Android build.
  // Web browsers intentionally require a user gesture, so web permission is requested by the Settings > Allow button.
  useEffect(() => {
    if (authLoading || !currentUserProfile?.uid || !Capacitor.isNativePlatform() || Capacitor.getPlatform() !== 'android') return;
    let cancelled = false;
    const uid = currentUserProfile.uid;
    const attemptKey = `oc-native-push-prompt-attempted:${uid}`;
    const start = async () => {
      try {
        if (currentUserProfile.pushNotificationsEnabled) {
          await initializeNativePushForUser(uid);
          return;
        }
        if (localStorage.getItem(attemptKey) === '1') return;
        // Persist the attempt before prompting so a denial does not cause repeated system prompts.
        localStorage.setItem(attemptKey, '1');
        await enablePushNotifications(uid);
        if (!cancelled) await updateDoc(doc(db, 'users', uid), { pushNotificationsEnabled: true });
      } catch (error) {
        console.warn('Native push permission/token setup did not complete:', error);
      }
    };
    void start();
    return () => { cancelled = true; };
  }, [authLoading, currentUserProfile?.uid, currentUserProfile?.pushNotificationsEnabled]);
  const [serviceMode, setServiceMode] = useState<'normal' | 'maintenance' | 'closed' | 'server_error' | 'not_found' | 'try_again'>('normal');
  const [serviceModeMessage, setServiceModeMessage] = useState('We are improving OpenCirkle. Please try again shortly.');
  const [serviceModeLoaded, setServiceModeLoaded] = useState(() => { try { return Boolean(localStorage.getItem('oc-service-mode-cache')); } catch { return false; } });
  const [serviceSchedule, setServiceSchedule] = useState<any>(() => { try { return JSON.parse(localStorage.getItem('oc-service-mode-cache') || 'null') || { scheduledServiceEnabled: false, serviceMode: 'normal', maintenanceMode: false, serviceModeMessage: 'We are improving OpenCirkle. Please try again shortly.' }; } catch { return { scheduledServiceEnabled: false, serviceMode: 'normal', maintenanceMode: false, serviceModeMessage: 'We are improving OpenCirkle. Please try again shortly.' }; } });
  const [scheduleCountdownSeconds, setScheduleCountdownSeconds] = useState<number | null>(null);
  const [maintenanceEmail, setMaintenanceEmail] = useState('');
  const [notifyStatus, setNotifyStatus] = useState('');
  const [notifyBusy, setNotifyBusy] = useState(false);
  const [retryBusy, setRetryBusy] = useState(false);
  const [retryStatus, setRetryStatus] = useState('');
  const serviceFunctions = getFunctions(undefined, 'us-central1');

  const submitMaintenanceNotification = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const email = maintenanceEmail.trim().toLowerCase();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setNotifyStatus('Please enter a valid email address.');
      return;
    }
    setNotifyBusy(true);
    setNotifyStatus('');
    try {
      const subscribe = httpsCallable(serviceFunctions, 'subscribeMaintenanceNotifications');
      const result = await subscribe({ email });
      const data = result.data as { alreadySubscribed?: boolean };
      setNotifyStatus(data.alreadySubscribed ? 'This email is already subscribed.' : 'You are subscribed! We will email you when OpenCirkle is back.');
      setMaintenanceEmail('');
    } catch (error: any) {
      console.error('Maintenance notification subscription failed:', error);
      setNotifyStatus(error?.message || 'Could not save your email. Please try again.');
    } finally {
      setNotifyBusy(false);
    }
  };

  const retryServiceCheck = async () => {
    if (retryBusy) return;
    setRetryBusy(true);
    setRetryStatus('');
    try {
      const check = httpsCallable(serviceFunctions, 'checkServiceAvailability');
      const result = await check({});
      const data = result.data as { mode: typeof serviceMode; targetAt?: number; serverNow?: number; message?: string };
      setServiceMode(data.mode || 'normal');
      setServiceModeMessage(data.message || 'We are improving OpenCirkle. Please try again shortly.');
      if (data.targetAt && data.serverNow) setScheduleCountdownSeconds(Math.max(0, Math.ceil((data.targetAt - data.serverNow) / 1000)));
      if (data.mode === 'normal') {
        try { localStorage.removeItem('oc-service-mode-cache'); } catch {}
        window.location.reload();
      } else {
        setRetryStatus('OpenCirkle is still unavailable. Please try again when the timer ends.');
      }
    } catch (error: any) {
      console.error('Authoritative service availability check failed:', error);
      setRetryStatus('Could not reach the server. Check your internet connection and try again.');
    } finally {
      setRetryBusy(false);
    }
  };

  // Live global service lock: admin changes take effect without a redeploy or refresh.
  useEffect(() => {
    const settingsRef = doc(db, 'platformSettings', 'global');
    const unsubscribe = onSnapshot(settingsRef, (snap) => {
      const data = snap.exists() ? snap.data() : {};
      const legacyMaintenance = data.maintenanceMode === true;
      const mode = data.serviceMode as typeof serviceMode | undefined;
      setServiceSchedule({
        scheduledServiceEnabled: data.scheduledServiceEnabled === true,
        serviceCloseAt: Number(data.serviceCloseAt) || 0,
        serviceOpenAt: Number(data.serviceOpenAt) || 0,
        maintenanceEndAt: Number(data.maintenanceEndAt) || 0,
        appClosedReopenAt: Number(data.appClosedReopenAt) || 0,
        scheduledServiceMode: data.scheduledServiceMode === 'closed' ? 'closed' : 'maintenance',
        dailyScheduleEnabled: data.dailyScheduleEnabled === true,
        dailyCloseTime: typeof data.dailyCloseTime === 'string' ? data.dailyCloseTime : '',
        dailyOpenTime: typeof data.dailyOpenTime === 'string' ? data.dailyOpenTime : '',
        manualMode: mode && ['normal', 'maintenance', 'closed', 'server_error', 'not_found', 'try_again'].includes(mode) ? mode : (legacyMaintenance ? 'maintenance' : 'normal'),
        serviceModeMessage: typeof data.serviceModeMessage === 'string' && data.serviceModeMessage.trim() ? data.serviceModeMessage : 'We are improving OpenCirkle. Please try again shortly.',
      });
      try { localStorage.setItem('oc-service-mode-cache', JSON.stringify({ scheduledServiceEnabled: data.scheduledServiceEnabled === true, serviceCloseAt: Number(data.serviceCloseAt) || 0, serviceOpenAt: Number(data.serviceOpenAt) || 0, maintenanceEndAt: Number(data.maintenanceEndAt) || 0, appClosedReopenAt: Number(data.appClosedReopenAt) || 0, scheduledServiceMode: data.scheduledServiceMode === 'closed' ? 'closed' : 'maintenance', dailyScheduleEnabled: data.dailyScheduleEnabled === true, dailyCloseTime: typeof data.dailyCloseTime === 'string' ? data.dailyCloseTime : '', dailyOpenTime: typeof data.dailyOpenTime === 'string' ? data.dailyOpenTime : '', manualMode: mode && ['normal', 'maintenance', 'closed', 'server_error', 'not_found', 'try_again'].includes(mode) ? mode : (legacyMaintenance ? 'maintenance' : 'normal'), serviceModeMessage: typeof data.serviceModeMessage === 'string' && data.serviceModeMessage.trim() ? data.serviceModeMessage : 'We are improving OpenCirkle. Please try again shortly.' })); } catch {}
      const updateConfig = {
        enabled: data.appUpdateEnabled === true,
        url: typeof data.appUpdateUrl === 'string' ? data.appUpdateUrl : '',
        version: typeof data.appUpdateVersion === 'string' ? data.appUpdateVersion : '',
        versionCode: Math.max(0, Number(data.appUpdateVersionCode) || 0),
        notes: typeof data.appUpdateNotes === 'string' ? data.appUpdateNotes : '',
      };
      setAppUpdateConfig(updateConfig);
      try { localStorage.setItem('oc-app-update-cache', JSON.stringify(updateConfig)); } catch {}
      setServiceModeLoaded(true);
    }, (error) => {
      console.warn('Could not read global service mode:', error);
      if (typeof navigator !== 'undefined' && navigator.onLine) {
        setServiceMode('server_error');
        setServiceSchedule((prev: any) => ({ ...prev, manualMode: 'server_error' }));
      }
      setServiceModeLoaded(true);
    });
    return unsubscribe;
  }, []);

  // Evaluate service windows against absolute epoch timestamps; refresh every second for a live countdown.
  useEffect(() => {
    const evaluateSchedule = () => {
      const now = Date.now();
      const enabled = serviceSchedule.scheduledServiceEnabled === true;
      const closeAt = Number(serviceSchedule.serviceCloseAt) || 0;
      const openAt = Number(serviceSchedule.serviceOpenAt) || 0;
      const scheduledMode = serviceSchedule.scheduledServiceMode === 'closed' ? 'closed' : 'maintenance';
      const screenTarget = scheduledMode === 'closed'
        ? (Number(serviceSchedule.appClosedReopenAt) || openAt)
        : (Number(serviceSchedule.maintenanceEndAt) || openAt);
      const valid = enabled && closeAt > 0 && screenTarget > closeAt;
      const updateScheduleState = (nextMode: typeof serviceMode, nextCountdown: number | null) => {
        // Keep the main app tree stable during the per-second clock tick. In normal
        // mode the countdown is not visible, so only publish actual mode changes.
        setServiceMode(previous => previous === nextMode ? previous : nextMode);
        setScheduleCountdownSeconds(previous => {
          const value = nextMode === 'normal' ? null : nextCountdown;
          return previous === value ? previous : value;
        });
      };
      const dailyEnabled = serviceSchedule.dailyScheduleEnabled === true && /^([01]\d|2[0-3]):[0-5]\d$/.test(serviceSchedule.dailyCloseTime || '') && /^([01]\d|2[0-3]):[0-5]\d$/.test(serviceSchedule.dailyOpenTime || '') && serviceSchedule.dailyCloseTime !== serviceSchedule.dailyOpenTime;
      if (dailyEnabled) {
        const [ch, cm] = serviceSchedule.dailyCloseTime.split(':').map(Number);
        const [oh, om] = serviceSchedule.dailyOpenTime.split(':').map(Number);
        const closeMinute = ch * 60 + cm, openMinute = oh * 60 + om;
        const d = new Date(now), currentMinute = d.getHours() * 60 + d.getMinutes();
        const closed = closeMinute < openMinute ? currentMinute >= closeMinute && currentMinute < openMinute : currentMinute >= closeMinute || currentMinute < openMinute;
        const next = new Date(now); next.setSeconds(0, 0);
        const targetMinute = closed ? openMinute : closeMinute;
        next.setHours(Math.floor(targetMinute / 60), targetMinute % 60, 0, 0);
        if (closed && closeMinute >= openMinute && currentMinute >= closeMinute) next.setDate(next.getDate() + 1);
        if (!closed && closeMinute < openMinute && currentMinute >= openMinute) next.setDate(next.getDate() + 1);
        updateScheduleState(closed ? scheduledMode : 'normal', Math.max(0, Math.ceil((next.getTime() - now) / 1000)));
      } else if (valid) {
        const closed = now >= closeAt && now < screenTarget;
        updateScheduleState(closed ? scheduledMode : 'normal', Math.max(0, Math.ceil(((closed ? screenTarget : closeAt) - now) / 1000)));
      } else {
        const manualMode = serviceSchedule.manualMode || 'normal';
        const manualTarget = manualMode === 'closed'
          ? (Number(serviceSchedule.appClosedReopenAt) || openAt)
          : (Number(serviceSchedule.maintenanceEndAt) || openAt);
        const timedManualLock = (manualMode === 'maintenance' || manualMode === 'closed') && manualTarget > 0;
        const manualExpired = timedManualLock && now >= manualTarget;
        updateScheduleState(manualExpired ? 'normal' : manualMode, timedManualLock && !manualExpired
          ? Math.max(0, Math.ceil((manualTarget - now) / 1000)) : null);
      }
      setServiceModeMessage(serviceSchedule.serviceModeMessage || 'We are improving OpenCirkle. Please try again shortly.');
    };
    evaluateSchedule();
    const timer = window.setInterval(evaluateSchedule, 1000);
    return () => window.clearInterval(timer);
  }, [serviceSchedule]);


  // Dynamic App Customization Studio runtime: cached config paints immediately, Firestore keeps it synchronized.
  const [appCustomization, setAppCustomization] = useState<any>(() => {
    try { return JSON.parse(localStorage.getItem('oc-app-customization-cache') || 'null'); } catch { return null; }
  });
  useEffect(() => {
    const ref = doc(db, 'platformSettings', 'global');
    const apply = (raw: any) => {
      if (!raw || raw.schemaVersion !== 1 || raw.status !== 'published') return;
      const c = raw;
      const validColor = (v: any) => typeof v === 'string' && /^#[0-9a-f]{6}$/i.test(v);
      const root = document.documentElement;
      const colors = c.colors || {};
      const vars: Record<string, string> = {
        '--oc-bg': colors.background, '--oc-bg-secondary': colors.secondaryBackground,
        '--oc-surface': colors.surface, '--oc-primary': colors.primary, '--oc-secondary': colors.secondary,
        '--oc-accent': colors.accent, '--oc-header': colors.header, '--oc-footer': colors.footer,
        '--oc-navigation': colors.navigation, '--oc-nav-active': colors.navActive, '--oc-button': colors.button,
        '--oc-button-text': colors.buttonText, '--oc-text': colors.text, '--oc-muted': colors.muted,
        '--oc-border': colors.border, '--oc-icon': colors.icon,
      };
      Object.entries(vars).forEach(([key, value]) => { if (validColor(value)) root.style.setProperty(key, value as string); });
      const font = ['Inter','Roboto','Poppins','Open Sans','system-ui'].includes(c.typography?.fontFamily) ? c.typography.fontFamily : 'system-ui';
      root.style.setProperty('--oc-font-family', `"${font}", system-ui, sans-serif`);
      const base = Number(c.typography?.baseSize);
      if (Number.isFinite(base) && base >= 12 && base <= 20) root.style.setProperty('--oc-base-size', `${base}px`);
      const radius = Number(c.layout?.cardRadius);
      if (Number.isFinite(radius) && radius >= 0 && radius <= 36) root.style.setProperty('--oc-card-radius', `${radius}px`);
      root.dataset.ocNavHidden = c.navigation?.visible === false ? 'true' : 'false';
      root.dataset.ocHeaderHidden = c.header?.visible === false ? 'true' : 'false';
      root.dataset.ocFooterHidden = c.footer?.visible === false ? 'true' : 'false';
      setAppCustomization(c);
      try { localStorage.setItem('oc-app-customization-cache', JSON.stringify(c)); } catch {}
      try { window.dispatchEvent(new CustomEvent('oc-app-customization-updated', { detail: c })); } catch {}
    };
    try { const cached = JSON.parse(localStorage.getItem('oc-app-customization-cache') || 'null'); if (cached) apply(cached); } catch {}
    const unsub = onSnapshot(ref, snap => { const data = snap.exists() ? snap.data() : {}; apply(data.appCustomization); }, err => console.warn('Customization sync unavailable; using last valid cached design.', err));
    return () => unsub();
  }, []);

  const isServiceLocked = serviceMode !== 'normal' && !isAdmin && !isSuperAdmin;

  const [activeTab, setActiveTab] = useState('feed');
  const [themePreference, setThemePreference] = useState<'crystal_dark' | 'moonlight_manor'>(() => {
    try { const saved = localStorage.getItem('oc-theme-preference'); return saved === 'moonlight_manor' || saved === 'crystal_light' ? 'moonlight_manor' : 'crystal_dark'; }
    catch { return 'crystal_dark'; }
  });

  // Apply the selected appearance globally and restore the signed-in user's saved preference.
  useEffect(() => {
    document.documentElement.dataset.ocTheme = themePreference === 'moonlight_manor' ? 'moonlight' : 'dark';
    document.body.dataset.ocTheme = themePreference === 'moonlight_manor' ? 'moonlight' : 'dark';
    try { localStorage.setItem('oc-theme-preference', themePreference); } catch {}
  }, [themePreference]);

  useEffect(() => {
    if (currentUserProfile?.themePreference === 'moonlight_manor' || currentUserProfile?.themePreference === 'crystal_light' || currentUserProfile?.themePreference === 'crystal_dark') {
      setThemePreference(currentUserProfile.themePreference === 'crystal_dark' ? 'crystal_dark' : 'moonlight_manor');
    }
  }, [currentUserProfile?.uid, currentUserProfile?.themePreference]);

  const handleThemePreferenceChange = async (next: 'crystal_dark' | 'moonlight_manor') => {
    setThemePreference(next);
    try { localStorage.setItem('oc-theme-preference', next); } catch {}
    if (currentUserProfile?.uid) {
      try { await updateDoc(doc(db, 'users', currentUserProfile.uid), { themePreference: next }); }
      catch (error) { console.warn('Could not sync appearance preference to profile:', error); }
    }
  };
  // Keep visited sections mounted so switching tabs preserves state and avoids repeated loading.
  const [visitedTabs, setVisitedTabs] = useState<Set<string>>(() => new Set(['feed']));
  const [showSplash, setShowSplash] = useState(true);
  const [foregroundPush, setForegroundPush] = useState<{ title: string; body: string } | null>(null);

  useEffect(() => { const timer = window.setTimeout(() => setShowSplash(false), 450); return () => window.clearTimeout(timer); }, []);

  useEffect(() => {
    let active = true;
    let unsubscribe: (() => void) | undefined;
    void listenForForegroundPush(payload => {
      if (!active) return;
      setForegroundPush({ title: payload.title || 'OpenCirkle update', body: payload.body || 'You have a new notification.' });
      window.setTimeout(() => setForegroundPush(null), 5000);
    }).then(stop => { unsubscribe = stop; if (!active) stop(); }).catch(err => console.warn('Foreground push listener setup failed:', err));
    return () => { active = false; unsubscribe?.(); };
  }, []);
  const [selectedUser, setSelectedUser] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [chatRecipient, setChatRecipient] = useState<UserProfile | null>(null);

  // Keep a lightweight Firestore heartbeat so other profiles can show online status.
  useEffect(() => {
    if (!currentUserProfile?.uid) return;
    const userRef = doc(db, 'users', currentUserProfile.uid);
    const heartbeat = () => {
      if (document.visibilityState === 'visible') {
        updateDoc(userRef, { lastActiveAt: Date.now(), isOnline: currentUserProfile.onlineVisibility !== false && currentUserProfile.showOnlineStatus !== false }).catch((err) =>
          console.warn('Presence update failed:', err)
        );
      }
    };
    heartbeat();
    // Lower write frequency; profile snapshots ignore lastActiveAt-only updates.
    const interval = window.setInterval(heartbeat, 60000);
    const onVisibility = () => heartbeat();
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      window.clearInterval(interval);
      document.removeEventListener('visibilitychange', onVisibility);
      updateDoc(userRef, { lastActiveAt: Date.now(), isOnline: false }).catch(() => {});
    };
  }, [currentUserProfile?.uid]);

  // Modal states
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authDefaultMode, setAuthDefaultMode] = useState<'login' | 'register'>('login');
  const [showComposeModal, setShowComposeModal] = useState(false);

  // Live badge counts
  const [unreadNotifsCount, setUnreadNotifsCount] = useState(0);
  const [unreadMessagesCount, setUnreadMessagesCount] = useState(0);

  // Subscribe to unread notifications count
  useEffect(() => {
    if (!currentUserProfile) {
      setUnreadNotifsCount(0);
      return;
    }
    const unsub = subscribeToNotifications(currentUserProfile.uid, (_, unread) => {
      setUnreadNotifsCount(unread);
    });
    return () => unsub();
  }, [currentUserProfile?.uid]);

  // Subscribe to unread messages count
  useEffect(() => {
    if (!currentUserProfile) {
      setUnreadMessagesCount(0);
      return;
    }
    const unsub = subscribeToConversations(currentUserProfile.uid, (convs) => {
      const totalUnread = convs.reduce((sum, c) => {
        return sum + (c.unreadCount?.[currentUserProfile.uid] || 0);
      }, 0);
      setUnreadMessagesCount(totalUnread);
    });
    return () => unsub();
  }, [currentUserProfile?.uid]);

  // Handle URL hash changes
  useEffect(() => {
    const handleHash = () => {
      const hash = window.location.hash;
      if (hash.startsWith('#user-')) {
        const username = decodeURIComponent(hash.replace('#user-', ''));
        setSelectedUser(username);
        setVisitedTabs((prev) => new Set([...prev, 'profile']));
        setActiveTab('profile');
      } else if (hash.startsWith('#tag-')) {
        const tag = hash.replace('#tag-', '');
        setSearchQuery(`#${tag}`);
        setVisitedTabs((prev) => new Set([...prev, 'explore']));
        setActiveTab('explore');
      } else if (hash.startsWith('#post-') || hash.startsWith('#story-')) {
        setVisitedTabs((prev) => new Set([...prev, 'feed']));
        setActiveTab('feed');
        window.dispatchEvent(new CustomEvent(hash.startsWith('#post-') ? 'opencirkle:open-post' : 'opencirkle:open-story', { detail: { id: decodeURIComponent(hash.slice(hash.indexOf('-') + 1)) } }));
      } else if (hash.startsWith('#messages')) {
        setVisitedTabs((prev) => new Set([...prev, 'messages']));
        setActiveTab('messages');
      }
    };

    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  const handleOpenAuth = (mode: 'login' | 'register' = 'login') => {
    setAuthDefaultMode(mode);
    setShowAuthModal(true);
  };

  const handleUserClick = (username: string) => {
    const cleanUsername = username.trim().replace(/^@/, '');
    if (!cleanUsername) return;
    setSelectedUser(cleanUsername);
    setVisitedTabs((prev) => new Set([...prev, 'profile']));
    setActiveTab('profile');
    // replaceState updates the deep link without causing a second hashchange navigation.
    window.history.replaceState(null, '', `${window.location.pathname}${window.location.search}#user-${encodeURIComponent(cleanUsername)}`);
  };

  const handleHashtagClick = (tag: string) => {
    setSearchQuery(`#${tag}`);
    setVisitedTabs((prev) => new Set([...prev, 'explore']));
    setActiveTab('explore');
    window.location.hash = `#tag-${tag}`;
  };

  const handleStartChat = (user: UserProfile) => {
    if (!currentUserProfile || !user?.uid || user.uid === currentUserProfile.uid) return;
    // Clone the latest profile snapshot so ChatView receives a fresh recipient
    // and reliably opens that person's conversation from the Message button.
    setChatRecipient({ ...user });
    setVisitedTabs((prev) => new Set([...prev, 'messages']));
    setActiveTab('messages');
    window.history.replaceState(null, '', `${window.location.pathname}${window.location.search}#messages`);
  };

  const handleTabChange = (tab: string) => {
    if (tab === 'profile') {
      setSelectedUser(currentUserProfile?.username || null);
    }
    setVisitedTabs((prev) => { const next = new Set(prev); next.add(tab); return next; });
    setActiveTab(tab);
  };

  if (!networkOnline) {
    return (
      <main className="oc-fullscreen-art-screen" aria-label="Network connection error">
        <img src="/network-offline-screen.png" alt="Something went wrong. Try refreshing the page or checking your connection." />
        <button type="button" className="oc-art-hotspot oc-offline-hotspot" onClick={retryOfflineConnection} disabled={offlineRetryBusy} aria-label="Try again">
          <span className="sr-only">{offlineRetryBusy ? 'Checking connection' : 'Try again'}</span>
        </button>
      </main>
    );
  }

  const mustUpdate = updateVersionReady && appUpdateConfig.enabled === true &&
    Number(appUpdateConfig.versionCode) > 0 && installedVersionCode < Number(appUpdateConfig.versionCode);
  if (mustUpdate && appUpdateConfig.url) {
    return (
      <main className="oc-fullscreen-art-screen" aria-label="App update required">
        <img src="/app-update-screen.png" alt={`A new version of OpenCirkle ${appUpdateConfig.version || ''} is available. Update now to continue.`} />
        <button type="button" className="oc-art-hotspot oc-update-hotspot" onClick={() => { window.location.href = appUpdateConfig.url; }} aria-label="Update now">
          <span className="sr-only">Update Now</span>
        </button>
      </main>
    );
  }

  if (!serviceModeLoaded || authLoading || !updateVersionReady) {
    return <div className="min-h-screen bg-[#050A18] text-[#F1F8FF] flex flex-col items-center justify-center gap-5" role="status"><img src="/opencirkle-splash-logo.png" alt="OpenCirkle" className="h-28 w-28 object-contain" /><Dots className="w-18" /></div>;
  }

  if (isServiceLocked && (serviceMode === 'maintenance' || serviceMode === 'closed')) {
    const remaining = Math.max(0, scheduleCountdownSeconds ?? 0);
    const days = Math.floor(remaining / 86400);
    const hours = Math.floor((remaining % 86400) / 3600);
    const minutes = Math.floor((remaining % 3600) / 60);
    const seconds = remaining % 60;
    const pad = (n: number) => String(n).padStart(2, '0');
    const countdown = `${pad(days)} : ${pad(hours)} : ${pad(minutes)} : ${pad(seconds)}`;
    if (serviceMode === 'maintenance') return (
      <main className="oc-service-screen oc-maintenance-screen fixed inset-0 z-[9999] flex min-h-[100dvh] flex-col items-center overflow-y-auto" aria-label="OpenCirkle maintenance">
        <div className="oc-maintenance-art"><img src="/maintenance-hero.jpg" alt="OpenCirkle maintenance illustration" /></div>
        <section className="oc-maintenance-copy w-full text-center">
          <h1>Hang on! We are under maintenance</h1>
          <p>It will not take a long time till we get the issue fixed. We will be live again in</p>
          <div className="oc-maintenance-countdown" role="timer" aria-live="off">{countdown}</div>
          <form className="oc-maintenance-notify" onSubmit={submitMaintenanceNotification}>
            <input type="email" aria-label="Your email" placeholder="Your email..." value={maintenanceEmail} onChange={(e) => setMaintenanceEmail(e.target.value)} autoComplete="email" required disabled={notifyBusy} />
            <button type="submit" disabled={notifyBusy}>{notifyBusy ? 'Saving...' : 'Notify Me'}</button>
          </form>
          {notifyStatus && <p className="oc-maintenance-feedback" role="status">{notifyStatus}</p>}
        </section>
      </main>
    );
    return (
      <main className="oc-service-screen oc-closed-screen fixed inset-0 z-[9999] flex min-h-[100dvh] flex-col items-center overflow-y-auto" aria-label="OpenCirkle app closed">
        <div className="oc-closed-art"><img src="/closed-hero.jpg" alt="OpenCirkle" /></div>
        <section className="oc-closed-copy relative z-10 w-full text-center">
          <h1>App Closed</h1>
          <p className="oc-closed-subtitle">Try Again in...</p>
          <div className="oc-closed-ring" role="timer" aria-live="off" style={{ ['--oc-ring-progress' as any]: `${remaining > 0 ? Math.max(0, Math.min(100, (remaining % 60) / 60 * 100)) : 0}%` }}>
            <span>{pad(hours + days * 24)}:{pad(minutes)}:{pad(seconds)}</span>
          </div>
          <p className="oc-closed-message">Something went wrong.<br />Please try again later.</p>
          <button type="button" onClick={retryServiceCheck} disabled={retryBusy} className="oc-closed-retry">{retryBusy ? 'Checking...' : 'Try Again'}</button>
        </section>
      </main>
    );
  }

  if (isServiceLocked) {
    const screen = serviceMode === 'not_found'
      ? { code: '404', title: 'Page Not Found', body: serviceModeMessage || 'OpenCirkle is temporarily unavailable at this address.' }
      : { code: 'SERVER ERROR', title: 'Service Temporarily Unavailable', body: serviceModeMessage || 'Our servers are having trouble. Please try again shortly.' };
    return <div className="fixed inset-0 z-[9999] flex min-h-[100dvh] items-center justify-center overflow-y-auto bg-[#050A18] px-5 py-10 text-[#F1F8FF]"><section className="w-full max-w-lg rounded-[2rem] border border-[#168BFF]/25 bg-[#07152B]/90 p-8 text-center shadow-2xl"><img src="/opencirkle-splash-logo.png" alt="OpenCirkle" className="mx-auto mb-7 h-20 w-20 object-contain" /><div className="text-3xl font-black text-[#8DDCFF]">{screen.code}</div><h1 className="mt-4 text-2xl font-bold">{screen.title}</h1><p className="mt-4 text-sm leading-7 text-[#A8BCD7]">{screen.body}</p><button onClick={() => window.location.reload()} className="mt-8 rounded-xl bg-gradient-to-r from-[#0D47A1] to-[#168BFF] px-6 py-3 text-sm font-semibold text-white">Try Again</button></section></div>;
  }

  return (
    <div className="oc-app-shell min-h-[100dvh] bg-[#050A18] text-[#F1F8FF] flex flex-col selection:bg-[#168BFF]/30 selection:text-[#8DDCFF]">
      <a href="#main-content" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[130] focus:rounded-lg focus:bg-[#168BFF] focus:px-4 focus:py-2 focus:text-white">Skip to main content</a>
      <NetworkStatus />
      {foregroundPush && <div role="status" className="fixed top-3 left-3 right-3 z-[160] mx-auto max-w-xl rounded-2xl border border-[#8DDCFF]/40 bg-[#071A38]/95 p-4 shadow-2xl backdrop-blur-xl"><p className="text-sm font-bold text-[#F1F8FF]">{foregroundPush.title}</p><p className="mt-1 text-xs leading-5 text-[#A8BCD7]">{foregroundPush.body}</p><button type="button" onClick={() => setForegroundPush(null)} className="mt-2 text-[11px] font-semibold text-[#8DDCFF]">Dismiss</button></div>}
      {showSplash && <div className="oc-splash fixed inset-0 z-[100] flex flex-col items-center justify-center" role="status" aria-label="Loading OpenCirkle" style={{background: appCustomization?.splash?.gradientEnd ? `linear-gradient(135deg, ${appCustomization.splash.background || '#050A18'}, ${appCustomization.splash.gradientEnd})` : (appCustomization?.splash?.background || '#050A18')}}>
        <img src={appCustomization?.branding?.splashLogoUrl || appCustomization?.branding?.fallbackLogoUrl || "/opencirkle-splash-logo.png"} alt="" onError={(e) => { (e.currentTarget as HTMLImageElement).src = '/opencirkle-splash-logo.png'; }} className="mb-6 object-contain max-h-[32vh] max-w-[55vw]" style={{width: `${Math.min(240, Math.max(48, Number(appCustomization?.splash?.logoWidth) || 144))}px`, height: `${Math.min(240, Math.max(48, Number(appCustomization?.splash?.logoHeight) || 144))}px`}} />
        {appCustomization?.splash?.showLoading === false ? null : <Dots className="w-18" />}
      </div>}
      {/* Focused Profile / Chat views use a distraction-free layout. */}
      {activeTab !== 'profile' && activeTab !== 'messages' && <>
      {/* 3-Zone Sticky Top Header */}
      <Header
        onOpenAuth={() => handleOpenAuth('login')}
        onOpenCompose={() => {
          if (!currentUserProfile) handleOpenAuth('login');
          else setShowComposeModal(true);
        }}
        activeTab={activeTab}
        setActiveTab={handleTabChange}
        unreadNotifsCount={unreadNotifsCount}
        unreadMessagesCount={unreadMessagesCount}
      />

      </>}

      {/* Main 3-Column Layout */}
      <div className={`flex-1 w-full mx-auto flex ${activeTab === 'profile' || activeTab === 'messages' ? 'max-w-5xl px-1 sm:px-3' : 'max-w-7xl px-2 sm:px-4 lg:px-8'}`}>
        {/* Left Column: Desktop Navigation Sidebar */}
        {activeTab !== 'profile' && activeTab !== 'messages' && <Sidebar
          activeTab={activeTab}
          setActiveTab={handleTabChange}
          onOpenCompose={() => {
            if (!currentUserProfile) handleOpenAuth('login');
            else setShowComposeModal(true);
          }}
          unreadNotifsCount={unreadNotifsCount}
          unreadMessagesCount={unreadMessagesCount}
        />}

        {/* Center Column: Main Interactive Content Feed */}
        <main id="main-content" tabIndex={-1} className={`flex-1 min-w-0 outline-none ${activeTab === 'profile' || activeTab === 'messages' ? 'px-1 pt-16 pb-4 sm:px-3 sm:pt-16' : 'py-4 sm:py-6 px-1 sm:px-6 pb-28 md:pb-12'}`}>
          {activeTab !== 'profile' && activeTab !== 'messages' && <AnnouncementBanner />}

          <React.Suspense fallback={<div className="flex min-h-[38vh] items-center justify-center" role="status" aria-label="Loading section"><Dots className="w-18" /></div>}>
          <ViewErrorBoundary key="main-views" onRecover={() => { setActiveTab('feed'); setSelectedUser(null); setSearchQuery(''); window.history.replaceState(null, '', window.location.pathname + window.location.search); }}>
          <div className={activeTab === 'feed' ? 'w-full' : 'hidden'} aria-hidden={activeTab !== 'feed'}>
            <FeedView
              onHashtagClick={handleHashtagClick}
              onUserClick={handleUserClick}
              onOpenAuth={() => handleOpenAuth('login')}
            />
          </div>

          {visitedTabs.has('explore') && (
            <div className={activeTab === 'explore' ? 'w-full' : 'hidden'} aria-hidden={activeTab !== 'explore'}>
            <ExploreView
              initialSearch={searchQuery}
              onHashtagClick={handleHashtagClick}
              onUserClick={handleUserClick}
              onOpenAuth={() => handleOpenAuth('login')}
            />
            </div>
          )}

          {visitedTabs.has('notifications') && (
            <div className={activeTab === 'notifications' ? 'w-full' : 'hidden'} aria-hidden={activeTab !== 'notifications'}>
            <NotificationsView
              onUserClick={handleUserClick}
              onOpenAuth={() => handleOpenAuth('login')}
            />
            </div>
          )}

          {visitedTabs.has('messages') && (
            <div className={activeTab === 'messages' ? 'w-full' : 'hidden'} aria-hidden={activeTab !== 'messages'}>
            <ChatView
              key={chatRecipient?.uid || 'conversation-inbox'}
              initialRecipient={chatRecipient}
              onUserClick={handleUserClick}
              onOpenAuth={() => handleOpenAuth('login')}
            />
            </div>
          )}

          {visitedTabs.has('bookmarks') && (
            <div className={activeTab === 'bookmarks' ? 'w-full' : 'hidden'} aria-hidden={activeTab !== 'bookmarks'}>
            <BookmarksView
              onHashtagClick={handleHashtagClick}
              onUserClick={handleUserClick}
              onOpenAuth={() => handleOpenAuth('login')}
            />
            </div>
          )}

          {visitedTabs.has('profile') && (
            <div className={activeTab === 'profile' ? 'w-full' : 'hidden'} aria-hidden={activeTab !== 'profile'}>
            <ProfileView
              targetUsername={selectedUser || currentUserProfile?.username}
              onOpenAuth={() => handleOpenAuth('login')}
              onStartChat={handleStartChat}
              onHashtagClick={handleHashtagClick}
              onUserClick={handleUserClick}
              themePreference={themePreference}
              onThemePreferenceChange={handleThemePreferenceChange}
            />
            </div>
          )}

          {visitedTabs.has('settings') && (
            <div className={activeTab === 'settings' ? 'w-full' : 'hidden'} aria-hidden={activeTab !== 'settings'}>
            <SettingsView onOpenAuth={() => handleOpenAuth('login')} />
            </div>
          )}

          {visitedTabs.has('admin') && <div className={activeTab === 'admin' ? 'w-full' : 'hidden'} aria-hidden={activeTab !== 'admin'}><AdminControlCenter /></div>}
          </ViewErrorBoundary>
          </React.Suspense>
        </main>

        {/* Right Column: Trending & Discovery Panel */}
        {activeTab !== 'profile' && activeTab !== 'messages' && <TrendingSidebar
          onSearch={(term) => {
            setSearchQuery(term);
            setVisitedTabs((prev) => new Set([...prev, 'explore']));
        setActiveTab('explore');
          }}
          onHashtagClick={handleHashtagClick}
          onUserClick={handleUserClick}
          onOpenAuth={() => handleOpenAuth('login')}
        />}
      </div>

      {/* Mobile Bottom Navigation */}
      {!showAuthModal && !showComposeModal && <BottomNav
        activeTab={activeTab}
        setActiveTab={handleTabChange}
        onOpenAuth={() => handleOpenAuth('login')}
        onReturn={() => {
          setSelectedUser(null);
          setChatRecipient(null);
          setActiveTab('feed');
          window.history.replaceState(null, '', window.location.pathname + window.location.search);
        }}
        unreadMessagesCount={unreadMessagesCount}
        onOpenCompose={() => {
          if (!currentUserProfile) handleOpenAuth('login');
          else setShowComposeModal(true);
        }}
      />}

      {/* Floating Compose Modal (iOS Sheet on mobile) */}
      {showComposeModal && currentUserProfile && (
        <div className="fixed inset-0 z-[1200] flex items-start sm:items-center justify-center overflow-y-auto overscroll-contain p-0 sm:p-4 bg-[#031b1b]/90 backdrop-blur-md" style={{ paddingTop: "env(safe-area-inset-top)", paddingBottom: "env(safe-area-inset-bottom)" }}>
          <div className="relative my-auto w-full max-w-2xl">
            <PostComposer
              isModal={true}
              onClose={() => setShowComposeModal(false)}
              onPostCreated={() => {
                setShowComposeModal(false);
                setActiveTab('feed');
              }}
            />
          </div>
        </div>
      )}

      {/* Authentication Modal */}
      <AuthModal
        isOpen={showAuthModal}
        defaultMode={authDefaultMode}
        onClose={() => setShowAuthModal(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <MainLayout />
    </AuthProvider>
  );
}
