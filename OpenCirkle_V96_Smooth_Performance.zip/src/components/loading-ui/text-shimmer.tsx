import React, { memo, useMemo } from 'react';
import { motion } from 'motion/react';

type TextShimmerProps = {
  children: string;
  className?: string;
  duration?: number;
  spread?: number;
  baseColor?: string;
  shimmerColor?: string;
};

function TextShimmerComponent({
  children,
  className = '',
  duration = 2,
  spread = 2,
  baseColor,
  shimmerColor,
}: TextShimmerProps) {
  const dynamicSpread = useMemo(() => children.length * spread, [children, spread]);

  return (
    <motion.span
      className={`relative inline-block bg-clip-text [background-repeat:no-repeat,padding-box] [background-size:250%_100%,auto] [-webkit-text-fill-color:transparent] ${className}`}
      initial={{ backgroundPosition: '100% center' }}
      animate={{ backgroundPosition: '0% center' }}
      transition={{ repeat: Infinity, duration, ease: 'linear' }}
      style={{
        '--spread': `${dynamicSpread}px`,
        '--base-color': baseColor ?? 'color-mix(in oklab, currentColor 55%, transparent)',
        '--base-gradient-color': shimmerColor ?? 'currentColor',
        backgroundImage: 'linear-gradient(90deg, transparent calc(50% - var(--spread)), var(--base-gradient-color), transparent calc(50% + var(--spread))), linear-gradient(var(--base-color), var(--base-color))',
      } as React.CSSProperties}
    >
      {children}
    </motion.span>
  );
}

export const TextShimmer = memo(TextShimmerComponent);
