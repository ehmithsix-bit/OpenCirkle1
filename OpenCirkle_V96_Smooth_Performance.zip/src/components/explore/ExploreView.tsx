import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Post, UserProfile } from '../../types';
import type { QueryDocumentSnapshot } from 'firebase/firestore';
import { searchPosts, fetchPostsByHashtag, fetchPostsFeed } from '../../services/postService';
import { fetchExploreUsers, fetchFollowingIds, toggleFollowUser } from '../../services/socialService';
import { PostCard } from '../post/PostCard';
import { CrystalAvatar } from '../common/CrystalAvatar';
import { Search, Hash, Users, Sparkles, X } from 'lucide-react';
import { VerifiedBadge } from '../common/VerifiedBadge';
import { TextShimmer } from '../loading-ui/text-shimmer';

interface ExploreViewProps {
  initialSearch?: string;
  onHashtagClick: (tag: string) => void;
  onUserClick: (username: string) => void;
  onOpenAuth: () => void;
}

export const ExploreView: React.FC<ExploreViewProps> = ({
  initialSearch = '',
  onHashtagClick,
  onUserClick,
  onOpenAuth,
}) => {
  const { currentUserProfile } = useAuth();
  const [searchTerm, setSearchTerm] = useState(initialSearch);
  const [activeTab, setActiveTab] = useState<'all' | 'posts' | 'people' | 'tags'>('all');
  const [postResults, setPostResults] = useState<Post[]>([]);
  const [userResults, setUserResults] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(false);
  const [followingMap, setFollowingMap] = useState<Record<string, boolean>>({});
  const [followBusyMap, setFollowBusyMap] = useState<Record<string, boolean>>({});
  const [followingIdsState, setFollowingIdsState] = useState<string[]>([]);
  const [userCursor, setUserCursor] = useState<QueryDocumentSnapshot | null>(null);
  const [hasMoreUsers, setHasMoreUsers] = useState(false);
  const [loadingMoreUsers, setLoadingMoreUsers] = useState(false);

  useEffect(() => {
    if (initialSearch) {
      setSearchTerm(initialSearch);
    }
  }, [initialSearch]);

  useEffect(() => {
    let active = true;
    const executeSearch = async () => {
      const clean = searchTerm.trim();
      const normalized = clean.replace(/^@/, '').replace(/^#/, '').trim().toLowerCase();
      setLoading(true);
      setUserCursor(null);
      setHasMoreUsers(false);
      try {
        const shouldLoadUsers = activeTab === 'people' || activeTab === 'all' || !clean;
        // Following IDs and the first people page are independent reads; start
        // both together so Explore does not wait for one network round-trip first.
        const [followingIds, userPage] = await Promise.all([
          currentUserProfile?.uid ? fetchFollowingIds(currentUserProfile.uid) : Promise.resolve([] as string[]),
          shouldLoadUsers ? fetchExploreUsers(currentUserProfile?.uid, 50) : Promise.resolve(null),
        ]);
        if (!active) return;
        setFollowingIdsState(followingIds);

        let validUsers: UserProfile[] = [];
        if (userPage) {
          validUsers = userPage.users.filter((u) => {
            if (!normalized) return true;
            return u.username.toLowerCase().includes(normalized) ||
              u.displayName.toLowerCase().includes(normalized) ||
              u.uid.toLowerCase() === normalized;
          });
          if (active) {
            setUserCursor(userPage.lastDoc);
            setHasMoreUsers(userPage.hasMore);
          }
        }

        let posts: Post[] = [];
        if (activeTab !== 'people' && currentUserProfile?.uid && followingIds.length) {
          if (clean && clean.startsWith('@')) {
            posts = [];
          } else if (clean) {
            const foundPosts = clean.startsWith('#')
              ? await fetchPostsByHashtag(normalized, 100)
              : await searchPosts(clean);
            const followedSet = new Set(followingIds);
            posts = foundPosts.filter((post) =>
              Boolean(post.authorId) &&
              followedSet.has(post.authorId) &&
              post.privacy !== 'private' &&
              (!post.scheduledAt || post.scheduledAt <= Date.now())
            );
          } else {
            // Explore Posts shows recent public posts from every followed account.
            // Firestore 'in' queries accept at most 30 IDs, so split the list and merge.
            const chunks: string[][] = [];
            for (let i = 0; i < followingIds.length; i += 30) {
              chunks.push(followingIds.slice(i, i + 30));
            }
            const pages = await Promise.all(chunks.map((ids) =>
              fetchPostsFeed({ feedType: 'following', followedUserIds: ids, pageSize: 50 })
            ));
            const unique = new Map<string, Post>();
            pages.flatMap((page) => page.posts).forEach((post) => {
              if (post.id && (!post.scheduledAt || post.scheduledAt <= Date.now())) {
                unique.set(post.id, post);
              }
            });
            posts = Array.from(unique.values()).sort((a, b) => b.createdAt - a.createdAt);
          }
        }

        if (active) {
          setPostResults(posts);
          setUserResults(validUsers);
          const nextMap: Record<string, boolean> = {};
          validUsers.forEach((u) => { nextMap[u.uid] = followingIds.includes(u.uid); });
          setFollowingMap(nextMap);
        }
      } catch (err) {
        console.error('Explore search error:', err);
        if (active) {
          setPostResults([]);
          setUserResults([]);
          setHasMoreUsers(false);
        }
      } finally {
        if (active) setLoading(false);
      }
    };

    const timer = setTimeout(executeSearch, 300);
    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [searchTerm, currentUserProfile?.uid, activeTab]);

  const loadMoreUsers = async () => {
    if (loadingMoreUsers || !hasMoreUsers || !userCursor) return;
    setLoadingMoreUsers(true);
    try {
      const page = await fetchExploreUsers(currentUserProfile?.uid, 50, userCursor);
      const clean = searchTerm.trim();
      const normalized = clean.replace(/^@/, '').replace(/^#/, '').trim().toLowerCase();
      const matchingUsers = page.users.filter((u) => {
        if (!normalized) return true;
        return u.username.toLowerCase().includes(normalized) ||
          u.displayName.toLowerCase().includes(normalized) ||
          u.uid.toLowerCase() === normalized;
      });
      setUserResults((prev) => {
        const seen = new Set(prev.map((u) => u.uid));
        return [...prev, ...matchingUsers.filter((u) => !seen.has(u.uid))];
      });
      setUserCursor(page.lastDoc);
      setHasMoreUsers(page.hasMore);
      setFollowingMap((prev) => {
        const next = { ...prev };
        matchingUsers.forEach((u) => { next[u.uid] = followingIdsState.includes(u.uid); });
        return next;
      });
    } catch (error) {
      console.error('Could not load more Explore users:', error);
    } finally {
      setLoadingMoreUsers(false);
    }
  };

  const handleFollowToggle = async (targetUser: UserProfile) => {
    if (!currentUserProfile) {
      onOpenAuth();
      return;
    }

    if (followBusyMap[targetUser.uid]) return;
    const wasFollowing = Boolean(followingMap[targetUser.uid]);
    setFollowBusyMap(prev => ({ ...prev, [targetUser.uid]: true }));
    setFollowingMap(prev => ({ ...prev, [targetUser.uid]: !wasFollowing }));
    try {
      const res = await toggleFollowUser(currentUserProfile, targetUser);
      setFollowingMap(prev => ({ ...prev, [targetUser.uid]: res.status === 'following' || res.status === 'requested' }));
    } catch (err) {
      setFollowingMap(prev => ({ ...prev, [targetUser.uid]: wasFollowing }));
      console.error('Follow error:', err);
    } finally {
      setFollowBusyMap(prev => ({ ...prev, [targetUser.uid]: false }));
    }
  };

  const trendingTags = [
    'OpenCirkle',
    'Cryptography',
    'Philosophy',
    'TextOnly',
    'DigitalMinimalism',
    'NetworkTheory',
    'Mathematics',
  ];

  return (
    <div className="max-w-2xl w-full mx-auto pb-16">
      {/* Search Header */}
      <div className="relative mb-5">
        <Search className="w-4 h-4 text-[#A8BCD7] absolute left-4 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search topics, #tags, or @thinkers..."
          className="w-full bg-[#071A38]/70 border border-[#168BFF]/25 rounded-2xl pl-11 pr-10 py-3 text-sm text-[#F1F8FF] placeholder-[#A8BCD7]/50 focus:outline-none focus:border-[#168BFF] focus:ring-1 focus:ring-[#168BFF] transition-all"
        />
        {searchTerm && (
          <button
            onClick={() => setSearchTerm('')}
            className="absolute right-3.5 top-1/2 -translate-y-1/2 p-1 text-[#A8BCD7] hover:text-[#F1F8FF]"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Quick Hashtags Strip */}
      <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-4 scrollbar-none">
        {trendingTags.map((t) => (
          <button
            key={t}
            onClick={() => {
              setSearchTerm(`#${t}`);
              onHashtagClick(t);
            }}
            className="text-xs font-mono px-3 py-1.5 rounded-xl bg-[#071A38]/80 text-[#8DDCFF] hover:bg-[#0D47A1]/50 border border-[#168BFF]/20 transition-all shrink-0 active:scale-95"
          >
            #{t}
          </button>
        ))}
      </div>

      {/* Category Tabs: iOS Rounded Liquid Glass Pill */}
      <div className="flex items-center gap-1.5 p-1 rounded-full ios-liquid-glass-subtle border border-[#8DDCFF]/20 mb-6">
        {[
          { id: 'all', label: 'All Results' },
          { id: 'posts', label: `Posts (${postResults.length})` },
          { id: 'people', label: `People (${userResults.length})` },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex-1 py-1.5 px-3 text-xs font-semibold rounded-full ios-press transition-all ${
              activeTab === tab.id
                ? 'bg-gradient-to-r from-[#0D47A1] to-[#168BFF] text-white shadow-[0_0_15px_rgba(22,139,255,0.4)] border border-[#8DDCFF]/30'
                : 'text-[#A8BCD7] hover:text-[#F1F8FF]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Results rendering */}
      {loading ? (
        <div className="py-12 text-center text-sm font-mono text-[#8DDCFF]" role="status" aria-label="Loading">
          <TextShimmer duration={2} spread={2} className="font-semibold tracking-[0.18em]">loading</TextShimmer>
        </div>
      ) : (
        <div className="space-y-6">
          {/* People Section */}
          {(activeTab === 'all' || activeTab === 'people') && (userResults.length > 0 || hasMoreUsers) && (
            <div className="rounded-3xl ios-liquid-glass p-5 border border-[#8DDCFF]/20 space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-[#8DDCFF] uppercase tracking-wider mb-2">
                <Users className="w-4 h-4 text-[#168BFF]" />
                <span>Discourse Thinkers</span>
              </div>

              <div className="divide-y divide-[#168BFF]/10">
                {userResults.map((user) => {
                  const isFollowed = followingMap[user.uid];
                  return (
                    <div
                      key={user.uid}
                      className="py-3 first:pt-0 last:pb-0 flex items-center justify-between gap-3"
                    >
                      <button
                        onClick={() => onUserClick(user.username.trim())}
                        className="flex items-center gap-3 text-left group min-w-0"
                      >
                        <CrystalAvatar
                          displayName={user.displayName}
                          username={user.username}
                          avatarSymbol={user.avatarSymbol}
                          avatarUrl={user.avatarUrl}
                          avatarColor={user.avatarColor}
                          size="md"
                        />
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="text-sm font-semibold text-[#F1F8FF] group-hover:text-[#8DDCFF] transition-colors truncate">
                              {user.displayName}
                            </span>
                            {user.verified && (
                              <VerifiedBadge size="sm" title="Verified account" placement="displayName" className="align-middle" />
                            )}
                          </div>
                          <span className="text-xs font-mono text-[#A8BCD7] truncate block">
                            @{user.username.trim()}
                          </span>
                          {user.bio && (
                            <p className="text-xs text-[#A8BCD7]/80 line-clamp-1 mt-0.5">
                              {user.bio}
                            </p>
                          )}
                        </div>
                      </button>

                      {currentUserProfile?.uid !== user.uid && (
                        <button
                          onClick={() => handleFollowToggle(user)}
                          disabled={Boolean(followBusyMap[user.uid])}
                          className={`px-4 py-1.5 text-xs font-semibold rounded-xl transition-all shrink-0 ${
                            isFollowed
                              ? 'bg-[#071A38] text-[#8DDCFF] border border-[#168BFF]/30'
                              : 'bg-gradient-to-r from-[#0D47A1] to-[#168BFF] text-white shadow-[0_0_12px_rgba(22,139,255,0.3)]'
                          }`}
                        >
                          {followBusyMap[user.uid] ? 'Please wait…' : isFollowed ? 'Following' : 'Connect'}
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
              {hasMoreUsers && (
                <button
                  type="button"
                  onClick={loadMoreUsers}
                  disabled={loadingMoreUsers}
                  className="w-full mt-3 py-2.5 rounded-xl border border-[#168BFF]/25 text-xs font-semibold text-[#8DDCFF] hover:bg-[#0D47A1]/20 disabled:opacity-50 transition-all"
                >
                  {loadingMoreUsers ? 'Loading users…' : 'Load more users'}
                </button>
              )}
            </div>
          )}

          {/* Posts Section */}
          {(activeTab === 'all' || activeTab === 'posts') && (
            <div className="space-y-4">
              {postResults.length === 0 ? (
                <div className="rounded-3xl ios-liquid-glass p-8 text-center text-xs text-[#A8BCD7] border border-[#168BFF]/15">
                  {currentUserProfile ? `No matching posts from people you follow${searchTerm ? ` for "${searchTerm}"` : ""}.` : "Sign in and follow accounts to see their posts here."}
                </div>
              ) : (
                postResults.map((post, idx) => (
                  <PostCard
                    key={`explore-post-${post.id || 'p'}-${idx}`}
                    post={post}
                    onHashtagClick={onHashtagClick}
                    onUserClick={onUserClick}
                    onOpenAuth={onOpenAuth}
                  />
                ))
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
