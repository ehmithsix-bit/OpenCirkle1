import React, { useEffect, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import { PushNotifications } from '@capacitor/push-notifications';
import { BellRing, MessageCircle, Newspaper, CircleDot, Radio, CheckCircle2, AlertCircle, Loader2, Heart, MessageSquare, UserPlus, Eye } from 'lucide-react';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useAuth } from '../../context/AuthContext';
import { DEFAULT_PUSH_PREFERENCES, disablePushNotifications, enablePushNotifications, PushPreferences } from '../../services/pushNotificationService';

const rows: { key: keyof PushPreferences; label: string; description: string; icon: React.ElementType }[] = [
  { key: 'messages', label: 'Direct messages', description: 'নতুন মেসেজ এলে ফোনে নোটিফিকেশন', icon: MessageCircle },
  { key: 'posts', label: 'New posts', description: 'যাদের ফলো করো তাদের নতুন পোস্ট', icon: Newspaper },
  { key: 'stories', label: 'New stories', description: 'ফলো করা অ্যাকাউন্টের নতুন Story', icon: CircleDot },
  { key: 'online', label: 'Online alerts', description: 'সমর্থিত হলে বন্ধু অনলাইনে এলে', icon: Radio },
  { key: 'likes', label: 'Likes', description: 'তোমার পোস্টে Like এলে', icon: Heart },
  { key: 'comments', label: 'Comments and replies', description: 'পোস্টে comment বা reply এলে', icon: MessageSquare },
  { key: 'follows', label: 'New followers', description: 'কেউ তোমাকে follow করলে', icon: UserPlus },
];

export const PushNotificationSettings: React.FC = () => {
  const { currentUserProfile } = useAuth();
  const [prefs, setPrefs] = useState<PushPreferences>(DEFAULT_PUSH_PREFERENCES);
  const [permission, setPermission] = useState<NotificationPermission | 'unsupported'>(() => Capacitor.isNativePlatform() ? 'default' : typeof Notification === 'undefined' ? 'unsupported' : Notification.permission);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const [onlineVisibility, setOnlineVisibility] = useState(true);

  useEffect(() => {
    if (!currentUserProfile?.uid) return;
    getDoc(doc(db, 'users', currentUserProfile.uid)).then(snap => {
      const saved = snap.data()?.pushPreferences;
      if (saved) setPrefs({ ...DEFAULT_PUSH_PREFERENCES, ...saved });
      setOnlineVisibility(snap.data()?.onlineVisibility !== false && snap.data()?.showOnlineStatus !== false);
    }).catch(() => {});
  }, [currentUserProfile?.uid]);

  if (!currentUserProfile) return null;

  const enable = async () => {
    setBusy(true); setError(''); setNotice('');
    try {
      await enablePushNotifications(currentUserProfile.uid);
      setPermission('granted');
      await updateDoc(doc(db, 'users', currentUserProfile.uid), { pushPreferences: prefs, pushNotificationsEnabled: true });
      setNotice('Push notification চালু হয়েছে। এখন অ্যাপের বাইরে থাকলেও সমর্থিত ডিভাইসে নোটিফিকেশন আসবে।');
    } catch (e: any) {
      setError(e?.message || 'Notification চালু করা যায়নি।');
      if (Capacitor.isNativePlatform()) { const p = await PushNotifications.checkPermissions().catch(() => ({ receive: 'prompt' as const })); setPermission(p.receive === 'granted' ? 'granted' : p.receive === 'denied' ? 'denied' : 'default'); } else if (typeof Notification !== 'undefined') setPermission(Notification.permission);
    } finally { setBusy(false); }
  };

  const disable = async () => {
    setBusy(true); setError(''); setNotice('');
    try {
      await disablePushNotifications(currentUserProfile.uid);
      await updateDoc(doc(db, 'users', currentUserProfile.uid), { pushNotificationsEnabled: false });
      setNotice('OpenCirkle push notification বন্ধ করা হয়েছে।');
    } catch (e: any) { setError(e?.message || 'Notification বন্ধ করা যায়নি।'); }
    finally { setBusy(false); }
  };

  const changeOnlineVisibility = async (value: boolean) => {
    setOnlineVisibility(value); setError('');
    try { await updateDoc(doc(db, 'users', currentUserProfile.uid), { onlineVisibility: value, showOnlineStatus: value, ...(value ? {} : { isOnline: false, lastActiveAt: Date.now() }) }); }
    catch (e: any) { setOnlineVisibility(!value); setError(e?.message || 'Online visibility save করা যায়নি।'); }
  };

  const changePreference = async (key: keyof PushPreferences, value: boolean) => {
    const next = { ...prefs, [key]: value };
    setPrefs(next); setError('');
    try { await updateDoc(doc(db, 'users', currentUserProfile.uid), { pushPreferences: next }); }
    catch (e: any) { setPrefs(prefs); setError(e?.message || 'Preference save করা যায়নি।'); }
  };

  return <section className="rounded-3xl ios-liquid-glass p-5 border border-[#8DDCFF]/20 space-y-4">
    <div className="flex items-start gap-3">
      <div className="rounded-xl bg-[#168BFF]/15 p-2.5"><BellRing className="w-5 h-5 text-[#8DDCFF]" /></div>
      <div className="min-w-0 flex-1"><h3 className="text-sm font-bold text-[#F1F8FF]">Push Notifications</h3><p className="mt-1 text-[11px] leading-5 text-[#A8BCD7]">অ্যাপ খোলা না থাকলেও ফোনের notification bar-এ আপডেট পেতে চালু করো।</p></div>
    </div>
    <div className="flex items-center justify-between gap-3 rounded-2xl border border-[#168BFF]/20 bg-[#071A38]/60 p-3">
      <div className="min-w-0"><p className="text-xs font-semibold text-[#F1F8FF]">Device permission</p><p className="text-[11px] text-[#A8BCD7]">{permission === 'granted' ? 'Allowed on this device' : permission === 'denied' ? 'Blocked in device settings' : permission === 'unsupported' ? 'Not supported on this device' : 'Not enabled yet'}</p></div>
      {permission === 'granted' ? <CheckCircle2 className="w-5 h-5 text-[#8DDCFF] shrink-0" /> : <button disabled={busy || permission === 'denied' || permission === 'unsupported'} onClick={enable} className="shrink-0 rounded-xl bg-gradient-to-r from-[#0D47A1] to-[#168BFF] px-4 py-2 text-xs font-bold text-white disabled:opacity-50">{busy ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Allow'}</button>}
    </div>
    {permission === 'denied' && <p className="text-[11px] text-amber-200">Browser settings থেকে OpenCirkle-এর Notifications permission Allow করতে হবে।</p>}
    <div className="space-y-1">
      {rows.map(({ key, label, description, icon: Icon }) => <div key={key} className="flex items-center gap-3 py-3 border-b last:border-b-0 border-[#168BFF]/10">
        <Icon className="w-4 h-4 text-[#8DDCFF] shrink-0" />
        <div className="flex-1 min-w-0"><p className="text-xs font-semibold text-[#F1F8FF]">{label}</p><p className="text-[10px] text-[#A8BCD7] mt-0.5">{description}</p></div>
        <button type="button" role="switch" aria-checked={prefs[key]} onClick={() => changePreference(key, !prefs[key])} className={`relative h-6 w-11 shrink-0 rounded-full border transition-colors ${prefs[key] ? 'bg-[#168BFF] border-[#8DDCFF]/70' : 'bg-[#071A38] border-[#168BFF]/30'}`}><span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-transform ${prefs[key] ? 'translate-x-[22px]' : 'translate-x-0.5'}`} /></button>
      </div>)}
    </div>
    <div className="flex items-center gap-3 py-3 border-b border-[#168BFF]/10"><Eye className="w-4 h-4 text-[#8DDCFF] shrink-0" /><div className="flex-1 min-w-0"><p className="text-xs font-semibold text-[#F1F8FF]">Show my online status</p><p className="text-[10px] text-[#A8BCD7] mt-0.5">অন্যরা তোমাকে online দেখতে পারবে কি না</p></div><button type="button" role="switch" aria-checked={onlineVisibility} onClick={() => changeOnlineVisibility(!onlineVisibility)} className={`relative h-6 w-11 shrink-0 rounded-full border transition-colors ${onlineVisibility ? 'bg-[#168BFF] border-[#8DDCFF]/70' : 'bg-[#071A38] border-[#168BFF]/30'}`}><span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-transform ${onlineVisibility ? 'translate-x-[22px]' : 'translate-x-0.5'}`} /></button></div>
    {notice && <p role="status" className="rounded-xl border border-[#8DDCFF]/30 bg-[#168BFF]/10 p-3 text-[11px] text-[#8DDCFF]">{notice}</p>}
    {error && <p role="alert" className="flex gap-2 rounded-xl border border-[#FF6B6B]/30 bg-[#FF6B6B]/10 p-3 text-[11px] text-[#FFB4B4]"><AlertCircle className="w-4 h-4 shrink-0" />{error}</p>}
    {permission === 'granted' && <button disabled={busy} onClick={disable} className="w-full rounded-xl border border-[#168BFF]/30 px-4 py-2.5 text-xs font-semibold text-[#A8BCD7] disabled:opacity-50">Turn off push notifications</button>}
    <p className="text-[10px] leading-4 text-[#7F9BBF]">নোট: Android-এ native FCM token এবং Firebase Functions deploy থাকতে হবে। App foreground-এ থাকলে in-app event পাওয়া যায়; background notification Android system tray-তে দেখাতে Functions-এর notification payload প্রয়োজন।</p>
  </section>;
};
