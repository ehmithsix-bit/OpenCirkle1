import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  updateUserProfile,
  resendVerificationEmail,
  deactivateAccount,
  deleteUserAccount,
  toggleBlockUser,
} from '../../services/authService';
import { PushNotificationSettings } from './PushNotificationSettings';
import {
  Settings,
  Shield,
  Lock,
  Globe,
  Bell,
  EyeOff,
  UserX,
  AlertTriangle,
  Mail,
  CheckCircle2,
  Trash2,
  AlertCircle,
} from 'lucide-react';

interface SettingsViewProps {
  onOpenAuth: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onOpenAuth }) => {
  const { currentUserProfile, firebaseUser, refreshProfile } = useAuth();

  const [isPrivate, setIsPrivate] = useState(Boolean(currentUserProfile?.isPrivate));
  const [newMutedWord, setNewMutedWord] = useState('');
  const [mutedWords, setMutedWords] = useState<string[]>(currentUserProfile?.mutedWords || []);
  const [blockedUsers, setBlockedUsers] = useState<string[]>(currentUserProfile?.blockedUsers || []);
  const [verificationSent, setVerificationSent] = useState(false);
  const [savingNotice, setSavingNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!currentUserProfile) {
    return (
      <div className="crystal-card max-w-md mx-auto rounded-2xl p-8 text-center border border-[#168BFF]/20 space-y-3">
        <Settings className="w-12 h-12 text-[#168BFF] mx-auto" />
        <h3 className="text-base font-bold text-[#F1F8FF]">Settings & Security</h3>
        <p className="text-xs text-[#A8BCD7]">Sign in to access your security parameters.</p>
        <button
          onClick={onOpenAuth}
          className="px-6 py-2.5 text-xs font-semibold text-white bg-gradient-to-r from-[#0D47A1] to-[#168BFF] rounded-xl shadow-[0_0_15px_rgba(22,139,255,0.4)]"
        >
          Sign In
        </button>
      </div>
    );
  }

  const handlePrivacyToggle = async () => {
    const nextState = !isPrivate;
    setIsPrivate(nextState);
    try {
      await updateUserProfile(currentUserProfile.uid, { isPrivate: nextState });
      await refreshProfile();
      setSavingNotice(`Account privacy updated to ${nextState ? 'Private' : 'Public'}.`);
      setTimeout(() => setSavingNotice(null), 3000);
    } catch (err: any) {
      setError(err?.message || 'Failed to update privacy.');
    }
  };

  const handleAddMutedWord = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = newMutedWord.trim().toLowerCase();
    if (!clean || mutedWords.includes(clean)) return;

    const next = [...mutedWords, clean];
    setMutedWords(next);
    setNewMutedWord('');
    try {
      await updateUserProfile(currentUserProfile.uid, { mutedWords: next });
      await refreshProfile();
    } catch (err: any) {
      setError(err?.message || 'Failed to add muted word.');
    }
  };

  const handleRemoveMutedWord = async (word: string) => {
    const next = mutedWords.filter((w) => w !== word);
    setMutedWords(next);
    try {
      await updateUserProfile(currentUserProfile.uid, { mutedWords: next });
      await refreshProfile();
    } catch (err: any) {
      setError(err?.message || 'Failed to remove muted word.');
    }
  };

  const handleUnblockUser = async (targetUid: string) => {
    try {
      await toggleBlockUser(currentUserProfile.uid, targetUid);
      setBlockedUsers((prev) => prev.filter((id) => id !== targetUid));
      await refreshProfile();
    } catch (err) {
      console.error('Error unblocking:', err);
    }
  };

  const handleResendVerification = async () => {
    try {
      await resendVerificationEmail();
      setVerificationSent(true);
      setTimeout(() => setVerificationSent(false), 5000);
    } catch (err: any) {
      setError(err?.message || 'Failed to resend verification email.');
    }
  };

  const handleDeactivate = async () => {
    const confirm = window.confirm(
      'Are you sure you want to deactivate your node? You can log back in at any time.'
    );
    if (!confirm) return;

    try {
      await deactivateAccount(currentUserProfile.uid);
    } catch (err: any) {
      setError(err?.message || 'Failed to deactivate account.');
    }
  };

  const handleDelete = async () => {
    const confirm = window.confirm(
      'CRITICAL WARNING: This will permanently delete your account and release your username. This action cannot be reversed.'
    );
    if (!confirm) return;

    try {
      await deleteUserAccount(currentUserProfile.uid);
    } catch (err: any) {
      setError(err?.message || 'Failed to delete account.');
    }
  };

  return (
    <div className="max-w-2xl w-full mx-auto pb-16 space-y-6">
      <div className="flex items-center gap-2 pb-3 border-b border-[#168BFF]/15">
        <Shield className="w-5 h-5 text-[#8DDCFF]" />
        <div>
          <h2 className="text-base font-bold text-[#F1F8FF]">Crystalline Security & Preferences</h2>
          <p className="text-xs text-[#A8BCD7]">Configure privacy, identity protocols, and account safety</p>
        </div>
      </div>

      {savingNotice && (
        <div className="p-3 rounded-xl bg-[#168BFF]/20 border border-[#168BFF]/40 text-xs text-[#8DDCFF] font-medium text-center">
          {savingNotice}
        </div>
      )}

      {error && (
        <div className="p-3 rounded-xl bg-[#FF6B6B]/15 border border-[#FF6B6B]/30 text-xs text-[#FF6B6B] flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Account Verification Status */}
      <div className="rounded-3xl ios-liquid-glass p-5 border border-[#8DDCFF]/20 space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold text-[#8DDCFF] uppercase tracking-wider">
          <Mail className="w-4 h-4" />
          <span>Email Verification Status</span>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs text-[#F1F8FF] font-medium">{firebaseUser?.email}</p>
            <p className="text-[11px] text-[#A8BCD7]">
              {firebaseUser?.emailVerified
                ? 'Your email is cryptographically verified.'
                : 'Email is pending confirmation.'}
            </p>
          </div>

          {firebaseUser?.emailVerified ? (
            <span className="flex items-center gap-1 text-xs font-semibold text-[#8DDCFF]">
              <CheckCircle2 className="w-4 h-4" />
              <span>Verified</span>
            </span>
          ) : (
            <button
              onClick={handleResendVerification}
              disabled={verificationSent}
              className="px-3.5 py-1.5 text-xs font-semibold text-[#8DDCFF] bg-[#071A38] hover:bg-[#0D47A1]/40 border border-[#168BFF]/30 rounded-xl transition-all"
            >
              {verificationSent ? 'Link Sent!' : 'Resend Link'}
            </button>
          )}
        </div>
      </div>

      {/* Push Notifications: browser permission + per-event preferences */}
      <PushNotificationSettings />

      {/* Bangladesh regional settings: English interface, local currency and time zone */}
      <div className="rounded-3xl ios-liquid-glass p-5 border border-[#8DDCFF]/20 space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold text-[#8DDCFF] uppercase tracking-wider">
          <Globe className="w-4 h-4" />
          <span>Regional Preferences</span>
        </div>
        <p className="text-xs text-[#A8BCD7]">OpenCirkle keeps its interface in English and uses Bangladesh-local formats for payment and time displays.</p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          <div className="rounded-xl bg-[#071A38]/70 border border-white/5 p-3"><p className="text-[10px] text-[#A8BCD7]">Interface language</p><p className="text-sm font-semibold text-white">English</p></div>
          <div className="rounded-xl bg-[#071A38]/70 border border-white/5 p-3"><p className="text-[10px] text-[#A8BCD7]">Currency</p><p className="text-sm font-semibold text-white">BDT (৳)</p></div>
          <div className="rounded-xl bg-[#071A38]/70 border border-white/5 p-3"><p className="text-[10px] text-[#A8BCD7]">Time zone</p><p className="text-sm font-semibold text-white">Dhaka (UTC+6)</p></div>
        </div>
        <p className="text-[11px] text-[#A8BCD7]">Supported local payout methods: bKash and Nagad. Transfers are reviewed by the OpenCirkle admin team; this setting does not create automatic payments.</p>
      </div>

      {/* Privacy Control */}
      <div className="rounded-3xl ios-liquid-glass p-5 border border-[#8DDCFF]/20 space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold text-[#8DDCFF] uppercase tracking-wider">
          <Lock className="w-4 h-4" />
          <span>Node Privacy Protocol</span>
        </div>

        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <p className="text-xs font-semibold text-[#F1F8FF]">
              {isPrivate ? 'Private Node Active' : 'Public Node Active'}
            </p>
            <p className="text-[11px] text-[#A8BCD7]">
              {isPrivate
                ? 'Followers must be manually accepted by you.'
                : 'Anyone in OpenCirkle can view your reflections.'}
            </p>
          </div>

          <button
            onClick={handlePrivacyToggle}
            className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ios-press ${
              isPrivate ? 'bg-[#168BFF]' : 'bg-[#071A38] border border-[#168BFF]/30'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white transition-transform ${
                isPrivate ? 'translate-x-6' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Muted Words */}
      <div className="rounded-3xl ios-liquid-glass p-5 border border-[#8DDCFF]/20 space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold text-[#8DDCFF] uppercase tracking-wider">
          <EyeOff className="w-4 h-4" />
          <span>Muted Vocabulary & Phrases</span>
        </div>
        <p className="text-[11px] text-[#A8BCD7]">
          Discourses containing these words will be muted from your home feed.
        </p>

        <form onSubmit={handleAddMutedWord} className="flex gap-2">
          <input
            type="text"
            value={newMutedWord}
            onChange={(e) => setNewMutedWord(e.target.value)}
            placeholder="Add word to mute..."
            className="flex-1 bg-[#050A18] border border-[#168BFF]/25 rounded-full px-4 py-2 text-xs text-[#F1F8FF] focus:outline-none focus:border-[#168BFF]"
          />
          <button
            type="submit"
            className="px-4 py-2 text-xs font-semibold text-white bg-[#0D47A1] hover:bg-[#168BFF] rounded-full transition-colors ios-press"
          >
            Mute
          </button>
        </form>

        <div className="flex flex-wrap gap-2 pt-2">
          {mutedWords.length === 0 ? (
            <span className="text-[11px] text-[#A8BCD7]/60 italic">No muted words configured.</span>
          ) : (
            mutedWords.map((word) => (
              <span
                key={word}
                className="inline-flex items-center gap-1.5 text-xs font-mono px-3 py-1 rounded-full bg-[#050A18] border border-[#8DDCFF]/20 text-[#8DDCFF]"
              >
                <span>{word}</span>
                <button
                  onClick={() => handleRemoveMutedWord(word)}
                  className="hover:text-[#FF6B6B]"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </span>
            ))
          )}
        </div>
      </div>

      {/* Blocked Accounts */}
      <div className="rounded-3xl ios-liquid-glass p-5 border border-[#8DDCFF]/20 space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold text-[#8DDCFF] uppercase tracking-wider">
          <UserX className="w-4 h-4" />
          <span>Blocked Nodes ({blockedUsers.length})</span>
        </div>
        <p className="text-[11px] text-[#A8BCD7]">
          Blocked users cannot message you, quote your text, or access your profile.
        </p>

        <div className="space-y-2">
          {blockedUsers.length === 0 ? (
            <span className="text-[11px] text-[#A8BCD7]/60 italic">No nodes are currently blocked.</span>
          ) : (
            blockedUsers.map((uid) => (
              <div
                key={uid}
                className="flex items-center justify-between p-2.5 rounded-2xl bg-[#050A18] border border-[#168BFF]/15"
              >
                <span className="text-xs font-mono text-[#A8BCD7]">UID: {uid.slice(0, 12)}...</span>
                <button
                  onClick={() => handleUnblockUser(uid)}
                  className="px-3 py-1 text-[11px] font-semibold text-[#8DDCFF] bg-[#071A38] hover:bg-[#0D47A1]/40 rounded-full transition-colors ios-press"
                >
                  Unblock
                </button>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Danger Zone */}
      <div className="rounded-3xl ios-liquid-glass p-5 border border-[#FF6B6B]/30 space-y-4">
        <div className="flex items-center gap-2 text-xs font-bold text-[#FF6B6B] uppercase tracking-wider">
          <AlertTriangle className="w-4 h-4" />
          <span>Terminal Actions</span>
        </div>

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-1">
          <div>
            <p className="text-xs font-semibold text-[#F1F8FF]">Deactivate Node</p>
            <p className="text-[11px] text-[#A8BCD7]">Temporarily suspend your presence.</p>
          </div>
          <button
            onClick={handleDeactivate}
            className="px-4 py-2 text-xs font-semibold text-[#FFD166] bg-[#FFD166]/10 hover:bg-[#FFD166]/20 border border-[#FFD166]/30 rounded-xl transition-colors"
          >
            Deactivate Account
          </button>
        </div>

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-3 border-t border-[#168BFF]/10">
          <div>
            <p className="text-xs font-semibold text-[#FF6B6B]">Delete Account</p>
            <p className="text-[11px] text-[#A8BCD7]">
              Irreversibly erase profile data and release username.
            </p>
          </div>
          <button
            onClick={handleDelete}
            className="px-4 py-2 text-xs font-semibold text-white bg-[#FF6B6B]/80 hover:bg-[#FF6B6B] rounded-xl shadow-[0_0_15px_rgba(255,107,107,0.3)] transition-colors"
          >
            Permanently Delete
          </button>
        </div>
      </div>
    </div>
  );
};
