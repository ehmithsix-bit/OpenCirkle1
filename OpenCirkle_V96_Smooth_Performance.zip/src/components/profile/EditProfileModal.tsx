import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { UserProfile } from '../../types';
import { updateUserProfile, changeUsername, checkUsernameAvailable } from '../../services/authService';
import { CrystalAvatar } from '../common/CrystalAvatar';
import { X, Check, Lock, Globe, AlertCircle } from 'lucide-react';

interface EditProfileModalProps {
  onClose: () => void;
  onProfileUpdated?: () => void;
}

const symbols: UserProfile['avatarSymbol'][] = [
  'gem',
  'prism',
  'hexagon',
  'star',
  'orb',
  'sparkle',
  'shield',
  'diamond',
];

const colors: UserProfile['avatarColor'][] = [
  'electric',
  'ice',
  'sapphire',
  'cyan',
  'neon',
];

export const EditProfileModal: React.FC<EditProfileModalProps> = ({
  onClose,
  onProfileUpdated,
}) => {
  const { currentUserProfile, refreshProfile } = useAuth();

  const [displayName, setDisplayName] = useState(currentUserProfile?.displayName || '');
  const [username, setUsername] = useState(currentUserProfile?.username || '');
  const [bio, setBio] = useState(currentUserProfile?.bio || '');
  const [avatarSymbol, setAvatarSymbol] = useState<UserProfile['avatarSymbol']>(
    currentUserProfile?.avatarSymbol || 'gem'
  );
  const [avatarColor, setAvatarColor] = useState<UserProfile['avatarColor']>(
    currentUserProfile?.avatarColor || 'electric'
  );
  const [isPrivate, setIsPrivate] = useState<boolean>(
    Boolean(currentUserProfile?.isPrivate)
  );
  const [saving, setSaving] = useState(false);
  const [usernameAvailability, setUsernameAvailability] = useState<'idle' | 'checking' | 'available' | 'taken' | 'invalid'>('idle');
  const [error, setError] = useState<string | null>(null);

  if (!currentUserProfile) return null;

  useEffect(() => {
    const clean = username.trim().replace(/^@/, '').toLowerCase();
    if (clean === currentUserProfile?.username?.toLowerCase()) { setUsernameAvailability('idle'); return; }
    if (!/^[a-z0-9_]{3,20}$/.test(clean)) { setUsernameAvailability(clean ? 'invalid' : 'idle'); return; }
    setUsernameAvailability('checking');
    let alive = true;
    const timer = window.setTimeout(async () => {
      try {
        const available = await checkUsernameAvailable(clean);
        if (alive) setUsernameAvailability(available ? 'available' : 'taken');
      } catch { if (alive) setUsernameAvailability('idle'); }
    }, 350);
    return () => { alive = false; window.clearTimeout(timer); };
  }, [username, currentUserProfile?.username]);


  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!displayName.trim() || saving) return;
    if (username.trim().replace(/^@/, '').toLowerCase() !== currentUserProfile.username.toLowerCase() && usernameAvailability !== 'available') { setError(usernameAvailability === 'taken' ? 'Username not available. Please choose another.' : 'Please wait for username availability check.'); return; }

    setSaving(true);
    setError(null);

    try {
      if (username.trim().replace(/^@/, '').toLowerCase() !== currentUserProfile.username.toLowerCase()) {
        await changeUsername(currentUserProfile.uid, username);
      }
      await updateUserProfile(currentUserProfile.uid, {
        displayName: displayName.trim(),
        bio: bio.trim(),
        avatarSymbol,
        avatarColor,
        isPrivate,
      });

      await refreshProfile();
      if (onProfileUpdated) onProfileUpdated();
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to update profile.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-[#050A18]/85 backdrop-blur-md">
      <div className="rounded-t-[32px] sm:rounded-3xl ios-liquid-glass w-full max-w-lg p-6 border border-[#8DDCFF]/30 shadow-[0_16px_50px_rgba(0,0,0,0.85)] relative h-[92dvh] max-h-[92dvh] sm:h-auto sm:max-h-[90dvh] flex flex-col overflow-hidden animate-slide-up sm:animate-in sm:fade-in sm:zoom-in-95 duration-200">
        <div className="w-10 h-1 bg-[#8DDCFF]/40 rounded-full mx-auto mb-4 sm:hidden shrink-0" />
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-[#A8BCD7] hover:text-[#F1F8FF] rounded-full hover:bg-[#071A38] transition-colors ios-press"
        >
          <X className="w-5 h-5" />
        </button>

        <h3 className="text-base font-bold text-[#F1F8FF] mb-4 shrink-0 pr-8">Edit Crystalline Identity</h3>

        <form onSubmit={handleSave} className="space-y-5 min-h-0 flex-1 overflow-y-auto overscroll-contain pb-[calc(1rem+env(safe-area-inset-bottom))] touch-pan-y" style={{ WebkitOverflowScrolling: 'touch', overscrollBehaviorY: 'contain' }}>
          {/* Live Preview Avatar */}
          <div className="flex flex-col items-center justify-center py-2 space-y-2">
            <CrystalAvatar
              displayName={displayName || currentUserProfile.username}
              username={currentUserProfile.username}
              avatarSymbol={avatarSymbol}
              avatarUrl={currentUserProfile.avatarUrl}
              avatarColor={avatarColor}
              size="xl"
            />
            <p className="text-[11px] text-[#A8BCD7]">Geometric Crystal Identity Preview</p>
          </div>

          {/* Facet Symbol Selector */}
          <div>
            <label className="block text-xs font-semibold text-[#F1F8FF] mb-2">
              Select Crystal Emblem
            </label>
            <div className="grid grid-cols-4 gap-2">
              {symbols.map((sym) => (
                <button
                  key={sym}
                  type="button"
                  onClick={() => setAvatarSymbol(sym)}
                  className={`py-2 px-3 rounded-xl border text-xs font-mono capitalize transition-all ${
                    avatarSymbol === sym
                      ? 'bg-[#168BFF]/20 border-[#168BFF] text-[#8DDCFF] shadow-[0_0_10px_rgba(22,139,255,0.3)]'
                      : 'bg-[#071A38]/50 border-[#168BFF]/15 text-[#A8BCD7] hover:border-[#168BFF]/40'
                  }`}
                >
                  {sym}
                </button>
              ))}
            </div>
          </div>

          {/* Radiant Aura Color */}
          <div>
            <label className="block text-xs font-semibold text-[#F1F8FF] mb-2">
              Radiant Aura Palette
            </label>
            <div className="grid grid-cols-5 gap-2">
              {colors.map((col) => (
                <button
                  key={col}
                  type="button"
                  onClick={() => setAvatarColor(col)}
                  className={`py-2 px-2 rounded-xl border text-xs font-mono capitalize transition-all ${
                    avatarColor === col
                      ? 'bg-[#168BFF]/20 border-[#168BFF] text-[#8DDCFF] shadow-[0_0_10px_rgba(22,139,255,0.3)]'
                      : 'bg-[#071A38]/50 border-[#168BFF]/15 text-[#A8BCD7] hover:border-[#168BFF]/40'
                  }`}
                >
                  {col}
                </button>
              ))}
            </div>
          </div>

          {/* Username */}
          <div>
            <label className="block text-xs font-semibold text-[#F1F8FF] mb-1.5">Username</label>
            <input type="text" value={username} onChange={(e) => setUsername(e.target.value.toLowerCase())} minLength={3} maxLength={20} pattern="[a-zA-Z0-9_]+" className="w-full bg-[#050A18] border border-[#168BFF]/25 rounded-xl px-3.5 py-2.5 text-xs text-[#F1F8FF] focus:outline-none focus:border-[#168BFF]" required />
            <p className={`text-[10px] mt-1 ${usernameAvailability === 'available' ? 'text-emerald-400' : usernameAvailability === 'taken' || usernameAvailability === 'invalid' ? 'text-rose-400' : 'text-[#A8BCD7]'}`} aria-live="polite">{usernameAvailability === 'checking' ? 'Checking availability…' : usernameAvailability === 'available' ? '✓ Username available' : usernameAvailability === 'taken' ? '✕ Username not available' : usernameAvailability === 'invalid' ? 'Use 3–20 letters, numbers, or underscores.' : 'You can change your username twice; after the second change, changes are locked for 2 months.'}</p>
          </div>

          {/* Display Name */}
          <div>
            <label className="block text-xs font-semibold text-[#F1F8FF] mb-1.5">
              Display Name
            </label>
            <input
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              maxLength={40}
              className="w-full bg-[#050A18] border border-[#168BFF]/25 rounded-xl px-3.5 py-2.5 text-xs text-[#F1F8FF] focus:outline-none focus:border-[#168BFF]"
              required
            />
          </div>

          {/* Biography */}
          <div>
            <label className="block text-xs font-semibold text-[#F1F8FF] mb-1.5">
              Text Biography (Max 300 characters)
            </label>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              maxLength={300}
              rows={3}
              placeholder="Reflect on your ideas, axioms, or inquiries..."
              className="w-full bg-[#050A18] border border-[#168BFF]/25 rounded-xl p-3 text-xs text-[#F1F8FF] focus:outline-none focus:border-[#168BFF] resize-none"
            />
            <span className="text-[10px] font-mono text-[#A8BCD7] block text-right">
              {bio.length} / 300
            </span>
          </div>

          {/* Account Privacy Toggle */}
          <div className="p-3.5 rounded-xl bg-[#050A18]/60 border border-[#168BFF]/20 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[#F1F8FF]">
                {isPrivate ? <Lock className="w-3.5 h-3.5 text-[#8DDCFF]" /> : <Globe className="w-3.5 h-3.5 text-[#168BFF]" />}
                <span>{isPrivate ? 'Private Profile' : 'Public Profile'}</span>
              </div>
              <p className="text-[11px] text-[#A8BCD7]">
                {isPrivate
                  ? 'Followers must request approval before viewing your posts.'
                  : 'Anyone can read your public reflections.'}
              </p>
            </div>
            <button
              type="button"
              onClick={() => setIsPrivate(!isPrivate)}
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                isPrivate ? 'bg-[#168BFF]' : 'bg-[#071A38] border border-[#168BFF]/30'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  isPrivate ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {error && (
            <div className="flex items-center gap-2 text-xs text-[#FF6B6B] bg-[#FF6B6B]/10 p-2.5 rounded-lg border border-[#FF6B6B]/20">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="sticky bottom-0 flex items-center justify-end gap-3 pt-3 pb-1 bg-[#07152B]/95 backdrop-blur-md border-t border-[#168BFF]/15">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-[#A8BCD7] hover:text-[#F1F8FF] rounded-xl hover:bg-[#071A38] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 text-xs font-semibold text-white bg-gradient-to-r from-[#0D47A1] to-[#168BFF] rounded-xl shadow-[0_0_15px_rgba(22,139,255,0.4)] transition-all disabled:opacity-50"
            >
              {saving ? 'Engraving Changes...' : 'Save Profile'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
