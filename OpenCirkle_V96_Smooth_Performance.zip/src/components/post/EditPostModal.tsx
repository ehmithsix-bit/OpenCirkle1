import React, { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Post, UserProfile } from '../../types';
import { editPost, MAX_POST_LENGTH, searchCollaboratorUsers, updatePostCollaborators } from '../../services/postService';
import { X, AlertCircle, UserPlus, Check, Loader2 } from 'lucide-react';

interface EditPostModalProps {
  post: Post;
  onClose: () => void;
  onPostUpdated: (updatedPost: Post) => void;
}

type CollaboratorChoice = { uid: string; username: string; displayName: string; status: 'pending' | 'accepted' | 'rejected'; invitedAt: number };

export const EditPostModal: React.FC<EditPostModalProps> = ({ post, onClose, onPostUpdated }) => {
  const { currentUserProfile } = useAuth();
  const [content, setContent] = useState(post.content);
  const [collaborators, setCollaborators] = useState<CollaboratorChoice[]>(() => (post.collaborators || []).map(c => ({ ...c })));
  const [collaboratorQuery, setCollaboratorQuery] = useState('');
  const [suggestions, setSuggestions] = useState<UserProfile[]>([]);
  const [searching, setSearching] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!currentUserProfile) return;
    const prefix = collaboratorQuery.trim().replace(/^@/, '');
    if (!prefix) { setSuggestions([]); setSearching(false); return; }
    let cancelled = false;
    const timer = window.setTimeout(async () => {
      setSearching(true);
      try {
        const matches = await searchCollaboratorUsers(prefix, currentUserProfile.uid, 8);
        if (!cancelled) setSuggestions(matches.filter(user => !collaborators.some(c => c.uid === user.uid)));
      } catch (e) {
        console.warn('Could not search collaborators:', e);
        if (!cancelled) setSuggestions([]);
      } finally { if (!cancelled) setSearching(false); }
    }, 220);
    return () => { cancelled = true; window.clearTimeout(timer); };
  }, [collaboratorQuery, currentUserProfile?.uid, collaborators]);

  const addCollaborator = (user: UserProfile) => {
    if (collaborators.length >= 6 || collaborators.some(c => c.uid === user.uid)) return;
    setCollaborators(prev => [...prev, { uid: user.uid, username: user.username, displayName: user.displayName || user.username, status: 'pending', invitedAt: Date.now() }]);
    setCollaboratorQuery('');
    setSuggestions([]);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUserProfile || submitting) return;
    setSubmitting(true);
    setError(null);
    try {
      const updatedText = await editPost(post.id, currentUserProfile.uid, content);
      const updatedCollaborators = await updatePostCollaborators(post.id, currentUserProfile, collaborators.map(c => c.username));
      onPostUpdated({ ...post, content: updatedText, collaborators: updatedCollaborators || [], collaboratorIds: (updatedCollaborators || []).map(c => c.uid), editedAt: Date.now() });
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to update post.');
    } finally { setSubmitting(false); }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-2 sm:p-4 bg-[#050A18]/85 backdrop-blur-md">
      <div className="rounded-t-[28px] sm:rounded-3xl ios-liquid-glass w-full max-w-xl h-auto max-h-[calc(100dvh-0.5rem)] sm:max-h-[92dvh] overflow-hidden flex flex-col border border-[#8DDCFF]/30 shadow-[0_16px_50px_rgba(0,0,0,0.85)] relative animate-slide-up sm:animate-in sm:fade-in sm:zoom-in-95 duration-200">
        <div className="shrink-0 px-5 pt-3 pb-3 sm:px-6 sm:pt-5 border-b border-[#8DDCFF]/10">
          <div className="w-10 h-1 bg-[#8DDCFF]/40 rounded-full mx-auto mb-3 sm:hidden" />
          <button type="button" onClick={onClose} aria-label="Close edit post" className="absolute top-4 right-4 z-10 p-1.5 text-[#A8BCD7] hover:text-[#F1F8FF] rounded-full hover:bg-[#071A38] transition-colors ios-press"><X className="w-5 h-5" /></button>
          <h3 className="text-base font-bold text-[#F1F8FF] pr-10">Edit Post</h3>
        </div>
        <form onSubmit={handleSubmit} className="flex min-h-0 flex-1 flex-col">
          <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain touch-pan-y px-5 py-4 sm:px-6 [-webkit-overflow-scrolling:touch]">
            <div className="space-y-4 pb-2">
              <textarea value={content} onChange={e => setContent(e.target.value)} rows={5} maxLength={MAX_POST_LENGTH} aria-label="Post content" className="w-full min-h-32 bg-[#050A18] border border-[#168BFF]/25 rounded-xl p-3 text-sm text-[#F1F8FF] focus:outline-none focus:border-[#168BFF] resize-y" />
              <div className="flex items-center justify-between text-xs text-[#A8BCD7]"><span className="font-mono tabular-nums">{content.length} / {MAX_POST_LENGTH}</span></div>
              <section className="rounded-xl border border-[#8DDCFF]/20 bg-[#071A38]/60 p-3 space-y-3">
                <div className="flex items-center gap-2 text-xs font-semibold text-[#8DDCFF]"><UserPlus className="w-4 h-4" /> Manage Collaborators</div>
                {collaborators.length > 0 ? <div className="flex flex-wrap gap-2">{collaborators.map(user => <span key={user.uid} className="inline-flex max-w-full items-center gap-1.5 rounded-full border border-[#8DDCFF]/25 bg-[#168BFF]/10 px-2.5 py-1.5 text-[11px] text-[#F1F8FF]"><span className="truncate">@{user.username}</span><span className="text-[9px] text-[#8DDCFF]">{user.status}</span><button type="button" aria-label={`Remove @${user.username}`} onClick={() => setCollaborators(prev => prev.filter(c => c.uid !== user.uid))} className="ml-0.5 text-[#A8BCD7] hover:text-[#FF7777]"><X className="h-3 w-3" /></button></span>)}</div> : <p className="text-[11px] text-[#8199B9]">No collaborators added yet.</p>}
                <div className="relative">
                  <input autoComplete="off" value={collaboratorQuery} onChange={e => setCollaboratorQuery(e.target.value)} placeholder="Type a username to find people…" className="w-full rounded-lg border border-[#168BFF]/20 bg-[#050A18] px-3 py-2.5 text-xs text-[#F1F8FF] outline-none focus:border-[#8DDCFF]" />
                  {(searching || suggestions.length > 0) && <div className="absolute z-30 mt-1 max-h-52 w-full overflow-y-auto rounded-xl border border-[#168BFF]/30 bg-[#071A38] shadow-2xl">{searching && <div className="px-3 py-2 text-[11px] text-[#A8BCD7]">Searching users…</div>}{suggestions.map(user => <button type="button" key={user.uid} onClick={() => addCollaborator(user)} className="flex w-full items-center justify-between gap-2 px-3 py-2.5 text-left hover:bg-[#168BFF]/15"><span className="min-w-0"><span className="block truncate text-xs font-semibold text-[#F1F8FF]">{user.displayName || user.username}</span><span className="block text-[10px] text-[#8DDCFF]">@{user.username}</span></span><UserPlus className="h-4 w-4 shrink-0 text-[#8DDCFF]" /></button>)}</div>}
                  {!searching && collaboratorQuery.trim() && suggestions.length === 0 && <p className="mt-1 text-[10px] text-[#8199B9]">No matching users found.</p>}
                </div>
                <p className="text-[10px] text-[#8199B9]">Select a username to invite. Remove a person with ×. New invitations require the invited user to accept.</p>
              </section>
              {error && <div className="flex items-center gap-2 text-xs text-[#FF6B6B] bg-[#FF6B6B]/10 p-2.5 rounded-lg border border-[#FF6B6B]/20"><AlertCircle className="w-4 h-4 shrink-0" /><span>{error}</span></div>}
            </div>
          </div>
          <div className="shrink-0 flex items-center justify-end gap-3 border-t border-[#8DDCFF]/15 bg-[#071A38]/95 px-5 pt-3 pb-[max(1rem,env(safe-area-inset-bottom))] sm:px-6 sm:pb-4 backdrop-blur-xl">
            <button type="button" onClick={onClose} className="px-4 py-2.5 text-xs font-medium text-[#A8BCD7] hover:text-[#F1F8FF] rounded-xl hover:bg-[#071A38] transition-colors">Cancel</button>
            <button type="submit" disabled={submitting || !content.trim()} className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-gradient-to-r from-[#0D47A1] to-[#168BFF] rounded-xl shadow-[0_0_15px_rgba(22,139,255,0.3)] transition-all disabled:opacity-50">{submitting ? <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Saving…</> : <><Check className="w-3.5 h-3.5" /> Save Changes</>}</button>
          </div>
        </form>
      </div>
    </div>
  );
};
