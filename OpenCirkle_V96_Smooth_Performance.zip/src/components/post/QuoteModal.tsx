import React from 'react';
import { Post } from '../../types';
import { PostComposer } from './PostComposer';
import { X, Quote } from 'lucide-react';

interface QuoteModalProps {
  post: Post;
  onClose: () => void;
  onPostCreated: (newPost: Post) => void;
}

export const QuoteModal: React.FC<QuoteModalProps> = ({
  post,
  onClose,
  onPostCreated,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-[#050A18]/85 backdrop-blur-md">
      <div className="relative w-full max-w-2xl">
        <PostComposer
          isModal={true}
          quotePost={post}
          onClose={onClose}
          onPostCreated={(newP) => {
            onPostCreated(newP);
            onClose();
          }}
          placeholder="Add your crystalline insight to this quote..."
        />
      </div>
    </div>
  );
};
