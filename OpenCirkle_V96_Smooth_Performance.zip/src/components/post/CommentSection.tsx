import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Comment, Post } from '../../types';
import { getLatestUserProfile } from '../../services/latestProfileService';
import { addComment, deleteComment, fetchPostComments } from '../../services/commentService';
import { CrystalAvatar } from '../common/CrystalAvatar';
import VerifiedBadge from '../common/VerifiedBadge';
import { Send, Trash2, CheckCircle2, ShieldAlert } from 'lucide-react';

interface CommentSectionProps {
  post: Post;
  onCommentsUpdated?: () => void;
  onOpenAuth?: () => void;
  onViewProfile?: (username: string) => void;
}

export const CommentSection: React.FC<CommentSectionProps> = ({
  post,
  onCommentsUpdated,
  onOpenAuth,
  onViewProfile,
}) => {
  const { currentUserProfile, isModerator } = useAuth();
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [newText, setNewText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        const list = await fetchPostComments(post.id);
        const refreshed = await Promise.all(list.map(async (comment) => {
          if (currentUserProfile?.uid === comment.authorId) {
            return { ...comment, authorUsername: currentUserProfile.username, authorDisplayName: currentUserProfile.displayName };
          }
          const profile = await getLatestUserProfile(comment.authorId);
          return profile ? {
            ...comment,
            authorUsername: profile.username || comment.authorUsername,
            authorDisplayName: profile.displayName || comment.authorDisplayName,
            authorVerified: profile.verified ?? comment.authorVerified,
            authorAvatarSymbol: profile.avatarSymbol || comment.authorAvatarSymbol,
            authorAvatarColor: profile.avatarColor || comment.authorAvatarColor,
            authorAvatarUrl: profile.avatarUrl || comment.authorAvatarUrl,
          } : comment;
        }));
        if (active) setComments(refreshed);
      } catch (e) {
        console.warn('Failed to load comments:', e);
      } finally {
        if (active) setLoading(false);
      }
    };
    load();
    return () => {
      active = false;
    };
  }, [post.id, currentUserProfile]);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUserProfile) {
      if (onOpenAuth) onOpenAuth();
      return;
    }
    if (!newText.trim() || submitting) return;

    setSubmitting(true);
    setError(null);
    try {
      const added = await addComment(post.id, currentUserProfile, newText);
      setComments((prev) => [...prev, added]);
      setNewText('');
      if (onCommentsUpdated) onCommentsUpdated();
    } catch (err: any) {
      setError(err?.message || 'Failed to submit comment.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (commentId: string) => {
    if (!currentUserProfile) return;
    try {
      await deleteComment(commentId, post.id, currentUserProfile.uid, isModerator);
      setComments((prev) => prev.filter((c) => c.id !== commentId));
      if (onCommentsUpdated) onCommentsUpdated();
    } catch (err: any) {
      console.error('Failed to delete comment:', err);
    }
  };

  return (
    <div className="mt-4 pt-4 border-t border-[#168BFF]/15 space-y-4">
      {/* Existing comments list */}
      {loading ? (
        <div className="py-4 text-center text-xs font-mono text-[#A8BCD7] animate-pulse">
          Loading discussion thread...
        </div>
      ) : comments.length === 0 ? (
        <div className="py-3 text-center text-xs text-[#A8BCD7]/70 italic">
          No reflections yet. Be the first to engrave your thoughts.
        </div>
      ) : (
        <div className="space-y-3">
          {comments.map((c) => {
            const canDelete = currentUserProfile && (currentUserProfile.uid === c.authorId || isModerator);
            return (
              <div
                key={c.id}
                className="p-3 rounded-xl bg-[#050A18]/60 border border-[#168BFF]/10 text-xs space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <button
                    onClick={() => onViewProfile && onViewProfile(c.authorUsername)}
                    className="flex items-center gap-2 text-left group focus:outline-none"
                  >
                    <CrystalAvatar
                      displayName={c.authorDisplayName}
                      username={c.authorUsername}
                      avatarSymbol={c.authorAvatarSymbol}
                      avatarUrl={c.authorAvatarUrl}
                      avatarColor={c.authorAvatarColor}
                      size="xs"
                    />
                    <span className="font-semibold text-[#F1F8FF] group-hover:text-[#8DDCFF] transition-colors">
                      {c.authorDisplayName}
                    </span>
                    {c.authorVerified && <VerifiedBadge size="sm" title="Verified account" />}
                    <span className="text-[#A8BCD7] font-mono text-[10px]">
                      @{c.authorUsername}
                    </span>
                  </button>

                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-[#A8BCD7]/60 font-mono">
                      {new Date(c.createdAt).toLocaleTimeString('en-BD', { timeZone: 'Asia/Dhaka', hour: '2-digit', minute: '2-digit' })}
                    </span>
                    {canDelete && (
                      <button
                        onClick={() => handleDelete(c.id)}
                        className="p-1 text-[#A8BCD7] hover:text-[#FF6B6B] transition-colors"
                        title="Delete comment"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>

                <p className="text-xs text-[#F1F8FF]/90 leading-relaxed pl-7 break-words whitespace-pre-wrap">
                  {c.content}
                </p>
              </div>
            );
          })}
        </div>
      )}

      {/* Add comment input */}
      {currentUserProfile ? (
        <form onSubmit={handleAdd} className="flex gap-2 items-center">
          <input
            type="text"
            value={newText}
            onChange={(e) => setNewText(e.target.value)}
            placeholder="Write a reflection (text only)..."
            maxLength={1000}
            className="flex-1 bg-[#050A18]/80 border border-[#168BFF]/25 rounded-xl px-3.5 py-2 text-xs text-[#F1F8FF] placeholder-[#A8BCD7]/50 focus:outline-none focus:border-[#168BFF] transition-all"
          />
          <button
            type="submit"
            disabled={!newText.trim() || submitting}
            className={`p-2.5 rounded-xl text-white transition-all ${
              newText.trim() && !submitting
                ? 'bg-gradient-to-r from-[#0D47A1] to-[#168BFF] shadow-[0_0_10px_rgba(22,139,255,0.4)]'
                : 'bg-[#071A38] text-[#A8BCD7]/40 cursor-not-allowed'
            }`}
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      ) : (
        <div className="text-center py-2">
          <button
            onClick={onOpenAuth}
            className="text-xs text-[#8DDCFF] hover:underline"
          >
            Sign in to join this discourse.
          </button>
        </div>
      )}

      {error && (
        <p className="text-[11px] text-[#FF6B6B]">{error}</p>
      )}
    </div>
  );
};
