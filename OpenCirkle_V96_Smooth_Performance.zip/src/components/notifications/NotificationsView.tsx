import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { NotificationItem, FollowRequestRecord, PlatformAnnouncement } from '../../types';
import { collection, onSnapshot, query, limit } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import {
  subscribeToNotifications,
  markNotificationRead,
  markCollaborationInvitationResponded,
  markAllNotificationsRead,
} from '../../services/notificationService';
import { respondToPostCollaboration } from '../../services/postService';
import {
  fetchPendingFollowRequests,
  respondToFollowRequest,
} from '../../services/socialService';
import { CrystalAvatar } from '../common/CrystalAvatar';
import {
  Bell,
  Heart,
  MessageSquare,
  Repeat2,
  UserPlus,
  AtSign,
  Check,
  X,
  CheckCheck,
} from 'lucide-react';

interface NotificationsViewProps {
  onUserClick: (username: string) => void;
  onPostClick?: (postId: string) => void;
  onOpenAuth: () => void;
}

export const NotificationsView: React.FC<NotificationsViewProps> = ({
  onUserClick,
  onPostClick,
  onOpenAuth,
}) => {
  const { currentUserProfile } = useAuth();
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [followRequests, setFollowRequests] = useState<FollowRequestRecord[]>([]);
  const [announcements, setAnnouncements] = useState<PlatformAnnouncement[]>([]);
  const [activeFilter, setActiveFilter] = useState<'all' | 'mentions' | 'interactions' | 'requests'>('all');
  const [loading, setLoading] = useState(true);
  const [collabActionBusy, setCollabActionBusy] = useState<string | null>(null);
  const [collabActionMessage, setCollabActionMessage] = useState<{ id: string; text: string; isError: boolean } | null>(null);

  // Subscribe to notifications
  useEffect(() => {
    if (!currentUserProfile?.uid) {
      setNotifications([]);
      setLoading(false);
      return;
    }
    const unsubscribe = subscribeToNotifications(currentUserProfile.uid, (list) => {
      setNotifications(list);
      setLoading(false);
    });

    return () => {
      unsubscribe();
    };
  }, [currentUserProfile?.uid]);

  // Live platform broadcasts sent from Admin appear inside the notification screen.
  useEffect(() => {
    const unsub = onSnapshot(query(collection(db, 'announcements'), limit(30)), (snap) => {
      const list = snap.docs.map((d) => ({ ...(d.data() as PlatformAnnouncement), id: d.id }))
        .filter((a) => a.active)
        .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      setAnnouncements(list);
    }, (err) => console.warn('Could not load platform notifications:', err));
    return () => unsub();
  }, []);

  // Load pending follow requests if user is private
  useEffect(() => {
    if (!currentUserProfile?.uid) {
      setFollowRequests([]);
      return;
    }
    let active = true;
    const loadRequests = async () => {
      try {
        const reqs = await fetchPendingFollowRequests(currentUserProfile.uid);
        if (active) setFollowRequests(reqs);
      } catch (err) {
        console.warn('Error loading follow requests:', err);
      }
    };
    loadRequests();
    return () => {
      active = false;
    };
  }, [currentUserProfile?.uid]);

  const handleMarkAllRead = async () => {
    if (!currentUserProfile) return;
    await markAllNotificationsRead(currentUserProfile.uid);
  };

  const handleNotificationClick = async (notif: NotificationItem) => {
    if (!notif.read) {
      await markNotificationRead(notif.id);
    }
    if (notif.targetPostId && onPostClick) {
      onPostClick(notif.targetPostId);
    } else if (notif.storyId) {
      window.location.hash = `#story-${encodeURIComponent(notif.storyId)}`;
    } else if (notif.type === 'message') {
      window.location.hash = '#messages';
    } else if (notif.type !== 'monetization_approved' && notif.type !== 'monetization_rejected' && notif.type !== 'monetization_payout') {
      onUserClick(notif.senderUsername);
    }
  };

  const handleCollabResponse = async (notif: NotificationItem, accept: boolean) => {
    if (!notif.targetPostId || !currentUserProfile || collabActionBusy) return;
    setCollabActionBusy(notif.id);
    setCollabActionMessage(null);
    try {
      await respondToPostCollaboration(notif.targetPostId, currentUserProfile, accept);
      // Marking the notification read is secondary; it must not undo a saved response.
      const response = accept ? 'accepted' : 'rejected';
      try { await markCollaborationInvitationResponded(notif.id, response); }
      catch (readError) { console.warn('Could not persist collaboration invitation response on notification:', readError); }
      setNotifications(prev => prev.map(item => item.id === notif.id ? { ...item, read: true, collaborationResponse: response } : item));
      setCollabActionMessage({ id: notif.id, text: accept ? 'Invitation accepted successfully.' : 'Invitation rejected.', isError: false });
    } catch (error: any) {
      console.error('Collaboration response failed:', error);
      setCollabActionMessage({ id: notif.id, text: error?.message || 'Could not respond to this invitation. Please try again.', isError: true });
    } finally {
      setCollabActionBusy(null);
    }
  };

  const handleRequestResponse = async (req: FollowRequestRecord, accept: boolean) => {
    if (!currentUserProfile) return;
    try {
      await respondToFollowRequest(req, currentUserProfile, accept);
      setFollowRequests((prev) => prev.filter((r) => r.id !== req.id));
    } catch (err) {
      console.error('Request response error:', err);
    }
  };

  // Keep all hooks above this guard so auth hydration never changes hook order.
  if (!currentUserProfile) {
    return (
      <div className="rounded-3xl ios-liquid-glass max-w-md mx-auto p-8 text-center border border-[#8DDCFF]/20 space-y-3">
        <Bell className="w-12 h-12 text-[#168BFF] mx-auto" />
        <h3 className="text-base font-bold text-[#F1F8FF]">Network Signals</h3>
        <p className="text-xs text-[#A8BCD7]">Sign in to receive signals, mentions, and interaction pulses.</p>
        <button onClick={onOpenAuth} className="px-6 py-2.5 text-xs font-semibold text-white bg-gradient-to-r from-[#0D47A1] to-[#168BFF] rounded-full shadow-[0_0_15px_rgba(22,139,255,0.4)] ios-press">Sign In</button>
      </div>
    );
  }

  const filteredNotifications = notifications.filter((n) => {
    if (activeFilter === 'mentions') return n.type === 'mention';
    if (activeFilter === 'interactions') return ['like', 'comment', 'reply', 'repost', 'post', 'story', 'online', 'message'].includes(n.type);
    if (activeFilter === 'requests') return n.type === 'follow_request' || n.type === 'collab_invite';
    return true;
  });

  const getSignalIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'like':
        return <Heart className="w-4 h-4 text-[#FF6B6B] fill-current" />;
      case 'comment':
      case 'reply':
      case 'message':
        return <MessageSquare className="w-4 h-4 text-[#8DDCFF]" />;
      case 'post':
      case 'story':
      case 'online':
        return <Bell className="w-4 h-4 text-[#8DDCFF]" />;
      case 'repost':
        return <Repeat2 className="w-4 h-4 text-[#168BFF]" />;
      case 'collab_invite':
      case 'collab_accepted':
      case 'collab_rejected':
        return <UserPlus className="w-4 h-4 text-[#8DDCFF]" />;
      case 'mention':
        return <AtSign className="w-4 h-4 text-[#8DDCFF]" />;
      case 'follow':
      case 'follow_request':
      default:
        return <UserPlus className="w-4 h-4 text-[#8DDCFF]" />;
    }
  };

  return (
    <div className="max-w-2xl w-full mx-auto pb-16">
      <div className="flex items-center justify-between mb-5 pb-3 border-b border-[#168BFF]/15">
        <div className="flex items-center gap-2">
          <Bell className="w-5 h-5 text-[#8DDCFF]" />
          <h2 className="text-base font-bold text-[#F1F8FF]">Signals & Pulses</h2>
        </div>

        {notifications.some((n) => !n.read) && (
          <button
            onClick={handleMarkAllRead}
            className="flex items-center gap-1.5 text-xs text-[#8DDCFF] hover:underline font-medium"
          >
            <CheckCheck className="w-3.5 h-3.5" />
            <span>Mark all read</span>
          </button>
        )}
      </div>

      {announcements.length > 0 && (
        <section className="mb-5 space-y-3" aria-label="Official OpenCirkle notifications">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#8DDCFF]">Official Notifications</h3>
          {announcements.map((announcement) => (
            <article key={announcement.id} className="rounded-2xl border border-[#168BFF]/30 bg-gradient-to-r from-[#071A38] to-[#0A2346] p-4 shadow-[0_8px_24px_rgba(22,139,255,.12)]">
              <div className="flex items-start gap-3">
                <div className="mt-0.5 rounded-xl border border-[#8DDCFF]/30 bg-[#168BFF]/15 p-2"><Bell className="h-4 w-4 text-[#8DDCFF]" /></div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2"><h4 className="text-sm font-bold text-[#F1F8FF]">{announcement.title}</h4><span className="rounded-full bg-[#168BFF]/15 px-2 py-0.5 text-[9px] uppercase text-[#8DDCFF]">{announcement.type}</span></div>
                  <p className="mt-1 whitespace-pre-wrap text-sm leading-relaxed text-[#C1D5EF]">{announcement.content}</p>
                  <p className="mt-2 text-[10px] text-[#7E9ABF]">OpenCirkle · {announcement.createdAt ? new Date(announcement.createdAt).toLocaleString('en-BD', { timeZone: 'Asia/Dhaka' }) : 'New'}</p>
                </div>
              </div>
            </article>
          ))}
        </section>
      )}

      {/* Pending Follow Requests Notice for Private Accounts */}
      {followRequests.length > 0 && (
        <div className="rounded-3xl ios-liquid-glass p-4 mb-6 border border-[#8DDCFF]/30 space-y-3">
          <h3 className="text-xs font-bold text-[#8DDCFF] uppercase tracking-wider flex items-center gap-2">
            <UserPlus className="w-4 h-4" />
            <span>Pending Node Access Requests ({followRequests.length})</span>
          </h3>

          <div className="divide-y divide-[#168BFF]/10">
            {followRequests.map((req) => (
              <div key={req.id} className="py-2.5 flex items-center justify-between gap-3">
                <button
                  onClick={() => onUserClick(req.requesterUsername)}
                  className="flex items-center gap-2.5 text-left group ios-press"
                >
                  <CrystalAvatar
                    displayName={req.requesterDisplayName}
                    username={req.requesterUsername}
                    avatarSymbol={req.requesterAvatarSymbol}
                    avatarUrl={req.requesterAvatarUrl}
                    avatarColor={req.requesterAvatarColor}
                    size="sm"
                  />
                  <div>
                    <span className="text-xs font-semibold text-[#F1F8FF] group-hover:text-[#8DDCFF]">
                      {req.requesterDisplayName}
                    </span>
                    <span className="text-[10px] font-mono text-[#A8BCD7] block">
                      @{req.requesterUsername}
                    </span>
                  </div>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleRequestResponse(req, true)}
                    className="p-1.5 rounded-full bg-[#168BFF]/20 text-[#8DDCFF] hover:bg-[#168BFF]/40 border border-[#168BFF]/40 transition-colors ios-press"
                    title="Accept Request"
                  >
                    <Check className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleRequestResponse(req, false)}
                    className="p-1.5 rounded-full bg-[#FF6B6B]/20 text-[#FF6B6B] hover:bg-[#FF6B6B]/40 border border-[#FF6B6B]/40 transition-colors ios-press"
                    title="Decline Request"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Filter Tabs: iOS Rounded Liquid Glass Pill */}
      <div className="flex items-center gap-1.5 p-1 rounded-full ios-liquid-glass-subtle border border-[#8DDCFF]/20 mb-5">
        {[
          { id: 'all', label: 'All Signals' },
          { id: 'mentions', label: 'Mentions' },
          { id: 'interactions', label: 'Interactions' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveFilter(tab.id as any)}
            className={`flex-1 py-1.5 px-3 text-xs font-semibold rounded-full ios-press transition-all ${
              activeFilter === tab.id
                ? 'bg-gradient-to-r from-[#0D47A1] to-[#168BFF] text-white shadow-[0_0_12px_rgba(22,139,255,0.4)] border border-[#8DDCFF]/30'
                : 'text-[#A8BCD7] hover:text-[#F1F8FF]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Signals List */}
      {loading ? (
        <div className="py-12 text-center text-xs font-mono text-[#A8BCD7] animate-pulse">
          Listening to signals...
        </div>
      ) : filteredNotifications.length === 0 ? (
        <div className="rounded-3xl ios-liquid-glass p-8 text-center text-xs text-[#A8BCD7] border border-[#168BFF]/15">
          No signal pulses recorded yet.
        </div>
      ) : (
        <div className="space-y-2.5">
          {filteredNotifications.map((n) => (
            <div
              key={n.id}
              onClick={() => handleNotificationClick(n)}
              className={`rounded-2xl ios-liquid-glass-subtle p-4 border transition-all cursor-pointer flex items-center justify-between gap-3 ios-press ${
                !n.read
                  ? 'border-[#8DDCFF]/40 shadow-[0_0_15px_rgba(22,139,255,0.2)]'
                  : 'border-[#168BFF]/10 hover:border-[#168BFF]/30'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="p-2 rounded-xl bg-[#050A18] border border-[#168BFF]/20 shrink-0">
                  {getSignalIcon(n.type)}
                </div>

                <div className="min-w-0">
                  <p className="text-xs text-[#F1F8FF] leading-snug">
                    <span className="font-bold text-[#8DDCFF]">{n.senderDisplayName}</span>{' '}
                    {n.type === 'like' && 'resonated with your discourse'}
                    {n.type === 'comment' && 'commented on your post'}
                    {n.type === 'reply' && 'replied to your comment'}
                    {n.type === 'post' && 'published a new post'}
                    {n.type === 'story' && 'shared a new story'}
                    {n.type === 'online' && 'is now online'}
                    {n.type === 'message' && 'sent you a message'}
                    {n.type === 'repost' && 'quoted your discourse'}
                    {n.type === 'follow' && 'started following you'}
                    {n.type === 'mention' && 'invoked your name in a discourse'}
                    {n.type === 'collab_invite' && 'invited you to collaborate on a post'}
                    {n.type === 'collab_accepted' && 'accepted your collaboration invitation'}
                    {n.type === 'collab_rejected' && 'rejected your collaboration invitation'}
                    {n.type === 'monetization_approved' && 'approved your monetization application'}
                    {n.type === 'monetization_rejected' && 'updated your monetization application'}
                    {n.type === 'monetization_payout' && 'confirmed your creator payout'}
                  </p>

                  {n.textSnippet && (
                    <p className={`text-[11px] text-[#A8BCD7] italic mt-0.5 ${n.type === 'monetization_approved' || n.type === 'monetization_rejected' || n.type === 'monetization_payout' ? 'whitespace-normal break-words' : 'truncate'}`}>
                      "{n.textSnippet}"
                    </p>
                  )}

                  {n.type === 'collab_invite' && <div className="mt-2 flex flex-wrap items-center gap-2" onClick={e => e.stopPropagation()}>
                    {!n.collaborationResponse ? <>
                      <button disabled={collabActionBusy !== null} onClick={() => handleCollabResponse(n, true)} className="rounded-lg bg-[#168BFF]/20 px-3 py-1.5 text-[11px] font-semibold text-[#8DDCFF] disabled:opacity-50">{collabActionBusy === n.id ? 'Please wait…' : 'Accept'}</button>
                      <button disabled={collabActionBusy !== null} onClick={() => handleCollabResponse(n, false)} className="rounded-lg bg-rose-500/15 px-3 py-1.5 text-[11px] font-semibold text-rose-200 disabled:opacity-50">Reject</button>
                    </> : <span className={`text-[10px] font-semibold ${n.collaborationResponse === 'accepted' ? 'text-emerald-300' : 'text-rose-300'}`}>You {n.collaborationResponse} this invitation.</span>}
                    {collabActionMessage?.id === n.id && <span role="status" className={`basis-full text-[10px] ${collabActionMessage.isError ? 'text-rose-300' : 'text-emerald-300'}`}>{collabActionMessage.text}</span>}
                  </div>}
                  <span className="text-[10px] font-mono text-[#A8BCD7]/60 block mt-1">
                    {new Date(n.createdAt).toLocaleTimeString('en-BD', { timeZone: 'Asia/Dhaka',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}{' '}
                    · {new Date(n.createdAt).toLocaleDateString('en-BD', { timeZone: 'Asia/Dhaka', month: 'short', day: 'numeric' })}
                  </span>
                </div>
              </div>

              {!n.read && (
                <span className="w-2.5 h-2.5 rounded-full bg-gradient-to-r from-[#168BFF] to-[#8DDCFF] shadow-[0_0_8px_#168BFF] shrink-0" />
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
