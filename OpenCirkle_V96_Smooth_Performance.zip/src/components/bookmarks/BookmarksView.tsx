import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Post } from '../../types';
import { fetchBookmarkedPosts } from '../../services/postService';
import { PostCard } from '../post/PostCard';
import { Bookmark, Sparkles } from 'lucide-react';

interface BookmarksViewProps {
  onHashtagClick: (tag: string) => void;
  onUserClick: (username: string) => void;
  onOpenAuth: () => void;
}

export const BookmarksView: React.FC<BookmarksViewProps> = ({
  onHashtagClick,
  onUserClick,
  onOpenAuth,
}) => {
  const { currentUserProfile } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);

  if (!currentUserProfile) {
    return (
      <div className="rounded-3xl ios-liquid-glass max-w-md mx-auto p-8 text-center border border-[#8DDCFF]/20 space-y-3">
        <Bookmark className="w-12 h-12 text-[#168BFF] mx-auto" />
        <h3 className="text-base font-bold text-[#F1F8FF]">Vault of Preserved Discourses</h3>
        <p className="text-xs text-[#A8BCD7]">
          Sign in to access your personal crypt of bookmarked reflections.
        </p>
        <button
          onClick={onOpenAuth}
          className="px-6 py-2.5 text-xs font-semibold text-white bg-gradient-to-r from-[#0D47A1] to-[#168BFF] rounded-full shadow-[0_0_15px_rgba(22,139,255,0.4)] ios-press"
        >
          Sign In
        </button>
      </div>
    );
  }

  useEffect(() => {
    let active = true;
    const load = async () => {
      setLoading(true);
      try {
        const list = await fetchBookmarkedPosts(currentUserProfile.uid);
        if (active) setPosts(list);
      } catch (err) {
        console.error('Failed to load bookmarks:', err);
      } finally {
        if (active) setLoading(false);
      }
    };
    load();
    return () => {
      active = false;
    };
  }, [currentUserProfile.uid]);

  return (
    <div className="max-w-2xl w-full mx-auto pb-16">
      <div className="flex items-center gap-2 mb-6 pb-3 border-b border-[#168BFF]/15">
        <Bookmark className="w-5 h-5 text-[#8DDCFF]" />
        <div>
          <h2 className="text-base font-bold text-[#F1F8FF]">Preserved Vault</h2>
          <p className="text-xs text-[#A8BCD7]">Discourses safely stored in your private node</p>
        </div>
      </div>

      {loading ? (
        <div className="py-12 text-center text-xs font-mono text-[#A8BCD7] animate-pulse">
          Opening crystalline vault...
        </div>
      ) : posts.length === 0 ? (
        <div className="rounded-3xl ios-liquid-glass p-8 text-center border border-[#168BFF]/15 space-y-2">
          <Bookmark className="w-10 h-10 text-[#168BFF]/40 mx-auto" />
          <h4 className="text-sm font-semibold text-[#F1F8FF]">Vault is Empty</h4>
          <p className="text-xs text-[#A8BCD7] max-w-sm mx-auto">
            Tap the bookmark emblem on any post in the feed to preserve it in your personal vault.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {posts.map((post, idx) => (
            <PostCard
              key={`bookmark-post-${post.id || 'p'}-${idx}`}
              post={post}
              onPostDeleted={(id) => setPosts((prev) => prev.filter((p) => p.id !== id))}
              onHashtagClick={onHashtagClick}
              onUserClick={onUserClick}
              onOpenAuth={onOpenAuth}
            />
          ))}
        </div>
      )}
    </div>
  );
};
