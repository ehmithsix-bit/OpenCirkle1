import React, { useState, useEffect } from 'react';
import { collection, doc, onSnapshot, runTransaction, setDoc, updateDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useAuth } from '../../context/AuthContext';
import {
  AdminAuditLog,
  PlatformAnnouncement,
  PlatformSettings,
  ReportItem,
  UserProfile,
  UserRole,
} from '../../types';
import {
  fetchPendingReports,
  resolveReport,
  updateUserModerationStatus,
  toggleUserVerification,
  updateUserRole,
  fetchAdminAuditLogs,
  fetchPlatformSettings,
  updatePlatformSettings,
  createAnnouncement,
  fetchActiveAnnouncements,
  fetchAdminAnalytics,
} from '../../services/moderationService';
import { deletePost } from '../../services/postService';
import { getUserByUsername } from '../../services/authService';
import { CrystalAvatar } from '../common/CrystalAvatar';
import { VerificationRequestsPanel } from './VerificationRequestsPanel';
import {
  ShieldAlert,
  Users,
  FileText,
  Radio,
  Sliders,
  History,
  CheckCircle2,
  XCircle,
  Trash2,
  Search,
  BadgeCheck,
  AlertTriangle,
  RefreshCw,
  Wallet,
} from 'lucide-react';

const toDateTimeLocal = (value?: number): string => {
  if (!value || !Number.isFinite(Number(value))) return '';
  const d = new Date(Number(value));
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

const fromDateTimeLocal = (value: string): number => {
  if (!value) return 0;
  const time = new Date(value).getTime();
  return Number.isFinite(time) ? time : 0;
};

export const AdminControlCenter: React.FC = () => {
  const { currentUserProfile, isModerator, isAdmin, isSuperAdmin } = useAuth();

  const [activeTab, setActiveTab] = useState<'reports' | 'users' | 'verification' | 'monetization' | 'announcements' | 'settings' | 'audit'>('reports');
  const [analytics, setAnalytics] = useState({
    totalUsers: 0,
    totalPosts: 0,
    pendingReports: 0,
    activeAnnouncements: 0,
  });
  const [reports, setReports] = useState<ReportItem[]>([]);
  const [auditLogs, setAuditLogs] = useState<AdminAuditLog[]>([]);
  const [announcements, setAnnouncements] = useState<PlatformAnnouncement[]>([]);
  const [settings, setSettings] = useState<PlatformSettings | null>(null);
  const [monetizationRequests, setMonetizationRequests] = useState<any[]>([]);
  const [monetizationBusyId, setMonetizationBusyId] = useState<string | null>(null);
  const [cashoutRequests, setCashoutRequests] = useState<any[]>([]);
  const [cashoutBusyId, setCashoutBusyId] = useState<string | null>(null);

  // User management state
  const [userQuery, setUserQuery] = useState('');
  const [inspectedUser, setInspectedUser] = useState<UserProfile | null>(null);
  const [userSearchLoading, setUserSearchLoading] = useState(false);

  // New announcement state
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newType, setNewType] = useState<PlatformAnnouncement['type']>('info');

  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [scheduleClockNow, setScheduleClockNow] = useState(Date.now());
  useEffect(() => { const timer = window.setInterval(() => setScheduleClockNow(Date.now()), 1000); return () => window.clearInterval(timer); }, []);

  if (!isModerator) {
    return (
      <div className="crystal-card max-w-md mx-auto rounded-2xl p-8 text-center border border-[#FF6B6B]/30 space-y-3">
        <ShieldAlert className="w-12 h-12 text-[#FF6B6B] mx-auto" />
        <h3 className="text-base font-bold text-[#F1F8FF]">Access Denied</h3>
        <p className="text-xs text-[#A8BCD7]">
          This control sanctuary is restricted to authorized OpenCirkle moderators and administrators.
        </p>
      </div>
    );
  }

  const loadData = async () => {
    setLoading(true);
    try {
      const [stats, repList, logs, platSettings, activeAnn] = await Promise.all([
        fetchAdminAnalytics(),
        fetchPendingReports(),
        fetchAdminAuditLogs(25),
        fetchPlatformSettings(),
        fetchActiveAnnouncements(),
      ]);

      setAnalytics(stats);
      setReports(repList);
      setAuditLogs(logs);
      setSettings(platSettings);
      setAnnouncements(activeAnn);
    } catch (err: any) {
      setError(err?.message || 'Failed to load administrative telemetry.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (!isAdmin) return;
    return onSnapshot(collection(db, 'cashoutRequests'), (snapshot) => {
      setCashoutRequests(snapshot.docs.map((d) => ({ id: d.id, ...d.data() })).sort((a: any, b: any) => Number(b.submittedAt || 0) - Number(a.submittedAt || 0)));
    }, (err) => setError(err?.message || 'Could not load cash-out requests.'));
  }, [isAdmin]);

  const creditCreatorBalance = async (item: any) => {
    const uid = String(item.uid || item.id || '');
    if (!uid) return setError('Missing creator UID.');
    const raw = window.prompt(`Add earnings credit to @${item.username || uid} (BDT ৳). Only enter verified earnings.`);
    if (raw === null) return;
    const amount = Number(raw);
    if (!Number.isFinite(amount) || amount <= 0 || amount > 100000000) return setError('Enter a valid amount greater than ৳0 and at most ৳100,000,000.');
    try {
      const walletRef = doc(db, 'creatorWallets', uid);
      await runTransaction(db, async (tx) => {
        const snap = await tx.get(walletRef);
        const data = snap.data() || {};
        const balance = Math.max(0, Number(data.availableBalance || 0));
        const earned = Math.max(0, Number(data.totalEarned || 0));
        tx.set(walletRef, { uid, availableBalance: Number((balance + amount).toFixed(2)), totalEarned: Number((earned + amount).toFixed(2)), currency: 'BDT', updatedAt: Date.now(), updatedBy: currentUserProfile?.uid || '', lastCreditReason: 'admin_verified_earnings_credit' }, { merge: true });
      });
      setFeedback(`Added ৳${amount.toLocaleString()} to @${item.username || uid}'s available balance.`);
    } catch (err: any) { setError(err?.message || 'Could not credit creator balance.'); }
  };

  const markCashoutPaid = async (item: any) => {
    const uid = String(item.uid || '');
    const amount = Number(item.amount || 0);
    if (!uid || !Number.isFinite(amount) || amount <= 0) { setError('This cash-out request has an invalid user or amount.'); return; }
    if (!window.confirm(`Only continue AFTER sending ৳${amount.toLocaleString()} to ${item.payoutMethod} ${item.payoutNumber} using your official merchant/account app. Mark this payout as paid?`)) return;
    setCashoutBusyId(item.id);
    try {
      const now = Date.now();
      const walletRef = doc(db, 'creatorWallets', uid);
      const requestRef = doc(db, 'cashoutRequests', item.id);
      await runTransaction(db, async (tx) => {
        const [walletSnap, requestSnap] = await Promise.all([tx.get(walletRef), tx.get(requestRef)]);
        if (!requestSnap.exists()) throw new Error('Cash-out request no longer exists.');
        const current = requestSnap.data();
        if (!['pending', 'processing'].includes(String(current.status))) throw new Error('This cash-out request has already been handled.');
        const walletData = walletSnap.data() || {};
        const balance = Math.max(0, Number(walletData.availableBalance || 0));
        if (balance < amount) throw new Error('Wallet balance is lower than the requested payout. Please reconcile the balance before paying.');
        tx.set(walletRef, { availableBalance: Number((balance - amount).toFixed(2)), totalPaid: Number((Math.max(0, Number(walletData.totalPaid || 0)) + amount).toFixed(2)), updatedAt: now, updatedBy: currentUserProfile?.uid || '' }, { merge: true });
        tx.update(requestRef, { status: 'paid', paidAt: now, paidBy: currentUserProfile?.uid || '', paymentConfirmation: 'admin_confirmed_external_transfer' });
      });
      const notificationRef = doc(collection(db, 'notifications'));
      await setDoc(notificationRef, { id: notificationRef.id, recipientId: uid, senderId: currentUserProfile?.uid || '', senderUsername: currentUserProfile?.username || 'opencirkle_admin', senderDisplayName: 'OpenCirkle Payout Team', senderAvatarSymbol: 'gem', senderAvatarColor: 'electric', type: 'monetization_payout', targetPostId: '', textSnippet: `আপনার ৳${amount.toLocaleString()} ${item.payoutMethod} পেআউট Admin দ্বারা paid হিসেবে নিশ্চিত করা হয়েছে।`, read: false, createdAt: now });
      setFeedback(`৳${amount.toLocaleString()} payout marked paid. The transfer must already have been sent externally.`);
    } catch (err: any) { setError(err?.message || 'Could not process this payout.'); }
    finally { setCashoutBusyId(null); }
  };

  // Subscribe to the real Firestore monetization queue for administrators.
  useEffect(() => {
    if (!isAdmin) return;
    const unsubscribe = onSnapshot(collection(db, 'monetizationRequests'), (snapshot) => {
      setMonetizationRequests(snapshot.docs
        .map((d) => ({ ...d.data(), id: d.id }))
        .sort((a, b) => Number(b.submittedAt || 0) - Number(a.submittedAt || 0)));
    }, (err) => {
      console.error('Could not subscribe to monetization applications:', err);
      setError(err?.message || 'Could not load monetization applications.');
    });
    return () => unsubscribe();
  }, [isAdmin]);

  const reviewMonetizationApplication = async (item: any, decision: 'approved' | 'rejected') => {
    if (!currentUserProfile || !isAdmin) return;
    const uid = String(item.uid || item.id || '');
    if (!uid) { setError('Application is missing its user UID.'); return; }
    if ((item.status || 'pending') !== 'pending') { setError('This application has already been reviewed.'); return; }
    if (!window.confirm(`${decision === 'approved' ? 'Approve' : 'Reject'} monetization for @${item.username || uid}?`)) return;
    setMonetizationBusyId(uid);
    setError(null);
    setFeedback(null);
    try {
      const now = Date.now();
      const message = decision === 'approved'
        ? 'অভিনন্দন! 🎉 আপনার Monetization আবেদন সফলভাবে অনুমোদিত হয়েছে। এখন থেকে আপনি OpenCirkle Monetization Affiliate Partner। আপনার যোগ্য পোস্টের আয় Monetize সেকশনে জমা হবে; প্রযোজ্য পেমেন্ট নিয়ম অনুযায়ী উত্তোলন করা যাবে।'
        : 'আপনার OpenCirkle Monetization আবেদনটি এই মুহূর্তে অনুমোদিত হয়নি। বিস্তারিত জানতে Support-এর সঙ্গে যোগাযোগ করুন।';
      await setDoc(doc(db, 'monetizationRequests', uid), {
        status: decision, reviewedAt: now, reviewedBy: currentUserProfile.uid, reviewMessage: message,
      }, { merge: true });
      await setDoc(doc(db, 'users', uid), decision === 'approved'
        ? { monetizationEnabled: true, monetizationStatus: 'active', monetizationEnabledAt: now, monetizationApprovedBy: currentUserProfile.uid }
        : { monetizationEnabled: false, monetizationStatus: 'rejected', monetizationRejectedAt: now }, { merge: true });
      const notificationRef = doc(collection(db, 'notifications'));
      await setDoc(notificationRef, {
        id: notificationRef.id, recipientId: uid, senderId: currentUserProfile.uid,
        senderUsername: currentUserProfile.username || 'opencirkle_admin',
        senderDisplayName: 'OpenCirkle Monetization Team',
        senderAvatarSymbol: currentUserProfile.avatarSymbol || 'gem',
        senderAvatarColor: currentUserProfile.avatarColor || 'electric',
        type: decision === 'approved' ? 'monetization_approved' : 'monetization_rejected',
        targetPostId: '', textSnippet: message, read: false, createdAt: now,
      });
      setFeedback(decision === 'approved'
        ? 'Application approved and personal notification sent.'
        : 'Application rejected and personal notification sent.');
      await loadData();
    } catch (err: any) {
      setError(err?.message || 'Could not review this monetization application. Check Firestore permissions.');
    } finally {
      setMonetizationBusyId(null);
    }
  };

  const handleResolveReport = async (
    report: ReportItem,
    status: 'resolved' | 'dismissed',
    action: string
  ) => {
    if (!currentUserProfile) return;
    try {
      await resolveReport(report.id, currentUserProfile, status, action);
      setReports((prev) => prev.filter((r) => r.id !== report.id));
      setAnalytics((prev) => ({ ...prev, pendingReports: Math.max(0, prev.pendingReports - 1) }));
      setFeedback(`Report marked as ${status}.`);
      setTimeout(() => setFeedback(null), 3000);
      loadData();
    } catch (err: any) {
      setError(err?.message || 'Failed to resolve report.');
    }
  };

  const handleDeleteViolatingContent = async (report: ReportItem) => {
    if (!currentUserProfile) return;
    try {
      if (report.targetType === 'post') {
        await deletePost(report.targetId, currentUserProfile.uid, true);
      }
      await handleResolveReport(report, 'resolved', `Deleted ${report.targetType}`);
    } catch (err: any) {
      setError(err?.message || 'Failed to delete reported content.');
    }
  };

  const handleSearchUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userQuery.trim()) return;

    setUserSearchLoading(true);
    setError(null);
    try {
      const user = await getUserByUsername(userQuery.trim());
      setInspectedUser(user);
      if (!user) {
        setError(`User @${userQuery.trim()} was not found.`);
      }
    } catch (err: any) {
      setError(err?.message || 'Search failed.');
    } finally {
      setUserSearchLoading(false);
    }
  };

  const handleToggleVerified = async (targetUser: UserProfile) => {
    if (!currentUserProfile || !isAdmin) return;
    try {
      const nextStatus = !targetUser.verified;
      await toggleUserVerification(currentUserProfile, targetUser.uid, nextStatus);
      setInspectedUser({ ...targetUser, verified: nextStatus });
      setFeedback(`User verification status updated.`);
      setTimeout(() => setFeedback(null), 3000);
    } catch (err: any) {
      setError(err?.message || 'Failed to update verification.');
    }
  };

  const handleUpdateStatus = async (
    targetUser: UserProfile,
    newStatus: 'active' | 'suspended' | 'banned'
  ) => {
    if (!currentUserProfile || !isAdmin) return;
    try {
      await updateUserModerationStatus(currentUserProfile, targetUser.uid, newStatus);
      setInspectedUser({ ...targetUser, status: newStatus });
      setFeedback(`User status set to ${newStatus}.`);
      setTimeout(() => setFeedback(null), 3000);
    } catch (err: any) {
      setError(err?.message || 'Failed to update user status.');
    }
  };

  const handleUpdateRole = async (targetUser: UserProfile, newRole: UserRole) => {
    if (!currentUserProfile || !isSuperAdmin) {
      setError('Only Super Admins can alter user authorization roles.');
      return;
    }
    try {
      await updateUserRole(currentUserProfile, targetUser.uid, newRole);
      setInspectedUser({ ...targetUser, role: newRole });
      setFeedback(`User role changed to ${newRole}.`);
      setTimeout(() => setFeedback(null), 3000);
    } catch (err: any) {
      setError(err?.message || 'Failed to update role.');
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUserProfile || !settings || !isAdmin) return;
    try {
      if (settings.scheduledServiceEnabled) {
        const selectedEnd = settings.scheduledServiceMode === 'closed' ? (settings.appClosedReopenAt || settings.serviceOpenAt) : (settings.maintenanceEndAt || settings.serviceOpenAt);
        if (!settings.serviceCloseAt || !selectedEnd || selectedEnd <= settings.serviceCloseAt) {
          setError('Scheduled close/open time invalid. Reopen time must be later than close time.');
          return;
        }
      }
      if (settings.dailyScheduleEnabled && (!/^([01]\d|2[0-3]):[0-5]\d$/.test(settings.dailyCloseTime || '') || !/^([01]\d|2[0-3]):[0-5]\d$/.test(settings.dailyOpenTime || '') || settings.dailyCloseTime === settings.dailyOpenTime)) {
        setError('Set two valid, different daily close and reopen times.'); return;
      }
      if (settings.appUpdateEnabled && (!Number.isInteger(Number(settings.appUpdateVersionCode)) || Number(settings.appUpdateVersionCode) < 1)) {
        throw new Error('Enter a valid minimum app version code (1 or higher).');
      }
      if (settings.appUpdateEnabled && settings.appUpdateUrl) {
        const updateUrl = new URL(settings.appUpdateUrl);
        if (updateUrl.protocol !== 'https:') throw new Error('App update link must use HTTPS.');
      } else if (settings.appUpdateEnabled && !settings.appUpdateUrl?.trim()) {
        throw new Error('Enter an update download URL or turn off app updates.');
      }
      const timezoneSettings = settings.dailyScheduleEnabled ? { dailyTimezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC' } : {};
      await updatePlatformSettings(currentUserProfile, { ...settings, ...timezoneSettings });
      setFeedback('Platform settings updated successfully.');
      setTimeout(() => setFeedback(null), 3000);
    } catch (err: any) {
      setError(err?.message || 'Failed to save settings.');
    }
  };

  const handleCreateAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUserProfile || !newTitle.trim() || !newContent.trim()) return;
    try {
      const ann = await createAnnouncement(currentUserProfile, newTitle, newContent, newType);
      setAnnouncements((prev) => [ann, ...prev]);
      setNewTitle('');
      setNewContent('');
      setFeedback('Platform announcement published.');
      setTimeout(() => setFeedback(null), 3000);
    } catch (err: any) {
      setError(err?.message || 'Failed to create announcement.');
    }
  };

  return (
    <div className="max-w-5xl w-full mx-auto pb-16 space-y-6">
      {/* Control Center Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#168BFF]/20">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#0D47A1] via-[#168BFF] to-[#8DDCFF] flex items-center justify-center p-0.5 shadow-[0_0_20px_rgba(22,139,255,0.4)]">
            <div className="w-full h-full bg-[#050A18] rounded-[14px] flex items-center justify-center">
              <ShieldAlert className="w-5 h-5 text-[#8DDCFF]" />
            </div>
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-[#F1F8FF] tracking-tight">
              Super Admin Control Center
            </h1>
            <p className="text-xs text-[#A8BCD7]">
              Node Governance · Role: <span className="text-[#8DDCFF] uppercase font-mono">{currentUserProfile?.role}</span>
            </p>
          </div>
        </div>

        <button
          onClick={loadData}
          className="self-start sm:self-auto flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-[#071A38] text-xs text-[#8DDCFF] border border-[#168BFF]/25 hover:bg-[#0D47A1]/40 transition-colors"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Telemetry</span>
        </button>
      </div>

      {feedback && (
        <div className="p-3 rounded-xl bg-[#168BFF]/20 border border-[#168BFF]/40 text-xs text-[#8DDCFF] font-medium text-center">
          {feedback}
        </div>
      )}

      {error && (
        <div className="p-3 rounded-xl bg-[#FF6B6B]/15 border border-[#FF6B6B]/30 text-xs text-[#FF6B6B] flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* KPI Stats Grid (Tabular Numerals) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="crystal-card rounded-2xl p-4 border border-[#168BFF]/20 space-y-1">
          <span className="text-xs text-[#A8BCD7] flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5 text-[#168BFF]" /> Users
          </span>
          <span className="text-2xl font-mono font-bold text-[#F1F8FF] tabular-nums block">
            {analytics.totalUsers}
          </span>
        </div>

        <div className="crystal-card rounded-2xl p-4 border border-[#168BFF]/20 space-y-1">
          <span className="text-xs text-[#A8BCD7] flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5 text-[#8DDCFF]" /> Discourses
          </span>
          <span className="text-2xl font-mono font-bold text-[#F1F8FF] tabular-nums block">
            {analytics.totalPosts}
          </span>
        </div>

        <div className="crystal-card rounded-2xl p-4 border border-[#FF6B6B]/25 space-y-1">
          <span className="text-xs text-[#A8BCD7] flex items-center gap-1.5">
            <ShieldAlert className="w-3.5 h-3.5 text-[#FF6B6B]" /> Pending Reports
          </span>
          <span className="text-2xl font-mono font-bold text-[#FF6B6B] tabular-nums block">
            {analytics.pendingReports}
          </span>
        </div>

        <div className="crystal-card rounded-2xl p-4 border border-[#168BFF]/20 space-y-1">
          <span className="text-xs text-[#A8BCD7] flex items-center gap-1.5">
            <Radio className="w-3.5 h-3.5 text-[#FFD166]" /> Announcements
          </span>
          <span className="text-2xl font-mono font-bold text-[#F1F8FF] tabular-nums block">
            {analytics.activeAnnouncements}
          </span>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 p-1 bg-[#071A38]/70 border border-[#168BFF]/20 rounded-xl overflow-x-auto">
        {[
          { id: 'reports', label: `Moderation Queue (${reports.length})`, icon: ShieldAlert },
          { id: 'users', label: 'User Governance', icon: Users },
          ...(isAdmin ? [{ id: 'verification', label: 'ID Verification', icon: BadgeCheck }] : []),
          ...(isAdmin ? [{ id: 'monetization', label: `Monetization (${monetizationRequests.filter((r) => r.status === 'pending').length})`, icon: Wallet }] : []),
          { id: 'announcements', label: 'Announcements', icon: Radio },
          ...(isAdmin ? [{ id: 'settings', label: 'Platform Parameters', icon: Sliders }] : []),
          { id: 'audit', label: 'Security Audit Log', icon: History },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-all shrink-0 ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-[#0D47A1] to-[#168BFF] text-white shadow-[0_0_12px_rgba(22,139,255,0.4)]'
                  : 'text-[#A8BCD7] hover:text-[#F1F8FF]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {activeTab === 'verification' && isAdmin && <VerificationRequestsPanel />}

      {activeTab === 'monetization' && isAdmin && (
        <div className="space-y-4">
          <div className="crystal-card rounded-2xl p-5 border border-[#168BFF]/20">
            <h3 className="text-sm font-bold text-[#F1F8FF]">Creator monetization applications</h3>
            <p className="text-xs text-[#A8BCD7] mt-1">Review submitted applications, approve or reject, and send a personal in-app notification. Approval activates the account flag; it does not fabricate earnings.</p>
          </div>
          {monetizationRequests.length === 0 ? (
            <div className="crystal-card rounded-2xl p-8 text-center text-xs text-[#A8BCD7] border border-[#168BFF]/15">No monetization applications found.</div>
          ) : monetizationRequests.map((item) => (
            <article key={item.id} className="crystal-card rounded-2xl p-5 border border-[#168BFF]/20 space-y-3">
              <div className="flex items-start justify-between gap-3 flex-wrap">
                <div>
                  <h4 className="text-sm font-bold text-[#F1F8FF]">@{item.username || 'unknown'} <span className="text-xs font-normal text-[#A8BCD7]">· {item.displayName || ''}</span></h4>
                  <p className="text-[11px] text-[#A8BCD7]">UID: {item.uid || item.id}</p>
                </div>
                <span className={`text-[10px] uppercase rounded-full border px-2 py-1 ${item.status === 'approved' ? 'border-emerald-500/40 text-emerald-300' : item.status === 'rejected' ? 'border-red-500/40 text-red-300' : 'border-amber-500/40 text-amber-200'}`}>{item.status || 'pending'}</span>
              </div>
              <div className="grid sm:grid-cols-2 gap-2 text-xs text-[#A8BCD7]">
                <p>Followers at apply: <b className="text-white">{Number(item.followersAtApplication || 0).toLocaleString()}</b></p>
                <p>Total views at apply: <b className="text-white">{Number(item.totalViewsAtApplication || 0).toLocaleString()}</b></p>
                <p>Document: <b className="text-white">{item.documentType || '—'}</b></p>
                <p>ID number: <b className="text-white">{item.documentNumber || '—'}</b></p>
                <p>Payout: <b className="text-white">{item.payoutMethod || '—'} · {item.payoutNumber || '—'}</b></p>
                <p>Submitted: <b className="text-white">{item.submittedAt ? new Date(item.submittedAt).toLocaleString() : '—'}</b></p>
              </div>
              {item.status === 'pending' && (
                <div className="flex gap-2 flex-wrap">
                  <button disabled={monetizationBusyId === (item.uid || item.id)} onClick={() => reviewMonetizationApplication(item, 'approved')} className="px-4 py-2 rounded-lg text-xs font-bold bg-emerald-700 text-white disabled:opacity-50">{monetizationBusyId === (item.uid || item.id) ? 'Saving…' : 'Approve & Notify'}</button>
                  <button disabled={monetizationBusyId === (item.uid || item.id)} onClick={() => reviewMonetizationApplication(item, 'rejected')} className="px-4 py-2 rounded-lg text-xs font-bold bg-red-700 text-white disabled:opacity-50">Reject & Notify</button>
                </div>
              )}
              {item.status === 'approved' && <button onClick={() => creditCreatorBalance(item)} className="px-4 py-2 rounded-lg text-xs font-bold bg-blue-700 text-white">Add verified earnings balance</button>}
            </article>
          ))}
          <div className="crystal-card rounded-2xl p-5 border border-[#168BFF]/20 space-y-3">
            <div><h3 className="text-sm font-bold text-[#F1F8FF]">Creator cash-out queue</h3><p className="text-xs text-[#A8BCD7] mt-1">Pay requests within 24–48 hours. bKash/Nagad money transfer is external: send the money first, then use “Pay All / Mark Paid” to record it and deduct the wallet balance.</p></div>
            {cashoutRequests.length === 0 ? <p className="text-xs text-[#A8BCD7]">No cash-out requests yet.</p> : cashoutRequests.map((item) => <article key={item.id} className="rounded-xl border border-white/10 p-3 space-y-2"><div className="flex flex-wrap items-start justify-between gap-2"><div><p className="text-sm font-bold text-white">@{item.username || item.uid}</p><p className="text-xs text-[#A8BCD7]">{item.payoutMethod} · {item.payoutNumber}</p><p className="text-[11px] text-[#A8BCD7]">Requested {item.submittedAt ? new Date(item.submittedAt).toLocaleString() : '—'}</p></div><div className="text-right"><p className="text-lg font-extrabold text-white">৳{Number(item.amount || 0).toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:2})}</p><p className="text-xs text-[#8DDCFF]">{String(item.status || 'pending').toUpperCase()}</p></div></div>{['pending','processing'].includes(item.status) && <button disabled={cashoutBusyId === item.id} onClick={() => markCashoutPaid(item)} className="rounded-lg px-4 py-2 text-xs font-bold bg-emerald-700 text-white disabled:opacity-50">{cashoutBusyId === item.id ? 'Processing…' : 'Pay All / Mark Paid'}</button>}</article>)}
          </div>
        </div>
      )}

      {/* Tab 1: Moderation Reports Queue */}
      {activeTab === 'reports' && (
        <div className="space-y-4">
          {reports.length === 0 ? (
            <div className="crystal-card rounded-2xl p-8 text-center text-xs text-[#A8BCD7] border border-[#168BFF]/15">
              <CheckCircle2 className="w-8 h-8 text-[#8DDCFF] mx-auto mb-2" />
              <span>The crystal crypt is serene. Zero pending reports require moderation.</span>
            </div>
          ) : (
            reports.map((report) => (
              <div
                key={report.id}
                className="crystal-card rounded-2xl p-5 border border-[#FF6B6B]/25 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-[#FF6B6B]/15 text-[#FF6B6B] border border-[#FF6B6B]/30">
                      {report.reason}
                    </span>
                    <span className="text-xs text-[#A8BCD7]">
                      Target Type: <strong className="text-[#F1F8FF] uppercase">{report.targetType}</strong>
                    </span>
                  </div>

                  <span className="text-[10px] font-mono text-[#A8BCD7]">
                    {new Date(report.createdAt).toLocaleString()}
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-[#050A18]/80 border border-[#168BFF]/15 text-xs space-y-1">
                  <p className="text-[#8DDCFF] font-semibold">
                    Target Content Snippet:
                  </p>
                  <p className="italic text-[#F1F8FF]/90">
                    "{report.targetSnippet || 'No snippet captured'}"
                  </p>
                  {report.explanation && (
                    <p className="text-[11px] text-[#A8BCD7] pt-1">
                      Reporter explanation: "{report.explanation}"
                    </p>
                  )}
                </div>

                <div className="flex items-center justify-between pt-2">
                  <span className="text-[11px] text-[#A8BCD7]">
                    Reported by @{report.reporterUsername}
                  </span>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleResolveReport(report, 'dismissed', 'Dismissed by moderator')}
                      className="px-3 py-1.5 text-xs text-[#A8BCD7] hover:text-[#F1F8FF] hover:bg-[#071A38] rounded-lg transition-colors"
                    >
                      Dismiss
                    </button>

                    {report.targetType === 'post' && (
                      <button
                        onClick={() => handleDeleteViolatingContent(report)}
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-[#FF6B6B]/80 hover:bg-[#FF6B6B] rounded-lg transition-colors flex items-center gap-1.5"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Delete Content</span>
                      </button>
                    )}

                    <button
                      onClick={() => handleResolveReport(report, 'resolved', 'Marked resolved')}
                      className="px-3 py-1.5 text-xs font-semibold text-white bg-[#168BFF] hover:bg-[#168BFF]/80 rounded-lg transition-colors"
                    >
                      Resolve
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Tab 2: User Governance */}
      {activeTab === 'users' && (
        <div className="space-y-5">
          <form onSubmit={handleSearchUser} className="flex gap-2">
            <input
              type="text"
              value={userQuery}
              onChange={(e) => setUserQuery(e.target.value)}
              placeholder="Search user by username (e.g. alice)..."
              className="flex-1 bg-[#050A18] border border-[#168BFF]/25 rounded-xl px-4 py-2.5 text-xs text-[#F1F8FF] placeholder-[#A8BCD7]/50 focus:outline-none focus:border-[#168BFF]"
            />
            <button
              type="submit"
              disabled={userSearchLoading}
              className="px-5 py-2.5 text-xs font-semibold text-white bg-gradient-to-r from-[#0D47A1] to-[#168BFF] rounded-xl flex items-center gap-2"
            >
              <Search className="w-3.5 h-3.5" />
              <span>{userSearchLoading ? 'Searching...' : 'Inspect Node'}</span>
            </button>
          </form>

          {inspectedUser && (
            <div className="crystal-card rounded-2xl p-6 border border-[#168BFF]/25 space-y-4">
              <div className="flex items-center gap-4 pb-4 border-b border-[#168BFF]/15">
                <CrystalAvatar
                  displayName={inspectedUser.displayName}
                  username={inspectedUser.username}
                  avatarSymbol={inspectedUser.avatarSymbol}
                  avatarUrl={inspectedUser.avatarUrl}
                  avatarColor={inspectedUser.avatarColor}
                  size="lg"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-[#F1F8FF]">
                      {inspectedUser.displayName}
                    </h3>
                    {inspectedUser.verified && (
                      <CheckCircle2 className="w-4 h-4 text-[#8DDCFF]" />
                    )}
                  </div>
                  <p className="text-xs font-mono text-[#A8BCD7]">@{inspectedUser.username}</p>
                  <p className="text-[11px] font-mono text-[#A8BCD7]/60">UID: {inspectedUser.uid}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-[#050A18] border border-[#168BFF]/15">
                  <span className="text-[#A8BCD7] block text-[10px]">Current Role</span>
                  <span className="font-bold text-[#8DDCFF] uppercase">{inspectedUser.role}</span>
                </div>
                <div className="p-3 rounded-xl bg-[#050A18] border border-[#168BFF]/15">
                  <span className="text-[#A8BCD7] block text-[10px]">Account Status</span>
                  <span
                    className={`font-bold uppercase ${
                      inspectedUser.status === 'active'
                        ? 'text-[#8DDCFF]'
                        : inspectedUser.status === 'suspended'
                        ? 'text-[#FFD166]'
                        : 'text-[#FF6B6B]'
                    }`}
                  >
                    {inspectedUser.status}
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-[#050A18] border border-[#168BFF]/15">
                  <span className="text-[#A8BCD7] block text-[10px]">Posts Count</span>
                  <span className="font-bold text-[#F1F8FF] font-mono">{inspectedUser.postsCount}</span>
                </div>
                <div className="p-3 rounded-xl bg-[#050A18] border border-[#168BFF]/15">
                  <span className="text-[#A8BCD7] block text-[10px]">Followers</span>
                  <span className="font-bold text-[#F1F8FF] font-mono">{inspectedUser.followersCount}</span>
                </div>
              </div>

              {/* Action Controls */}
              <div className="space-y-3 pt-3 border-t border-[#168BFF]/15">
                <h4 className="text-xs font-bold text-[#8DDCFF] uppercase tracking-wider">
                  Governance Controls
                </h4>

                <div className="flex flex-wrap items-center gap-3">
                  {/* Verified Badge Toggle */}
                  <button
                    onClick={() => handleToggleVerified(inspectedUser)}
                    className="px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-[#071A38] text-[#8DDCFF] border border-[#168BFF]/30 hover:bg-[#0D47A1]/40 transition-colors flex items-center gap-1.5"
                  >
                    <BadgeCheck className="w-3.5 h-3.5" />
                    <span>{inspectedUser.verified ? 'Revoke Verification' : 'Grant Verified Badge'}</span>
                  </button>

                  {/* Suspend / Unsuspend */}
                  {inspectedUser.status === 'active' ? (
                    <button
                      onClick={() => handleUpdateStatus(inspectedUser, 'suspended')}
                      className="px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-[#FFD166]/15 text-[#FFD166] border border-[#FFD166]/30 hover:bg-[#FFD166]/25 transition-colors"
                    >
                      Suspend Account
                    </button>
                  ) : (
                    <button
                      onClick={() => handleUpdateStatus(inspectedUser, 'active')}
                      className="px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-[#168BFF]/20 text-[#8DDCFF] border border-[#168BFF]/40 hover:bg-[#168BFF]/30 transition-colors"
                    >
                      Restore Active Status
                    </button>
                  )}

                  {/* Ban User */}
                  {inspectedUser.status !== 'banned' && (
                    <button
                      onClick={() => handleUpdateStatus(inspectedUser, 'banned')}
                      className="px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-[#FF6B6B]/15 text-[#FF6B6B] border border-[#FF6B6B]/30 hover:bg-[#FF6B6B]/25 transition-colors"
                    >
                      Ban Account
                    </button>
                  )}
                </div>

                {/* Role Management (Super Admin Exclusive) */}
                {isSuperAdmin && (
                  <div className="pt-2">
                    <span className="text-[11px] text-[#A8BCD7] block mb-1.5">
                      Assign Role (Super Admin Privilege):
                    </span>
                    <div className="flex items-center gap-2">
                      {(['user', 'moderator', 'admin', 'superadmin'] as UserRole[]).map((r) => (
                        <button
                          key={r}
                          onClick={() => handleUpdateRole(inspectedUser, r)}
                          disabled={inspectedUser.role === r}
                          className={`px-3 py-1 text-xs font-mono uppercase rounded-lg border transition-all ${
                            inspectedUser.role === r
                              ? 'bg-[#168BFF] text-white border-[#168BFF]'
                              : 'bg-[#050A18] text-[#A8BCD7] border-[#168BFF]/20 hover:border-[#168BFF]/50'
                          }`}
                        >
                          {r}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Announcements */}
      {activeTab === 'announcements' && (
        <div className="space-y-6">
          <form onSubmit={handleCreateAnnouncement} className="crystal-card rounded-2xl p-5 border border-[#168BFF]/20 space-y-4">
            <h3 className="text-xs font-bold text-[#8DDCFF] uppercase tracking-wider flex items-center gap-2">
              <Radio className="w-4 h-4" /> Broadcast Platform Announcement
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2">
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="Announcement title..."
                  className="w-full bg-[#050A18] border border-[#168BFF]/25 rounded-xl px-3.5 py-2 text-xs text-[#F1F8FF] focus:outline-none focus:border-[#168BFF]"
                  required
                />
              </div>

              <div>
                <select
                  value={newType}
                  onChange={(e) => setNewType(e.target.value as any)}
                  className="w-full bg-[#050A18] border border-[#168BFF]/25 rounded-xl px-3 py-2 text-xs text-[#F1F8FF] focus:outline-none focus:border-[#168BFF]"
                >
                  <option value="info">Information</option>
                  <option value="feature">New Feature</option>
                  <option value="maintenance">Maintenance</option>
                  <option value="alert">Critical Alert</option>
                </select>
              </div>
            </div>

            <textarea
              value={newContent}
              onChange={(e) => setNewContent(e.target.value)}
              placeholder="Announcement text details..."
              rows={3}
              className="w-full bg-[#050A18] border border-[#168BFF]/25 rounded-xl p-3 text-xs text-[#F1F8FF] focus:outline-none focus:border-[#168BFF] resize-none"
              required
            />

            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-white bg-gradient-to-r from-[#0D47A1] to-[#168BFF] rounded-xl shadow-[0_0_15px_rgba(22,139,255,0.4)]"
            >
              Publish Broadcast
            </button>
          </form>

          {/* Active announcements */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-[#A8BCD7] uppercase tracking-wider">
              Active Broadcasts ({announcements.length})
            </h4>

            {announcements.map((ann) => (
              <div
                key={ann.id}
                className="crystal-card rounded-2xl p-4 border border-[#168BFF]/20 space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#F1F8FF]">{ann.title}</span>
                  <span className="text-[10px] font-mono text-[#8DDCFF] uppercase px-2 py-0.5 rounded bg-[#168BFF]/15">
                    {ann.type}
                  </span>
                </div>
                <p className="text-xs text-[#A8BCD7] leading-relaxed">{ann.content}</p>
                <span className="text-[10px] font-mono text-[#A8BCD7]/50 block">
                  Broadcasted by {ann.createdBy} · {new Date(ann.createdAt).toLocaleDateString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Platform Settings */}
      {activeTab === 'settings' && settings && (
        <form onSubmit={handleSaveSettings} className="crystal-card rounded-2xl p-6 border border-[#168BFF]/20 space-y-5">
          <h3 className="text-xs font-bold text-[#8DDCFF] uppercase tracking-wider flex items-center gap-2">
            <Sliders className="w-4 h-4" /> Global Platform Parameters
          </h3>

          <div>
            <label className="block text-xs font-semibold text-[#F1F8FF] mb-1.5">
              Maximum Post Character Limit (Strictly Text Only)
            </label>
            <input
              type="number"
              value={settings.postCharLimit}
              onChange={(e) => setSettings({ ...settings, postCharLimit: parseInt(e.target.value) || 5000 })}
              min={100}
              max={10000}
              className="w-full sm:w-64 bg-[#050A18] border border-[#168BFF]/25 rounded-xl px-3.5 py-2 text-xs text-[#F1F8FF] font-mono tabular-nums focus:outline-none focus:border-[#168BFF]"
            />
            <p className="text-[11px] text-[#A8BCD7] mt-1">Default: 5,000 characters.</p>
          </div>

          <div className="flex items-center justify-between p-3.5 rounded-xl bg-[#050A18] border border-[#168BFF]/15">
            <div>
              <p className="text-xs font-semibold text-[#F1F8FF]">Open Registration</p>
              <p className="text-[11px] text-[#A8BCD7]">Permit new accounts to register.</p>
            </div>
            <input
              type="checkbox"
              checked={settings.allowRegistrations}
              onChange={(e) => setSettings({ ...settings, allowRegistrations: e.target.checked })}
              className="w-4 h-4 rounded text-[#168BFF]"
            />
          </div>

          <div className="rounded-2xl border border-amber-300/25 bg-gradient-to-br from-[#15172A] to-[#07152B] p-4 sm:p-5 space-y-4">
            <div className="flex items-start gap-3">
              <div className="rounded-xl bg-amber-300/10 p-2.5 text-amber-200"><AlertTriangle className="h-5 w-5" /></div>
              <div className="flex-1">
                <p className="text-sm font-bold text-[#F1F8FF]">Global App Lock / Service Screen</p>
                <p className="mt-1 text-[11px] leading-5 text-[#A8BCD7]">এটি চালু করলে সাধারণ user পুরো app ব্যবহার করতে পারবে না। Admin/Super Admin app ব্যবহার করে এই mode বন্ধ করতে পারবেন। Firebase-এর live setting থেকে সবার app-এ সঙ্গে সঙ্গে প্রযোজ্য হবে।</p>
              </div>
            </div>
            <label className="flex items-center justify-between gap-4 rounded-xl border border-[#168BFF]/20 bg-[#050A18]/70 p-3.5">
              <span><strong className="block text-xs text-[#F1F8FF]">Enable Global Lock</strong><span className="mt-1 block text-[10px] text-[#A8BCD7]">ON = পুরো app lock · OFF = স্বাভাবিক app</span></span>
              <input type="checkbox" checked={(settings.serviceMode || (settings.maintenanceMode ? 'maintenance' : 'normal')) !== 'normal'} onChange={(e) => setSettings({ ...settings, maintenanceMode: e.target.checked, serviceMode: e.target.checked ? ((settings.serviceMode && settings.serviceMode !== 'normal') ? settings.serviceMode : 'maintenance') : 'normal' })} className="h-5 w-5 accent-[#168BFF]" />
            </label>
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-[#F1F8FF]">Screen Type</label>
              <select value={settings.serviceMode || (settings.maintenanceMode ? 'maintenance' : 'normal')} onChange={(e) => { const mode = e.target.value as NonNullable<PlatformSettings['serviceMode']>; setSettings({ ...settings, serviceMode: mode, maintenanceMode: mode === 'maintenance' }); }} className="w-full rounded-xl border border-[#168BFF]/25 bg-[#050A18] px-3.5 py-3 text-xs text-[#F1F8FF]">
                <option value="normal">Normal App (Unlock)</option>
                <option value="maintenance">Maintenance Mode</option><option value="closed">App Closed</option><option value="server_error">Server Error</option>
                <option value="not_found">404 — Page Not Found</option>
                <option value="try_again">503 — Try Again Later</option>
              </select>
              <p className="mt-1 text-[10px] text-[#A8BCD7]">শুধু mode select করে Save Parameters চাপলেও lock/unlock হবে।</p>
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-[#F1F8FF]">Message shown to users</label>
              <textarea rows={3} value={settings.serviceModeMessage || ''} onChange={(e) => setSettings({ ...settings, serviceModeMessage: e.target.value })} placeholder="We are improving OpenCirkle. Please try again shortly." className="w-full resize-y rounded-xl border border-[#168BFF]/25 bg-[#050A18] px-3.5 py-3 text-xs leading-5 text-[#F1F8FF]" />
            </div>
          </div>

          <div className="rounded-2xl border border-cyan-300/25 bg-gradient-to-br from-[#071B31] to-[#050A18] p-4 sm:p-5 space-y-4">
            <div>
              <h4 className="text-sm font-bold text-[#F1F8FF]">Scheduled App Availability Timer</h4>
              <p className="mt-1 text-[11px] leading-5 text-[#A8BCD7]">এখানে local date ও time দিয়ে app কখন বন্ধ (maintenance screen) হবে এবং কখন আবার খুলবে সেটি schedule করো। Save Parameters চাপলে online app-এ realtime-এ sync হবে।</p>
            </div>
            <label className="block text-xs font-semibold text-[#F1F8FF]">Scheduled lock screen type
              <select value={settings.scheduledServiceMode || 'maintenance'} onChange={e => setSettings({ ...settings, scheduledServiceMode: e.target.value as 'maintenance' | 'closed' })} className="mt-2 w-full rounded-xl border border-[#168BFF]/25 bg-[#050A18] px-3 py-3 text-xs text-[#F1F8FF]"><option value="maintenance">Maintenance screen</option><option value="closed">App Closed screen</option></select>
            </label>
            <label className="flex items-center justify-between gap-3 rounded-xl border border-cyan-300/20 bg-[#050A18]/70 p-3.5 text-xs text-[#F1F8FF]">
              <span><strong className="block">Enable scheduled close/open</strong><span className="mt-1 block text-[10px] text-[#A8BCD7]">ON করলে schedule manual service mode-কে override করবে</span></span>
              <input type="checkbox" checked={Boolean(settings.scheduledServiceEnabled)} onChange={(e) => setSettings({ ...settings, scheduledServiceEnabled: e.target.checked })} className="h-5 w-5 accent-[#168BFF]" />
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label className="block text-xs font-semibold text-[#F1F8FF]">App close time
                <input type="datetime-local" value={toDateTimeLocal(settings.serviceCloseAt)} onChange={(e) => setSettings({ ...settings, serviceCloseAt: fromDateTimeLocal(e.target.value) })} className="mt-2 w-full rounded-xl border border-[#168BFF]/25 bg-[#050A18] px-3 py-3 text-xs text-[#F1F8FF]" />
                <span className="mt-1 block text-[10px] font-normal text-[#A8BCD7]">এই সময় থেকে সাধারণ user-এর app lock হবে</span>
              </label>
              <label className="block text-xs font-semibold text-[#F1F8FF]">General app reopen time (fallback)
                <input type="datetime-local" value={toDateTimeLocal(settings.serviceOpenAt)} onChange={(e) => setSettings({ ...settings, serviceOpenAt: fromDateTimeLocal(e.target.value) })} className="mt-2 w-full rounded-xl border border-[#168BFF]/25 bg-[#050A18] px-3 py-3 text-xs text-[#F1F8FF]" />
                <span className="mt-1 block text-[10px] font-normal text-[#A8BCD7]">Screen-specific time না দিলে এটি ব্যবহার হবে</span>
              </label>
              <label className="block text-xs font-semibold text-[#F1F8FF]">Maintenance screen end time
                <input type="datetime-local" value={toDateTimeLocal(settings.maintenanceEndAt)} onChange={(e) => setSettings({ ...settings, maintenanceEndAt: fromDateTimeLocal(e.target.value) })} className="mt-2 w-full rounded-xl border border-violet-300/25 bg-[#050A18] px-3 py-3 text-xs text-[#F1F8FF]" />
                <span className="mt-1 block text-[10px] font-normal text-[#A8BCD7]">Maintenance UI-তে এই সময় পর্যন্ত countdown হবে</span>
              </label>
              <label className="block text-xs font-semibold text-[#F1F8FF]">App Closed screen reopen time
                <input type="datetime-local" value={toDateTimeLocal(settings.appClosedReopenAt)} onChange={(e) => setSettings({ ...settings, appClosedReopenAt: fromDateTimeLocal(e.target.value) })} className="mt-2 w-full rounded-xl border border-rose-300/25 bg-[#050A18] px-3 py-3 text-xs text-[#F1F8FF]" />
                <span className="mt-1 block text-[10px] font-normal text-[#A8BCD7]">App Closed UI-তে এই সময় পর্যন্ত countdown হবে</span>
              </label>
            </div>
            <div className="flex flex-wrap gap-2">
              <button type="button" onClick={() => { const close = Date.now() + 60 * 60 * 1000; setSettings({ ...settings, scheduledServiceEnabled: true, serviceCloseAt: close, serviceOpenAt: close + 60 * 60 * 1000, maintenanceEndAt: 0, appClosedReopenAt: 0 }); }} className="rounded-lg border border-cyan-300/25 bg-cyan-300/10 px-3 py-2 text-[11px] font-semibold text-cyan-100 hover:bg-cyan-300/20">Close in 1h · reopen in 2h</button>
              <button type="button" onClick={() => { const close = Date.now() + 6 * 60 * 60 * 1000; setSettings({ ...settings, scheduledServiceEnabled: true, serviceCloseAt: close, serviceOpenAt: close + 2 * 60 * 60 * 1000, maintenanceEndAt: 0, appClosedReopenAt: 0 }); }} className="rounded-lg border border-cyan-300/25 bg-cyan-300/10 px-3 py-2 text-[11px] font-semibold text-cyan-100 hover:bg-cyan-300/20">Close in 6h · reopen in 8h</button>
              <button type="button" onClick={() => { const close = Date.now() + 24 * 60 * 60 * 1000; setSettings({ ...settings, scheduledServiceEnabled: true, serviceCloseAt: close, serviceOpenAt: close + 60 * 60 * 1000, maintenanceEndAt: 0, appClosedReopenAt: 0 }); }} className="rounded-lg border border-cyan-300/25 bg-cyan-300/10 px-3 py-2 text-[11px] font-semibold text-cyan-100 hover:bg-cyan-300/20">Close in 24h · reopen in 25h</button>
              <button type="button" onClick={() => setSettings({ ...settings, scheduledServiceEnabled: false, serviceCloseAt: 0, serviceOpenAt: 0, maintenanceEndAt: 0, appClosedReopenAt: 0 })} className="rounded-lg border border-rose-300/25 bg-rose-300/10 px-3 py-2 text-[11px] font-semibold text-rose-100 hover:bg-rose-300/20">Clear schedule</button>
            </div>
            <p className="text-[10px] text-[#8199B9]">Time zone: {Intl.DateTimeFormat().resolvedOptions().timeZone || 'device local time'}. Presets only fill the fields; review the times and press Save Parameters.</p>
            {settings.scheduledServiceEnabled && (!settings.serviceCloseAt || !(settings.scheduledServiceMode === 'closed' ? (settings.appClosedReopenAt || settings.serviceOpenAt) : (settings.maintenanceEndAt || settings.serviceOpenAt)) || (settings.scheduledServiceMode === 'closed' ? (settings.appClosedReopenAt || settings.serviceOpenAt) : (settings.maintenanceEndAt || settings.serviceOpenAt))! <= settings.serviceCloseAt || settings.serviceCloseAt <= scheduleClockNow) && <p className="rounded-lg border border-amber-300/20 bg-amber-300/10 p-3 text-[11px] text-amber-100">Choose a future close time and a reopen time later than close. If close time is already past, the schedule may lock the app immediately when saved.</p>}
            {settings.scheduledServiceEnabled && settings.serviceCloseAt && (settings.scheduledServiceMode === 'closed' ? (settings.appClosedReopenAt || settings.serviceOpenAt) : (settings.maintenanceEndAt || settings.serviceOpenAt))! > settings.serviceCloseAt && <p className="rounded-lg border border-cyan-300/20 bg-cyan-300/5 p-3 text-[11px] leading-5 text-cyan-100">Close: {new Date(settings.serviceCloseAt).toLocaleString()}<br />Reopen: {new Date((settings.scheduledServiceMode === 'closed' ? (settings.appClosedReopenAt || settings.serviceOpenAt) : (settings.maintenanceEndAt || settings.serviceOpenAt))!).toLocaleString()}<br /><strong>{scheduleClockNow < settings.serviceCloseAt ? 'App closes in: ' : scheduleClockNow < (settings.scheduledServiceMode === 'closed' ? (settings.appClosedReopenAt || settings.serviceOpenAt)! : (settings.maintenanceEndAt || settings.serviceOpenAt)!) ? 'App reopens in: ' : 'Schedule status: '}</strong>{scheduleClockNow < settings.serviceCloseAt ? (() => { const n = Math.ceil((settings.serviceCloseAt! - scheduleClockNow) / 1000); return `${Math.floor(n / 86400)}d ${Math.floor((n % 86400) / 3600)}h ${Math.floor((n % 3600) / 60)}m ${n % 60}s`; })() : scheduleClockNow < (settings.scheduledServiceMode === 'closed' ? (settings.appClosedReopenAt || settings.serviceOpenAt)! : (settings.maintenanceEndAt || settings.serviceOpenAt)!) ? (() => { const target = (settings.scheduledServiceMode === 'closed' ? (settings.appClosedReopenAt || settings.serviceOpenAt)! : (settings.maintenanceEndAt || settings.serviceOpenAt)!); const n = Math.ceil((target - scheduleClockNow) / 1000); return `${Math.floor(n / 86400)}d ${Math.floor((n % 86400) / 3600)}h ${Math.floor((n % 3600) / 60)}m ${n % 60}s`; })() : 'Schedule has finished; app is open.'}</p>}
            <div className="mt-5 rounded-xl border border-[#168BFF]/20 bg-[#050A18]/50 p-4 space-y-3">
              <label className="flex items-center gap-2 text-xs font-semibold text-[#8DDCFF]"><input type="checkbox" checked={Boolean(settings.dailyScheduleEnabled)} onChange={e => setSettings({ ...settings, dailyScheduleEnabled: e.target.checked })} /> Daily recurring app close/open</label>
              <div className="grid grid-cols-2 gap-3"><label className="text-[11px] text-[#A8BCD7]">Daily close time<input type="time" value={settings.dailyCloseTime || ''} onChange={e => setSettings({ ...settings, dailyCloseTime: e.target.value })} className="mt-2 w-full rounded-xl border border-[#168BFF]/25 bg-[#050A18] px-3 py-3 text-xs text-[#F1F8FF]" /></label><label className="text-[11px] text-[#A8BCD7]">Daily reopen time<input type="time" value={settings.dailyOpenTime || ''} onChange={e => setSettings({ ...settings, dailyOpenTime: e.target.value })} className="mt-2 w-full rounded-xl border border-[#168BFF]/25 bg-[#050A18] px-3 py-3 text-xs text-[#F1F8FF]" /></label></div>
              <p className="text-[10px] text-[#8199B9]">Repeats every day using each device's local timezone. Daily schedule takes priority over the one-time timer.</p>
            </div>
            <p className="text-[10px] leading-4 text-[#8199B9]">নোট: এটি app-এর global service/maintenance lock screen schedule করে। Firebase/Netlify backend-কে সত্যিকারের বন্ধ করা হয় না; API/data access বন্ধ করতে backend security rules ও server-side controls আলাদা করে লাগবে।</p>
          </div>

          <div className="rounded-2xl border border-[#8DDCFF]/30 bg-[#07152B] p-4 space-y-4">
            <div>
              <h4 className="text-sm font-bold text-[#F1F8FF]">App Update Distribution</h4>
              <p className="text-[11px] text-[#A8BCD7] mt-1">এখানে নতুন APK/ZIP/release page-এর HTTPS link দিলে Profile → ⋮ → Update This App থেকে user download করতে পারবে। ফাইলটি Netlify/GitHub Releases বা আপনার trusted hosting-এ upload করে direct/public link দিন।</p>
            </div>
            <label className="flex items-center justify-between gap-3 text-xs text-[#F1F8FF]">
              <span><strong>Show app update to users</strong><span className="block text-[10px] text-[#A8BCD7] mt-1">বন্ধ করলে Update This App unavailable দেখাবে</span></span>
              <input type="checkbox" checked={Boolean(settings.appUpdateEnabled)} onChange={(e) => setSettings({ ...settings, appUpdateEnabled: e.target.checked })} className="w-4 h-4" />
            </label>
            <div>
              <label className="block text-xs font-semibold text-[#F1F8FF] mb-1.5">Update download URL (HTTPS)</label>
              <input value={settings.appUpdateUrl || ''} onChange={(e) => setSettings({ ...settings, appUpdateUrl: e.target.value.trim() })} placeholder="https://example.com/opencirkle-latest.apk" className="w-full bg-[#050A18] border border-[#168BFF]/25 rounded-xl px-3.5 py-2 text-xs text-[#F1F8FF]" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#F1F8FF] mb-1.5">Required Android version code</label>
              <input type="number" min="1" step="1" value={settings.appUpdateVersionCode ?? ''} onChange={(e) => setSettings({ ...settings, appUpdateVersionCode: e.target.value === '' ? undefined : Number(e.target.value) })} placeholder="e.g. 58" className="w-full bg-[#050A18] border border-[#168BFF]/25 rounded-xl px-3.5 py-2 text-xs text-[#F1F8FF]" />
              <p className="text-[10px] text-[#A8BCD7] mt-1">Installed Android versionCode must be equal to or higher than this number. Set the same number in android/app/build.gradle for the release APK.</p>
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#F1F8FF] mb-1.5">Version label</label>
              <input value={settings.appUpdateVersion || ''} onChange={(e) => setSettings({ ...settings, appUpdateVersion: e.target.value })} placeholder="e.g. v3.2.0" maxLength={40} className="w-full bg-[#050A18] border border-[#168BFF]/25 rounded-xl px-3.5 py-2 text-xs text-[#F1F8FF]" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#F1F8FF] mb-1.5">What's new / update notes</label>
              <textarea rows={3} maxLength={2000} value={settings.appUpdateNotes || ''} onChange={(e) => setSettings({ ...settings, appUpdateNotes: e.target.value })} placeholder="Bug fixes, improvements, new features..." className="w-full resize-y bg-[#050A18] border border-[#168BFF]/25 rounded-xl px-3.5 py-3 text-xs text-[#F1F8FF]" />
            </div>
            <p className="text-[10px] text-amber-200">সতর্কতা: Web app হলে এই link একটি file/release page download/open করবে; browser থেকে website-এর code নিজে নিজে replace হবে না। APK হলে Android install-এর জন্য user-এর confirmation লাগবে।</p>
          </div>

          <div className="rounded-2xl border border-[#168BFF]/25 bg-[#07152B] p-4 space-y-4">
            <div>
              <h4 className="text-sm font-bold text-[#F1F8FF]">Monetag Ads Integration</h4>
              <p className="text-[11px] text-[#A8BCD7] mt-1">Monetag dashboard থেকে পাওয়া আসল Zone/Publisher ID ও HTTPS script URL এখানে দাও। শুধু ID বসালে বিজ্ঞাপন চালু হবে না।</p>
            </div>
            <label className="flex items-center justify-between gap-3 text-xs text-[#F1F8FF]">
              <span><strong>Enable Monetag</strong><span className="block text-[10px] text-[#A8BCD7] mt-1">App-এ ad slot চালু/বন্ধ করবে</span></span>
              <input type="checkbox" checked={Boolean(settings.monetagEnabled)} onChange={(e) => setSettings({ ...settings, monetagEnabled: e.target.checked })} className="w-4 h-4" />
            </label>
            <div>
              <label className="block text-xs font-semibold text-[#F1F8FF] mb-1.5">Monetag Zone / Publisher ID</label>
              <input value={settings.monetagZoneId || ''} onChange={(e) => setSettings({ ...settings, monetagZoneId: e.target.value.trim() })} placeholder="Enter your Monetag zone ID" className="w-full bg-[#050A18] border border-[#168BFF]/25 rounded-xl px-3.5 py-2 text-xs text-[#F1F8FF]" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#F1F8FF] mb-1.5">Monetag HTTPS Script URL (optional)</label>
              <input value={settings.monetagScriptUrl || ''} onChange={(e) => setSettings({ ...settings, monetagScriptUrl: e.target.value.trim() })} placeholder="https://... (optional if full code is pasted below)" className="w-full bg-[#050A18] border border-[#168BFF]/25 rounded-xl px-3.5 py-2 text-xs text-[#F1F8FF]" />
              <p className="text-[10px] text-[#A8BCD7] mt-1">Use this only if Monetag gave you a standalone script URL. The full code box below takes priority.</p>
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#F1F8FF] mb-1.5">Paste complete Monetag Ad Code</label>
              <textarea
                value={settings.monetagAdCode || ''}
                onChange={(e) => setSettings({ ...settings, monetagAdCode: e.target.value })}
                placeholder={'Paste the complete code copied from Monetag here, including any <script> tags...'}
                rows={7}
                spellCheck={false}
                className="w-full resize-y bg-[#050A18] border border-[#168BFF]/25 rounded-xl px-3.5 py-3 text-[11px] leading-relaxed text-[#F1F8FF] font-mono"
              />
              <p className="text-[10px] text-[#A8BCD7] mt-1">Save Parameters চাপার পর code Firebase-এ save হবে এবং Main App-এর feed ad slot-এ run করার চেষ্টা করবে। Monetag থেকে পাওয়া আসল code-টাই paste করবে। শুধু script code দিলে placement ওই feed slot-এ হবে।</p>
            </div>
          </div>

          <button
            type="submit"
            className="px-6 py-2.5 text-xs font-semibold text-white bg-gradient-to-r from-[#0D47A1] to-[#168BFF] rounded-xl shadow-[0_0_15px_rgba(22,139,255,0.4)]"
          >
            Save Parameters
          </button>
        </form>
      )}

      {/* Tab 5: Security Audit Logs */}
      {activeTab === 'audit' && (
        <div className="crystal-card rounded-2xl p-5 border border-[#168BFF]/20 space-y-3">
          <h3 className="text-xs font-bold text-[#8DDCFF] uppercase tracking-wider flex items-center gap-2 mb-3">
            <History className="w-4 h-4" /> Chronological Governance Audit Log
          </h3>

          <div className="divide-y divide-[#168BFF]/10">
            {auditLogs.length === 0 ? (
              <div className="py-6 text-center text-xs text-[#A8BCD7] italic">
                No administrative actions logged yet.
              </div>
            ) : (
              auditLogs.map((log) => (
                <div key={log.id} className="py-3 first:pt-0 last:pb-0 flex items-start justify-between gap-3 text-xs">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-[#8DDCFF] font-semibold">{log.action}</span>
                      <span className="text-[#A8BCD7]">by @{log.adminUsername}</span>
                    </div>
                    <p className="text-[#F1F8FF]/80 mt-0.5">{log.details}</p>
                    <span className="text-[10px] font-mono text-[#A8BCD7]/50 mt-1 block">
                      Target: {log.targetId}
                    </span>
                  </div>

                  <span className="text-[10px] font-mono text-[#A8BCD7] shrink-0">
                    {new Date(log.timestamp).toLocaleString([], {
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
