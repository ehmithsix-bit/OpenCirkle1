import React, { useState, useEffect } from 'react';
import {
  registerUser,
  loginUser,
  resetPassword,
  checkUsernameAvailable,
  registerWithGoogle,
} from '../../services/authService';
import { X, Check, AlertCircle, Lock, Mail, User, KeyRound } from 'lucide-react';
import openCirkleLogo from '../../assets/opencirkle-logo.png';
import googleLogo from '../../assets/google-logo.png';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultMode?: 'login' | 'register';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  defaultMode = 'login',
}) => {
  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>(defaultMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [countryCode, setCountryCode] = useState(() => localStorage.getItem('opencirkle_country') || 'BD');
  const [languageCode, setLanguageCode] = useState(() => localStorage.getItem('opencirkle_language') || 'en');

  const [usernameChecking, setUsernameChecking] = useState(false);
  const [usernameAvailable, setUsernameAvailable] = useState<boolean | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [savedEmails, setSavedEmails] = useState<string[]>([]);

  useEffect(() => {
    setMode(defaultMode);
    setError(null);
    setSuccessMsg(null);
    try {
      const saved = JSON.parse(localStorage.getItem('opencirkle_saved_accounts') || '[]');
      const emails = Array.isArray(saved) ? saved.filter((v): v is string => typeof v === 'string' && v.includes('@')) : [];
      const uniqueEmails = [...new Set(emails)];
      setSavedEmails(uniqueEmails);
      if (defaultMode === 'login' && uniqueEmails.length) {
        const previous = localStorage.getItem('opencirkle_last_account_to_switch')?.toLowerCase() || '';
        const nextEmail = uniqueEmails.find((saved) => saved.toLowerCase() !== previous) || uniqueEmails[0];
        setEmail(nextEmail);
        localStorage.removeItem('opencirkle_last_account_to_switch');
      }
    } catch { setSavedEmails([]); }
  }, [defaultMode, isOpen]);

  const rememberAccount = (rawEmail: string) => {
    const cleanEmail = rawEmail.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@')) return;
    const next = [cleanEmail, ...savedEmails.filter((item) => item.toLowerCase() !== cleanEmail)].slice(0, 10);
    setSavedEmails(next);
    try { localStorage.setItem('opencirkle_saved_accounts', JSON.stringify(next)); } catch { /* storage may be disabled */ }
  };

  // Debounced username availability checker
  useEffect(() => {
    if (mode !== 'register') return;
    const clean = username.trim().toLowerCase().replace(/[^a-z0-9_]/g, '');
    if (!clean || clean.length < 3) {
      setUsernameAvailable(null);
      return;
    }

    let active = true;
    setUsernameChecking(true);
    const timer = setTimeout(async () => {
      try {
        const available = await checkUsernameAvailable(clean);
        if (active) {
          setUsernameAvailable(available);
          setUsernameChecking(false);
        }
      } catch (err) {
        if (active) setUsernameChecking(false);
      }
    }, 400);

    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [username, mode]);

  const countryOptions = [{code:'BD',name:'Bangladesh',lang:'bn',langName:'বাংলা'},{code:'US',name:'United States',lang:'en',langName:'English'},{code:'GB',name:'United Kingdom',lang:'en',langName:'English'},{code:'IN',name:'India',lang:'hi',langName:'हिन्दी'},{code:'PK',name:'Pakistan',lang:'ur',langName:'اردو'},{code:'SA',name:'Saudi Arabia',lang:'ar',langName:'العربية'},{code:'AE',name:'United Arab Emirates',lang:'ar',langName:'العربية'},{code:'ID',name:'Indonesia',lang:'id',langName:'Bahasa Indonesia'},{code:'TR',name:'Türkiye',lang:'tr',langName:'Türkçe'},{code:'FR',name:'France',lang:'fr',langName:'Français'},{code:'ES',name:'Spain',lang:'es',langName:'Español'},{code:'BR',name:'Brazil',lang:'pt',langName:'Português'},{code:'JP',name:'Japan',lang:'ja',langName:'日本語'},{code:'KR',name:'South Korea',lang:'ko',langName:'한국어'},{code:'CN',name:'China',lang:'zh',langName:'中文'}];
  const selectedCountry = countryOptions.find(c => c.code === countryCode) || countryOptions[0];
  const chooseCountry = (code: string) => { const item = countryOptions.find(c => c.code === code) || countryOptions[0]; setCountryCode(code); setLanguageCode(item.lang); try { localStorage.setItem('opencirkle_country', code); localStorage.setItem('opencirkle_language', item.lang); } catch {} };

  const handleGoogleSignup = async () => { setError(null); setSubmitting(true); try { await registerWithGoogle(countryCode, languageCode); try { localStorage.setItem('opencirkle_country', countryCode); localStorage.setItem('opencirkle_language', languageCode); } catch {} onClose(); } catch (err: any) { setError(err?.message || 'Google sign-up failed.'); } finally { setSubmitting(false); } };

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    setSubmitting(true);

    try {
      if (mode === 'login') {
        await loginUser(email.trim(), password);
        rememberAccount(email);
        onClose();
      } else if (mode === 'register') {
        if (usernameAvailable === false) {
          throw new Error('Please select an available unique username.');
        }
        await registerUser(email.trim(), password, username, displayName || username, countryCode, languageCode);
        try { localStorage.setItem('opencirkle_country', countryCode); localStorage.setItem('opencirkle_language', languageCode); } catch {}
        rememberAccount(email);
        onClose();
      } else if (mode === 'forgot') {
        await resetPassword(email.trim());
        setSuccessMsg('Password reset instructions dispatched to your email.');
      }
    } catch (err: any) {
      setError(err?.message || 'Authentication operation failed. Please verify credentials.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-[#050A18]/85 backdrop-blur-md">
      <div className="rounded-t-[32px] sm:rounded-3xl ios-liquid-glass w-full max-w-md p-6 sm:p-8 border border-[#8DDCFF]/30 shadow-[0_16px_50px_rgba(0,0,0,0.85)] relative animate-slide-up sm:animate-in sm:fade-in sm:zoom-in-95 duration-200">
        {/* iOS Grabber Pill for Mobile */}
        <div className="w-10 h-1 bg-[#8DDCFF]/40 rounded-full mx-auto mb-4 sm:hidden" />

        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-[#A8BCD7] hover:text-[#F1F8FF] rounded-full hover:bg-[#071A38] transition-colors ios-press"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Brand Lockup */}
        <div className="text-center mb-6">
          <div className="w-14 h-14 mx-auto mb-3 rounded-full p-[2px] border-2 border-[#8DDCFF] ring-2 ring-[#168BFF]/60 shadow-[0_0_20px_rgba(22,139,255,0.45)]">
            <img src={openCirkleLogo} alt="OpenCirkle logo" loading="eager" fetchPriority="high" decoding="async" className="w-full h-full rounded-full object-contain" />
          </div>
          <h2 className="text-xl font-extrabold text-[#F1F8FF] tracking-tight">
            {mode === 'login' && 'Enter OpenCirkle'}
            {mode === 'register' && 'Engrave New Identity'}
            {mode === 'forgot' && 'Reset Access Key'}
          </h2>
          <p className="text-xs text-[#A8BCD7] mt-1">
            {mode === 'login' && 'Connect to the crystal discourse sanctuary.'}
            {mode === 'register' && 'Pure text social network. No media bloat.'}
            {mode === 'forgot' && 'Provide your registered email to restore access.'}
          </p>
        </div>

        {/* Mode Selector Tabs */}
        {mode !== 'forgot' && (
          <div className="flex items-center gap-1 p-1 bg-[#050A18]/80 border border-[#168BFF]/20 rounded-xl mb-6">
            <button
              type="button"
              onClick={() => setMode('login')}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                mode === 'login'
                  ? 'bg-gradient-to-r from-[#0D47A1] to-[#168BFF] text-white shadow-[0_0_12px_rgba(22,139,255,0.4)]'
                  : 'text-[#A8BCD7] hover:text-[#F1F8FF]'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => setMode('register')}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                mode === 'register'
                  ? 'bg-gradient-to-r from-[#0D47A1] to-[#168BFF] text-white shadow-[0_0_12px_rgba(22,139,255,0.4)]'
                  : 'text-[#A8BCD7] hover:text-[#F1F8FF]'
              }`}
            >
              Register
            </button>
          </div>
        )}

        <div className="grid grid-cols-2 gap-3 mb-4">
          <div><label className="block text-xs font-semibold text-[#F1F8FF] mb-1.5">Country / Region</label><select value={countryCode} onChange={e => chooseCountry(e.target.value)} className="w-full bg-[#050A18] border border-[#168BFF]/25 rounded-xl px-3 py-2.5 text-xs text-[#F1F8FF]">{countryOptions.map(c => <option key={c.code} value={c.code}>{c.name}</option>)}</select></div>
          <div><label className="block text-xs font-semibold text-[#F1F8FF] mb-1.5">App Language</label><select value={languageCode} onChange={e => { setLanguageCode(e.target.value); try { localStorage.setItem('opencirkle_language', e.target.value); } catch {} }} className="w-full bg-[#050A18] border border-[#168BFF]/25 rounded-xl px-3 py-2.5 text-xs text-[#F1F8FF]"><option value="en">English</option><option value="bn">বাংলা</option><option value="hi">हिन्दी</option><option value="ur">اردو</option><option value="ar">العربية</option><option value="id">Bahasa Indonesia</option><option value="tr">Türkçe</option><option value="fr">Français</option><option value="es">Español</option><option value="pt">Português</option><option value="ja">日本語</option><option value="ko">한국어</option><option value="zh">中文</option></select></div>
        </div>
        {(mode === 'register' || mode === 'login') && <button type="button" onClick={handleGoogleSignup} disabled={submitting} className="w-full flex items-center justify-center gap-3 py-3 mb-4 text-xs font-bold text-[#182230] bg-white border border-white/30 rounded-xl hover:bg-slate-50 disabled:opacity-50 transition-colors"><img src={googleLogo} alt="Google" className="w-5 h-5 object-contain" />{submitting ? 'Connecting to Google…' : 'Continue with Google'}</button>}
        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'register' && (
            <>
              {/* Unique Username */}
              <div>
                <label className="block text-xs font-semibold text-[#F1F8FF] mb-1.5">
                  Unique Username
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-[#A8BCD7] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value.toLowerCase())}
                    placeholder="e.g. quantum_node"
                    required
                    minLength={3}
                    maxLength={20}
                    className="w-full bg-[#050A18] border border-[#168BFF]/25 rounded-xl pl-10 pr-10 py-2.5 text-xs text-[#F1F8FF] font-mono focus:outline-none focus:border-[#168BFF]"
                  />
                  <div className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[11px] font-mono">
                    {usernameChecking && <span className="text-[#A8BCD7] animate-pulse">Checking...</span>}
                    {usernameAvailable === true && (
                      <span className="text-[#8DDCFF] flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" /> Available
                      </span>
                    )}
                    {usernameAvailable === false && (
                      <span className="text-[#FF6B6B]">Taken</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Display Name */}
              <div>
                <label className="block text-xs font-semibold text-[#F1F8FF] mb-1.5">
                  Display Name
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-[#A8BCD7] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="e.g. Elena Rostova"
                    maxLength={40}
                    className="w-full bg-[#050A18] border border-[#168BFF]/25 rounded-xl pl-10 pr-4 py-2.5 text-xs text-[#F1F8FF] focus:outline-none focus:border-[#168BFF]"
                  />
                </div>
              </div>
            </>
          )}

          {/* Remembered account chooser: email only; passwords are never stored on this device. */}
          {mode === 'login' && savedEmails.length > 0 && (
            <div>
              <label className="block text-xs font-semibold text-[#F1F8FF] mb-1.5">Switch to a saved account</label>
              <select
                value={savedEmails.some((saved) => saved.toLowerCase() === email.toLowerCase()) ? email : ''}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#050A18] border border-[#168BFF]/25 rounded-xl px-3 py-2.5 text-xs text-[#F1F8FF] focus:outline-none focus:border-[#168BFF]"
              >
                <option value="">Choose an account…</option>
                {savedEmails.map((saved) => <option key={saved} value={saved}>{saved}</option>)}
              </select>
              <button type="button" onClick={() => { setSavedEmails([]); try { localStorage.removeItem('opencirkle_saved_accounts'); } catch {} setEmail(''); setMode('register'); setError(null); }} className="mt-2 text-[10px] text-[#A8BCD7] hover:text-[#8DDCFF] underline">Forget all saved accounts · Create a new account</button>
            </div>
          )}

          {/* Email */}
          <div>
            <label className="block text-xs font-semibold text-[#F1F8FF] mb-1.5">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-[#A8BCD7] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="thinker@domain.com"
                required
                className="w-full bg-[#050A18] border border-[#168BFF]/25 rounded-xl pl-10 pr-4 py-2.5 text-xs text-[#F1F8FF] focus:outline-none focus:border-[#168BFF]"
              />
            </div>
          </div>

          {/* Password (if not forgot) */}
          {mode !== 'forgot' && (
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-semibold text-[#F1F8FF]">Password</label>
                {mode === 'login' && (
                  <button
                    type="button"
                    onClick={() => setMode('forgot')}
                    className="text-[11px] text-[#8DDCFF] hover:underline"
                  >
                    Forgot Password?
                  </button>
                )}
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-[#A8BCD7] absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  required
                  minLength={6}
                  className="w-full bg-[#050A18] border border-[#168BFF]/25 rounded-xl pl-10 pr-4 py-2.5 text-xs text-[#F1F8FF] focus:outline-none focus:border-[#168BFF]"
                />
              </div>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-2 text-xs text-[#FF6B6B] bg-[#FF6B6B]/10 p-2.5 rounded-lg border border-[#FF6B6B]/20">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {successMsg && (
            <div className="flex items-center gap-2 text-xs text-[#8DDCFF] bg-[#168BFF]/10 p-2.5 rounded-lg border border-[#168BFF]/30">
              <Check className="w-4 h-4 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-3 text-xs font-semibold text-white bg-gradient-to-r from-[#0D47A1] via-[#168BFF] to-[#0D47A1] rounded-xl shadow-[0_0_20px_rgba(22,139,255,0.4)] hover:shadow-[0_0_25px_rgba(22,139,255,0.6)] transition-all active:scale-95 disabled:opacity-50"
          >
            {submitting ? (
              'Authenticating...'
            ) : mode === 'login' ? (
              'Sign In to OpenCirkle'
            ) : mode === 'register' ? (
              'Engrave Profile'
            ) : (
              'Send Reset Link'
            )}
          </button>

          {mode === 'forgot' && (
            <button
              type="button"
              onClick={() => setMode('login')}
              className="w-full text-center text-xs text-[#8DDCFF] hover:underline pt-2 block"
            >
              Return to Sign In
            </button>
          )}
        </form>
      </div>
    </div>
  );
};
