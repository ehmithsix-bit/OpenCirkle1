import React, { useEffect, useState } from 'react';
import { collection, getDocs, limit, query } from 'firebase/firestore';
import { X, Send, Search, Loader2 } from 'lucide-react';
import { db } from '../../lib/firebase';
import { useAuth } from '../../context/AuthContext';
import { UserProfile } from '../../types';
import { getOrCreateConversation, sendTextMessage } from '../../services/messageService';
import { CrystalAvatar } from '../common/CrystalAvatar';
import VerifiedBadge from '../common/VerifiedBadge';

interface Props { title: string; shareText: string; shareUrl: string; onClose: () => void; }
export const ShareToUserModal: React.FC<Props> = ({ title, shareText, shareUrl, onClose }) => {
  const { currentUserProfile } = useAuth();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [sendingTo, setSendingTo] = useState<string | null>(null);
  const [sent, setSent] = useState<string[]>([]);
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        const q = query(collection(db, 'users'), limit(25));
        const snap = await getDocs(q);
        const list = snap.docs.map(d => ({ ...d.data(), uid: d.id } as UserProfile))
          .filter(u => u.uid !== currentUserProfile?.uid && (!u.status || u.status === 'active'));
        if (active) setUsers(list);
      } catch (e) { console.warn('Could not load share recipients:', e); if (active) setError('Could not load users. Check your connection and try again.'); }
      finally { if (active) setLoading(false); }
    };
    void load();
    return () => { active = false; };
  }, [currentUserProfile?.uid]);

  const sendTo = async (user: UserProfile) => {
    if (!currentUserProfile || sendingTo || sent.includes(user.uid)) return;
    setSendingTo(user.uid); setError('');
    try {
      const conversation = await getOrCreateConversation(currentUserProfile, user);
      const text = `${title}\n${shareText ? `${shareText.slice(0, 240)}\n` : ''}${shareUrl}`.slice(0, 2000);
      await sendTextMessage(conversation.id, currentUserProfile, user.uid, text);
      setSent(prev => [...prev, user.uid]);
    } catch (e: any) { setError(e?.message || `Could not share with @${user.username}.`); }
    finally { setSendingTo(null); }
  };
  const visible = users.filter(u => `${u.displayName || ''} ${u.username || ''}`.toLowerCase().includes(search.toLowerCase()));

  return <div className="fixed inset-0 z-[10000] flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label={title}>
    <div className="flex max-h-[82dvh] w-full max-w-md flex-col overflow-hidden rounded-2xl border border-[#168BFF]/30 bg-[#071A38] shadow-2xl">
      <div className="flex items-center justify-between border-b border-white/10 p-4"><div><h2 className="font-bold text-white">Share in Messenger</h2><p className="mt-1 text-xs text-[#A8BCD7]">Send this to an OpenCirkle user</p></div><button onClick={onClose} className="rounded-lg p-2 text-[#A8BCD7] hover:bg-white/10" aria-label="Close"><X className="h-5 w-5"/></button></div>
      <div className="p-3"><div className="relative"><Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#A8BCD7]"/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search name or username" className="w-full rounded-xl border border-white/10 bg-[#050A18] py-2.5 pl-9 pr-3 text-sm text-white outline-none focus:border-[#168BFF]"/></div></div>
      {error && <p className="px-4 pb-2 text-xs text-rose-300">{error}</p>}
      <div className="min-h-24 flex-1 overflow-y-auto px-2 pb-3">{loading ? <div className="flex items-center justify-center gap-2 p-8 text-sm text-[#A8BCD7]"><Loader2 className="h-4 w-4 animate-spin"/>Loading users…</div> : visible.length ? visible.map(user => <div key={user.uid} className="flex items-center gap-3 rounded-xl px-2 py-2 hover:bg-white/5"><CrystalAvatar displayName={user.displayName} username={user.username} avatarSymbol={user.avatarSymbol} avatarColor={user.avatarColor} avatarUrl={user.avatarUrl} size="md"/><div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-white">{user.displayName || user.username || 'OpenCirkle user'} {user.verified && <VerifiedBadge size="sm" title="Verified account" />}</p><p className="truncate text-xs text-[#A8BCD7]">@{user.username || 'user'}</p></div><button disabled={sendingTo !== null || sent.includes(user.uid)} onClick={() => void sendTo(user)} className="flex min-w-[78px] items-center justify-center gap-1 rounded-lg bg-[#0D47A1] px-3 py-2 text-xs font-semibold text-white disabled:opacity-60">{sendingTo === user.uid ? <Loader2 className="h-3.5 w-3.5 animate-spin"/> : sent.includes(user.uid) ? 'Sent ✓' : <><Send className="h-3.5 w-3.5"/>Send</>}</button></div>) : <p className="p-6 text-center text-sm text-[#A8BCD7]">No users found.</p>}</div>
    </div>
  </div>;
};
