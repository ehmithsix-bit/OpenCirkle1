import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Conversation, DirectMessage, UserProfile } from '../../types';
import { getLatestUserProfile } from '../../services/latestProfileService';
import {
  subscribeToConversations,
  subscribeToMessages,
  sendTextMessage,
  markConversationRead,
  getOrCreateConversation,
  setTypingStatus,
  subscribeToTyping,
  markMessagesSeen,
} from '../../services/messageService';
import { CrystalAvatar } from '../common/CrystalAvatar';
import VerifiedBadge from '../common/VerifiedBadge';
import { MessageSquare, Send, ArrowLeft, Shield, CheckCheck, AlertCircle } from 'lucide-react';

interface ChatViewProps {
  initialRecipient?: UserProfile | null;
  onUserClick: (username: string) => void;
  onOpenAuth: () => void;
}

export const ChatView: React.FC<ChatViewProps> = ({
  initialRecipient = null,
  onUserClick,
  onOpenAuth,
}) => {
  const { currentUserProfile } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [latestParticipants, setLatestParticipants] = useState<Record<string, Partial<UserProfile>>>({});
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<DirectMessage[]>([]);
  const [messageText, setMessageText] = useState('');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [localVirtualMessages, setLocalVirtualMessages] = useState<Array<{ id: string; senderId: string; text: string; createdAt: number }>>([]);
  const isVirtualRecipient = Boolean((initialRecipient as (UserProfile & { isVirtualProfile?: boolean }) | null)?.isVirtualProfile);
  const virtualChatKey = initialRecipient && currentUserProfile
    ? `opencirkle:virtual-chat:${currentUserProfile.uid}:${initialRecipient.uid}`
    : ''; 
  const [typingUsers, setTypingUsers] = useState<Record<string, { username: string; updatedAt: number }>>({});
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // If unauthenticated
  if (!currentUserProfile) {
    return (
      <div className="crystal-card max-w-md mx-auto rounded-2xl p-8 text-center border border-[#168BFF]/20 space-y-3">
        <MessageSquare className="w-12 h-12 text-[#168BFF] mx-auto" />
        <h3 className="text-base font-bold text-[#F1F8FF]">Crypt Messages</h3>
        <p className="text-xs text-[#A8BCD7]">
          Sign in to exchange private, encrypted text messages across the crystal crypt.
        </p>
        <button
          onClick={onOpenAuth}
          className="px-6 py-2.5 text-xs font-semibold text-white bg-gradient-to-r from-[#0D47A1] to-[#168BFF] rounded-xl shadow-[0_0_15px_rgba(22,139,255,0.4)]"
        >
          Sign In
        </button>
      </div>
    );
  }

  // Subscribe to user conversations
  useEffect(() => {
    if (isVirtualRecipient) return;
    const unsubscribe = subscribeToConversations(currentUserProfile.uid, (list) => {
      setConversations(list);
      // Auto select first or update active
      if (activeConversation) {
        const updated = list.find((c) => c.id === activeConversation.id);
        if (updated) setActiveConversation(updated);
      }
    });

    return () => {
      unsubscribe();
    };
  }, [currentUserProfile.uid, activeConversation?.id, isVirtualRecipient]);

  useEffect(() => {
    let active = true;
    const ids = Array.from(new Set(conversations.flatMap((conv) =>
      conv.participantIds.filter((uid) => uid && uid !== currentUserProfile.uid)
    )));
    if (!ids.length) return;
    Promise.all(ids.map(async (uid) => [uid, await getLatestUserProfile(uid)] as const)).then((entries) => {
      if (!active) return;
      setLatestParticipants((prev) => {
        const next = { ...prev };
        entries.forEach(([uid, profile]) => { if (profile) next[uid] = profile; });
        return next;
      });
    });
    return () => { active = false; };
  }, [conversations, currentUserProfile.uid]);

  // Handle a profile's Message action. Clear the previous thread immediately,
  // then ignore stale async results if the user chooses another recipient.
  useEffect(() => {
    let cancelled = false;

    if (!initialRecipient || !currentUserProfile) return () => { cancelled = true; };

    setError(null);
    setMessages([]);
    setActiveConversation(null);

    if (isVirtualRecipient && virtualChatKey) {
      try {
        setLocalVirtualMessages(JSON.parse(window.localStorage.getItem(virtualChatKey) || '[]'));
      } catch {
        setLocalVirtualMessages([]);
      }
      return () => { cancelled = true; };
    }

    getOrCreateConversation(currentUserProfile, initialRecipient)
      .then((conv) => {
        if (!cancelled) setActiveConversation(conv);
      })
      .catch((err) => {
        if (!cancelled) setError(err?.message || 'Could not open conversation.');
      });

    return () => { cancelled = true; };
  }, [initialRecipient?.uid, currentUserProfile?.uid, isVirtualRecipient, virtualChatKey]);

  // Subscribe to messages in active conversation
  useEffect(() => {
    if (isVirtualRecipient) { setMessages([]); return; }
    if (!activeConversation) {
      setMessages([]);
      return;
    }

    // Mark as read
    markConversationRead(activeConversation.id, currentUserProfile.uid);

    const unsubscribe = subscribeToMessages(activeConversation.id, (msgs) => {
      setMessages(msgs);
      void markMessagesSeen(activeConversation.id, currentUserProfile.uid, msgs).catch(() => {});
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 50);
    });

    const unsubscribeTyping = subscribeToTyping(activeConversation.id, setTypingUsers);
    return () => {
      unsubscribe();
      unsubscribeTyping();
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
      void setTypingStatus(activeConversation.id, currentUserProfile.uid, currentUserProfile.username, false).catch(() => {});
    };
  }, [activeConversation?.id, currentUserProfile.uid, isVirtualRecipient]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim() || sending) return;

    if (isVirtualRecipient && currentUserProfile && initialRecipient && virtualChatKey) {
      const nextMessage = {
        id: `local-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        senderId: currentUserProfile.uid,
        text: messageText.trim(),
        createdAt: Date.now(),
      };
      const next = [...localVirtualMessages, nextMessage];
      setLocalVirtualMessages(next);
      window.localStorage.setItem(virtualChatKey, JSON.stringify(next));
      setMessageText('');
      setError(null);
      return;
    }
    if (!activeConversation) return;

    // Identify recipient
    const otherId = activeConversation.participantIds.find((id) => id !== currentUserProfile.uid);
    if (!otherId) return;

    setSending(true);
    setError(null);

    try {
      await sendTextMessage(activeConversation.id, currentUserProfile, otherId, messageText);
      setMessageText('');
      await setTypingStatus(activeConversation.id, currentUserProfile.uid, currentUserProfile.username, false).catch(() => {});
    } catch (err: any) {
      setError(err?.message || 'Failed to send text message.');
    } finally {
      setSending(false);
    }
  };

  const getOtherParticipant = (conv: Conversation) => {
    const otherId = conv.participantIds.find((id) => id !== currentUserProfile.uid) || '';
    return {
      uid: otherId,
      data: {
        ...(conv.participantData[otherId] || {
          username: 'unknown',
          displayName: 'Crystalline Thinker',
          avatarSymbol: 'gem' as const,
          avatarColor: 'electric' as const,
          avatarUrl: undefined,
        }),
        ...(latestParticipants[otherId] || {}),
      },
    };
  };

  if (isVirtualRecipient && initialRecipient) {
    return (
      <div className="max-w-3xl w-full mx-auto pb-16">
        <div className="rounded-3xl ios-liquid-glass border border-[#8DDCFF]/30 shadow-[0_16px_50px_rgba(0,0,0,0.8)] h-[calc(100vh-140px)] min-h-[480px] flex flex-col overflow-hidden">
          <div className="p-4 border-b border-[#168BFF]/15 flex items-center gap-3 bg-[#071A38]/40">
            <button onClick={() => onUserClick(initialRecipient.username)} className="shrink-0">
              <CrystalAvatar displayName={initialRecipient.displayName} username={initialRecipient.username} avatarSymbol={initialRecipient.avatarSymbol} avatarUrl={initialRecipient.avatarUrl} avatarColor={initialRecipient.avatarColor} size="sm" />
            </button>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold text-[#F1F8FF] truncate">{initialRecipient.displayName}</p>
              <p className="text-[11px] font-mono text-[#A8BCD7]">@{initialRecipient.username}</p>
            </div>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {localVirtualMessages.length === 0 ? (
              <div className="py-16 text-center text-xs text-[#A8BCD7]"><p>No messages yet</p><p className="text-[11px] mt-1">Say hello to start the conversation.</p></div>
            ) : localVirtualMessages.map((m) => (
              <div key={m.id} className="flex flex-col items-end">
                <div className="max-w-[85%] rounded-2xl rounded-br-sm px-4 py-2.5 bg-gradient-to-r from-[#0D47A1] to-[#168BFF] text-white text-sm whitespace-pre-wrap break-words">{m.text}</div>
                <span className="text-[10px] text-[#A8BCD7] mt-1">{new Date(m.createdAt).toLocaleTimeString('en-BD', { hour: '2-digit', minute: '2-digit' })}</span>
              </div>
            ))}
          </div>
          {error && <p className="px-4 text-xs text-red-300">{error}</p>}
          <form onSubmit={handleSendMessage} className="p-3 border-t border-[#168BFF]/15 flex items-center gap-2">
            <input value={messageText} onChange={(e) => setMessageText(e.target.value)} placeholder="Write a message…" className="flex-1 min-w-0 rounded-xl bg-[#071A38] border border-[#168BFF]/25 px-4 py-3 text-sm text-[#F1F8FF] outline-none focus:border-[#8DDCFF]" maxLength={2000} />
            <button type="submit" disabled={!messageText.trim()} className="rounded-xl p-3 bg-gradient-to-r from-[#0D47A1] to-[#168BFF] text-white disabled:opacity-40" aria-label="Send message"><Send className="w-4 h-4" /></button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl w-full mx-auto pb-16">
      <div className="rounded-3xl ios-liquid-glass border border-[#8DDCFF]/30 shadow-[0_16px_50px_rgba(0,0,0,0.8)] h-[calc(100vh-140px)] min-h-[550px] flex overflow-hidden">
        {/* Left: Conversation list */}
        <div
          className={`w-full md:w-80 border-r border-[#168BFF]/15 flex flex-col ${
            activeConversation ? 'hidden md:flex' : 'flex'
          }`}
        >
          <div className="p-4 border-b border-[#168BFF]/15 flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#F1F8FF] flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-[#8DDCFF]" />
              <span>Crypt Transmissions</span>
            </h3>
            <span className="text-[10px] font-mono text-[#A8BCD7] uppercase">
              Text Only
            </span>
          </div>

          <div className="overflow-y-auto flex-1 divide-y divide-[#168BFF]/10">
            {conversations.length === 0 ? (
              <div className="p-8 text-center text-xs text-[#A8BCD7] italic">
                No active transmissions. Visit a thinker's profile to start a conversation.
              </div>
            ) : (
              conversations.map((conv) => {
                const { uid: otherId, data: otherData } = getOtherParticipant(conv);
                const unread = conv.unreadCount?.[currentUserProfile.uid] || 0;
                const isSelected = activeConversation?.id === conv.id;

                return (
                  <button
                    key={conv.id}
                    onClick={() => setActiveConversation(conv)}
                    className={`w-full p-4 flex items-center gap-3 text-left transition-all ${
                      isSelected
                        ? 'bg-[#168BFF]/15 border-l-2 border-[#168BFF]'
                        : 'hover:bg-[#071A38]/50'
                    }`}
                  >
                    <CrystalAvatar
                      displayName={otherData.displayName}
                      username={otherData.username}
                      avatarSymbol={otherData.avatarSymbol}
                        avatarUrl={otherData.avatarUrl}
                      avatarColor={otherData.avatarColor}
                      size="md"
                    />

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-0.5">
                        <span className="text-xs font-semibold text-[#F1F8FF] truncate">
                          {otherData.displayName}
                          {otherData.verified && <VerifiedBadge size="sm" title="Verified account" />}
                        </span>
                        {conv.lastMessageTimestamp && (
                          <span className="text-[10px] font-mono text-[#A8BCD7]">
                            {new Date(conv.lastMessageTimestamp).toLocaleTimeString('en-BD', { timeZone: 'Asia/Dhaka',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center justify-between">
                        <p className="text-xs text-[#A8BCD7] truncate">
                          {conv.lastMessageText || 'No transmissions yet'}
                        </p>
                        {unread > 0 && (
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#168BFF] text-white shrink-0 ml-2">
                            {unread}
                          </span>
                        )}
                      </div>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Right: Active Chat Conversation */}
        <div
          className={`flex-1 flex flex-col bg-[#050A18]/40 ${
            !activeConversation ? 'hidden md:flex items-center justify-center' : 'flex'
          }`}
        >
          {activeConversation ? (
            <>
              {/* Chat Header */}
              {(() => {
                const { data: otherData } = getOtherParticipant(activeConversation);
                return (
                  <div className="p-4 border-b border-[#168BFF]/15 flex items-center justify-between bg-[#071A38]/40">
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => setActiveConversation(null)}
                        className="md:hidden p-1.5 text-[#A8BCD7] hover:text-[#F1F8FF] rounded-lg"
                      >
                        <ArrowLeft className="w-5 h-5" />
                      </button>

                      <CrystalAvatar
                        displayName={otherData.displayName}
                        username={otherData.username}
                        avatarSymbol={otherData.avatarSymbol}
                        avatarUrl={otherData.avatarUrl}
                        avatarColor={otherData.avatarColor}
                        size="sm"
                      />

                      <div>
                        <button
                          onClick={() => onUserClick(otherData.username)}
                          className="text-xs font-bold text-[#F1F8FF] hover:text-[#8DDCFF] transition-colors truncate block"
                        >
                          {otherData.displayName}
                          {otherData.verified && <VerifiedBadge size="sm" title="Verified account" />}
                        </button>
                        <span className="text-[10px] font-mono text-[#A8BCD7]">
                          @{otherData.username}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 text-[11px] text-[#8DDCFF] font-mono">
                      <Shield className="w-3.5 h-3.5 text-[#168BFF]" />
                      <span>Crypt Node</span>
                    </div>
                  </div>
                );
              })()}

              {/* Messages Thread */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {(() => {
                  const otherId = activeConversation.participantIds.find((id) => id !== currentUserProfile.uid);
                  const typingUser = otherId ? typingUsers[otherId] : undefined;
                  return typingUser ? (
                    <div className="text-[11px] text-[#8DDCFF] italic px-2 animate-pulse">{typingUser.username} is typing...</div>
                  ) : null;
                })()}
                {messages.length === 0 ? (
                  <div className="py-16 text-center text-xs text-[#A8BCD7] italic space-y-1">
                    <p>Channel connected.</p>
                    <p className="text-[11px] text-[#A8BCD7]/60">Send the first text reflection.</p>
                  </div>
                ) : (
                  messages.map((m) => {
                    const isSelf = m.senderId === currentUserProfile.uid;
                    return (
                      <div
                        key={m.id}
                        className={`flex flex-col ${isSelf ? 'items-end' : 'items-start'}`}
                      >
                        <div
                          className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-xs break-words whitespace-pre-wrap leading-relaxed shadow-sm ${
                            isSelf
                              ? 'bg-gradient-to-r from-[#0D47A1] to-[#168BFF] text-white rounded-br-none shadow-[0_0_15px_rgba(22,139,255,0.25)]'
                              : 'bg-[#071A38] text-[#F1F8FF] border border-[#168BFF]/20 rounded-bl-none'
                          }`}
                        >
                          {m.text}
                        </div>
                        <div className="flex items-center gap-1 text-[10px] font-mono text-[#A8BCD7]/60 mt-1 px-1">
                          <span>
                            {new Date(m.createdAt).toLocaleTimeString('en-BD', { timeZone: 'Asia/Dhaka',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                          {isSelf && <CheckCheck className={`w-3 h-3 ${(m.readBy || []).some((uid) => uid !== currentUserProfile.uid) ? 'text-[#42F58D]' : 'text-[#8DDCFF]'}`} />}
                          {isSelf && (m.readBy || []).some((uid) => uid !== currentUserProfile.uid) && (
                            <span className="text-[#42F58D] ml-1">Seen by {getOtherParticipant(activeConversation).data.username}</span>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Text-Only Message Composer */}
              <form onSubmit={handleSendMessage} className="p-4 border-t border-[#168BFF]/15 bg-[#071A38]/40">
                {error && (
                  <div className="mb-2 text-[11px] text-[#FF6B6B] flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{error}</span>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={messageText}
                    onChange={(e) => {
                      const value = e.target.value;
                      setMessageText(value);
                      if (activeConversation) {
                        void setTypingStatus(activeConversation.id, currentUserProfile.uid, currentUserProfile.username, Boolean(value.trim())).catch(() => {});
                        if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
                        if (value.trim()) typingTimeoutRef.current = setTimeout(() => {
                          void setTypingStatus(activeConversation.id, currentUserProfile.uid, currentUserProfile.username, false).catch(() => {});
                        }, 2500);
                      }
                    }}
                    placeholder="Enter message text (strictly text-only)..."
                    maxLength={2000}
                    className="flex-1 bg-[#050A18]/90 border border-[#8DDCFF]/30 rounded-full px-5 py-2.5 text-xs text-[#F1F8FF] placeholder-[#A8BCD7]/50 focus:outline-none focus:border-[#168BFF] focus:ring-1 focus:ring-[#168BFF] transition-all"
                  />
                  <button
                    type="submit"
                    disabled={!messageText.trim() || sending}
                    className="p-2.5 rounded-full text-white bg-gradient-to-r from-[#0D47A1] to-[#168BFF] hover:shadow-[0_0_15px_rgba(22,139,255,0.5)] disabled:opacity-40 transition-all shrink-0 ios-press"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              </form>
            </>
          ) : (
            <div className="text-center p-8 space-y-2">
              <MessageSquare className="w-10 h-10 text-[#168BFF]/40 mx-auto" />
              <p className="text-sm font-semibold text-[#F1F8FF]">Select a Transmission Node</p>
              <p className="text-xs text-[#A8BCD7]">
                Choose an existing dialogue from the left or initiate contact via a profile.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
