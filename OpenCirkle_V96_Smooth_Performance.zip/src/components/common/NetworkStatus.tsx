import React, { useEffect, useState } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../../lib/firebase';

/** Small, non-blocking connection indicator. It does not interfere with Firebase data. */
export const NetworkStatus: React.FC = () => {
  const [online, setOnline] = useState(() => typeof navigator === 'undefined' ? true : navigator.onLine);
  const [recovered, setRecovered] = useState(false);
  const [indicatorEnabled, setIndicatorEnabled] = useState(true);

  useEffect(() => onSnapshot(doc(db, 'platformSettings', 'global'), snap => {
    setIndicatorEnabled(snap.exists() ? snap.data().offlineSyncIndicatorEnabled !== false : true);
  }, error => console.warn('Could not load offline status indicator setting:', error)), []);

  useEffect(() => {
    const handleOffline = () => { setOnline(false); setRecovered(false); };
    const handleOnline = () => {
      setOnline(true);
      setRecovered(true);
      const timer = window.setTimeout(() => setRecovered(false), 2600);
      // The timeout is intentionally short-lived and cleared on unmount.
      cleanupTimer = () => window.clearTimeout(timer);
    };
    let cleanupTimer = () => {};
    window.addEventListener('offline', handleOffline);
    window.addEventListener('online', handleOnline);
    return () => {
      cleanupTimer();
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('online', handleOnline);
    };
  }, []);

  if (!indicatorEnabled || (online && !recovered)) return null;
  return (
    <div role="status" aria-live="polite" className={`fixed left-1/2 top-2 z-[120] -translate-x-1/2 rounded-full border px-4 py-2 text-xs font-semibold shadow-xl backdrop-blur-xl ${online ? 'border-emerald-300/30 bg-emerald-950/90 text-emerald-100' : 'border-amber-300/30 bg-[#291b04]/95 text-amber-100'}`}>
      {online ? 'Connection restored' : 'You are offline · Some actions may not sync'}
    </div>
  );
};
