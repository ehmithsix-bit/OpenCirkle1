import React, { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';

interface BottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenAuth: () => void;
  onReturn: () => void;
  onOpenCompose: () => void;
  unreadMessagesCount?: number;
}

type NavPage = 'feed' | 'explore' | 'messages' | 'profile';

/**
 * KMF Crystal Navigation
 * Replaces the previous bottom navigation with the supplied rotating-border dock.
 * Existing application tab routing and authentication behavior are preserved.
 */
export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  setActiveTab,
  onOpenAuth,
  onReturn,
  onOpenCompose,
  unreadMessagesCount = 0,
}) => {
  const { currentUserProfile } = useAuth();
  const [opening, setOpening] = useState(true);
  const [animating, setAnimating] = useState<NavPage | null>(null);
  const [profileScrolled, setProfileScrolled] = useState(false);

  const immersive = activeTab === 'profile' || activeTab === 'messages';
  useEffect(() => {
    if (activeTab !== 'profile') { setProfileScrolled(false); return; }
    const updateScroll = () => setProfileScrolled(window.scrollY > 6);
    updateScroll();
    window.addEventListener('scroll', updateScroll, { passive: true });
    return () => window.removeEventListener('scroll', updateScroll);
  }, [activeTab]);
  const showReturn = activeTab === 'messages' || (activeTab === 'profile' && !profileScrolled);
  const count = Math.max(0, Number(unreadMessagesCount) || 0);

  useEffect(() => {
    const timeoutId = window.setTimeout(() => setOpening(false), 1100);
    return () => window.clearTimeout(timeoutId);
  }, []);

  const navigate = (page: NavPage) => {
    if ((page === 'messages' || page === 'profile') && !currentUserProfile) {
      onOpenAuth();
      return;
    }

    setAnimating(null);
    window.requestAnimationFrame(() => setAnimating(page));
    setActiveTab(page);
  };

  const finishAnimation = (page: NavPage) => {
    setAnimating((current) => current === page ? null : current);
  };

  return (
    <>
      <style>{`
        @property --oc-kmf-crystal-angle {
          syntax: "<angle>";
          initial-value: 0deg;
          inherits: false;
        }

        .oc-kmf-bottom-nav {
          position: fixed;
          left: 0;
          right: 0;
          bottom: 0;
          z-index: 1000;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 12px 14px calc(env(safe-area-inset-bottom, 8px) + 12px);
          pointer-events: none;
          overflow: visible;
        }

        .oc-kmf-dock {
          position: relative;
          isolation: isolate;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 5px;
          width: 100%;
          max-width: 390px;
          padding: 7px;
          background: rgba(8,25,43,.88);
          -webkit-backdrop-filter: blur(24px) saturate(180%);
          backdrop-filter: blur(24px) saturate(180%);
          border: 1px solid rgba(0,229,255,.24);
          border-radius: 999px;
          box-shadow:
            0 12px 40px rgba(0,0,0,.55),
            0 0 25px rgba(0,229,255,.07),
            inset 0 1px 0 rgba(255,255,255,.08);
          pointer-events: auto;
        }

        .oc-kmf-dock::before {
          content: "";
          position: absolute;
          inset: -1px;
          border-radius: inherit;
          padding: 1.5px;
          background: conic-gradient(
            from var(--oc-kmf-crystal-angle),
            transparent 0deg,
            transparent 55deg,
            rgba(0,229,255,.95) 95deg,
            rgba(255,255,255,.95) 115deg,
            rgba(22,139,255,.9) 140deg,
            transparent 180deg,
            transparent 245deg,
            rgba(168,248,255,.85) 290deg,
            transparent 330deg,
            transparent 360deg
          );
          -webkit-mask:
            linear-gradient(#fff 0 0) content-box,
            linear-gradient(#fff 0 0);
          -webkit-mask-composite: xor;
          mask-composite: exclude;
          pointer-events: none;
          z-index: -1;
          animation: ocKmfCrystalRotate 3.2s linear infinite;
        }

        @keyframes ocKmfCrystalRotate {
          to { --oc-kmf-crystal-angle: 360deg; }
        }

        .oc-kmf-nav-btn {
          position: relative;
          isolation: isolate;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-direction: column;
          gap: 3px;
          flex: 1;
          min-width: 0;
          height: 49px;
          border: 0;
          border-radius: 999px;
          background: transparent;
          color: #8298AC;
          cursor: pointer;
          transition:
            color .22s ease,
            background .22s ease,
            transform .22s cubic-bezier(.2,.8,.2,1);
          -webkit-tap-highlight-color: transparent;
          touch-action: manipulation;
        }

        .oc-kmf-nav-btn svg {
          width: 22px;
          height: 22px;
          fill: none;
          stroke: currentColor;
          stroke-width: 1.9;
          stroke-linecap: round;
          stroke-linejoin: round;
          transform-origin: center;
          will-change: transform;
        }

        .oc-kmf-nav-label {
          font-size: 9px;
          font-weight: 650;
          letter-spacing: .35px;
          line-height: 1;
          opacity: .85;
        }

        @media (hover: hover) {
          .oc-kmf-nav-btn:hover {
            color: #A8F8FF;
            background: rgba(0,229,255,.07);
          }
          .oc-kmf-nav-btn:hover svg { transform: translateY(-2px); }
        }

        .oc-kmf-nav-btn:active { transform: scale(.88); }

        .oc-kmf-nav-btn.active {
          color: #03131D;
          background: linear-gradient(135deg,#A8F8FF,#00E5FF,#168BFF);
          box-shadow:
            0 4px 20px rgba(0,229,255,.35),
            0 0 30px rgba(0,180,255,.16),
            inset 0 1px 0 rgba(255,255,255,.65);
          transform: scale(1.04);
        }

        .oc-kmf-nav-btn.active .oc-kmf-nav-label { opacity: 1; }
        .oc-kmf-nav-btn.active svg { filter: drop-shadow(0 1px 2px rgba(0,0,0,.15)); }

        @keyframes ocKmfHomeBounce {
          0%,100% { transform: translateY(0) scale(1); }
          35% { transform: translateY(-6px) scale(1.16); }
          65% { transform: translateY(1px) scale(.95); }
        }

        @keyframes ocKmfExploreSpin {
          0% { transform: rotate(0) scale(1); }
          45% { transform: rotate(180deg) scale(.8); }
          100% { transform: rotate(360deg) scale(1); }
        }

        @keyframes ocKmfMessagePop {
          0% { transform: scale(1) rotate(0); }
          35% { transform: scale(1.25) rotate(-9deg); }
          65% { transform: scale(.9) rotate(6deg); }
          100% { transform: scale(1) rotate(0); }
        }

        @keyframes ocKmfProfilePop {
          0% { transform: scale(1); }
          35% { transform: scale(1.22) rotate(-9deg); }
          65% { transform: scale(.9) rotate(7deg); }
          100% { transform: scale(1); }
        }

        .oc-kmf-nav-btn.anim-feed svg { animation: ocKmfHomeBounce .55s ease; }
        .oc-kmf-nav-btn.anim-explore svg { animation: ocKmfExploreSpin .65s ease; }
        .oc-kmf-nav-btn.anim-messages svg { animation: ocKmfMessagePop .55s cubic-bezier(.34,1.56,.64,1); }
        .oc-kmf-nav-btn.anim-profile svg { animation: ocKmfProfilePop .55s cubic-bezier(.34,1.56,.64,1); }

        @keyframes ocKmfLabelReveal {
          0% { opacity: .25; transform: translateY(5px); letter-spacing: .1px; }
          65% { opacity: 1; transform: translateY(-1px); letter-spacing: .5px; }
          100% { opacity: 1; transform: translateY(0); letter-spacing: .35px; }
        }
        .oc-kmf-nav-btn.anim-feed .oc-kmf-nav-label,
        .oc-kmf-nav-btn.anim-explore .oc-kmf-nav-label,
        .oc-kmf-nav-btn.anim-messages .oc-kmf-nav-label,
        .oc-kmf-nav-btn.anim-profile .oc-kmf-nav-label {
          animation: ocKmfLabelReveal .45s ease both;
        }

        .oc-kmf-nav-btn.oc-kmf-post-btn {
          flex: 0 0 58px;
          width: 58px;
          height: 58px;
          margin: -19px 3px 0;
          border: 1px solid rgba(168,248,255,.75);
          border-radius: 50%;
          color: #03131D;
          background: linear-gradient(145deg, #E8FFFF, #00E5FF 58%, #168BFF);
          box-shadow: 0 7px 22px rgba(0,229,255,.38), 0 0 0 5px rgba(0,229,255,.08), inset 0 1px 0 rgba(255,255,255,.8);
          gap: 1px;
          z-index: 5;
          flex-shrink: 0;
          position: relative;
          transform: translateY(-1px);
        }
        .oc-kmf-nav-btn.oc-kmf-post-btn svg { width: 23px; height: 23px; stroke-width: 2.4; }
        .oc-kmf-nav-btn.oc-kmf-post-btn .oc-kmf-nav-label { color: #03131D; font-size: 8px; font-weight: 800; opacity: 1; }
        .oc-kmf-nav-btn.oc-kmf-post-btn:hover { color: #03131D; background: linear-gradient(145deg, #F4FFFF, #42EEFF 58%, #399EFF); transform: translateY(-2px) scale(1.04); }
        @media (max-width: 380px) {
          .oc-kmf-nav-btn.oc-kmf-post-btn { flex-basis: 54px; width: 54px; height: 54px; margin-top: -17px; }
        }

        .oc-kmf-message-badge {
          position: absolute;
          top: 2px;
          right: 13px;
          min-width: 15px;
          height: 15px;
          padding: 0 4px;
          display: flex;
          align-items: center;
          justify-content: center;
          border: 2px solid #0B1B2B;
          border-radius: 20px;
          background: linear-gradient(135deg,#E9FFFF,#00E5FF);
          color: #03131D;
          font-size: 8px;
          font-weight: 900;
          box-shadow: 0 0 12px rgba(0,229,255,.5);
          animation: ocKmfBadgePulse 2s ease-in-out infinite;
        }

        @keyframes ocKmfBadgePulse {
          0%,100% { transform: scale(1); }
          50% { transform: scale(1.14); }
        }

        .oc-kmf-return {
          display: none;
          position: fixed;
          top: calc(env(safe-area-inset-top, 0px) + 12px);
          left: max(12px, calc((100vw - 960px) / 2 - 48px));
          z-index: 2000;
          width: 43px;
          height: 43px;
          align-items: center;
          justify-content: center;
          border: 1px solid rgba(0,229,255,.24);
          border-radius: 15px;
          background: rgba(8,25,43,.9);
          color: #00E5FF;
          -webkit-backdrop-filter: blur(18px);
          backdrop-filter: blur(18px);
          box-shadow: 0 5px 20px rgba(0,0,0,.3), 0 0 14px rgba(0,229,255,.12);
          cursor: pointer;
          touch-action: manipulation;
        }

        .oc-kmf-return svg { width: 21px; height: 21px; }
        .oc-kmf-return:active { transform: scale(.88); }
        .oc-kmf-return.visible { display: flex; animation: ocKmfReturnEnter .3s ease both; }

        @keyframes ocKmfReturnEnter {
          from { opacity: 0; transform: translateX(-12px) scale(.9); }
          to { opacity: 1; transform: translateX(0) scale(1); }
        }

        .oc-kmf-bottom-nav.opening .oc-kmf-dock {
          animation: ocKmfDockOpen .48s cubic-bezier(.2,.8,.2,1) both;
          overflow: visible;
        }

        /* Keep the raised centre Post action outside the dock's reveal mask. */
        @keyframes ocKmfDockOpen {
          from { opacity: 0; transform: translateY(12px) scale(.96); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }

        @keyframes ocKmfFromLeft {
          from { transform: translateX(-120%) scale(.7); opacity: 0; }
          to { transform: translateX(0) scale(1); opacity: 1; }
        }

        @keyframes ocKmfFromRight {
          from { transform: translateX(120%) scale(.7); opacity: 0; }
          to { transform: translateX(0) scale(1); opacity: 1; }
        }

        .oc-kmf-bottom-nav.opening .oc-kmf-nav-btn:nth-child(1) { animation: ocKmfFromLeft .5s ease .08s both; }
        .oc-kmf-bottom-nav.opening .oc-kmf-nav-btn:nth-child(2) { animation: ocKmfFromLeft .5s ease .16s both; }
        .oc-kmf-bottom-nav.opening .oc-kmf-nav-btn:nth-child(3) { animation: none; }
        .oc-kmf-bottom-nav.opening .oc-kmf-nav-btn:nth-child(4) { animation: ocKmfFromRight .5s ease .16s both; }
        .oc-kmf-bottom-nav.opening .oc-kmf-nav-btn:nth-child(5) { animation: ocKmfFromRight .5s ease .08s both; }

        @media (min-width: 768px) {
          .oc-kmf-bottom-nav { display: none; }
        }

        @media (max-width: 380px) {
          .oc-kmf-bottom-nav { padding-left: 9px; padding-right: 9px; }
          .oc-kmf-dock { gap: 3px; padding: 6px; }
          .oc-kmf-nav-btn { height: 46px; }
          .oc-kmf-nav-btn svg { width: 21px; height: 21px; }
          .oc-kmf-nav-label { font-size: 8px; }
          .oc-kmf-nav-btn.oc-kmf-post-btn {
          flex: 0 0 58px;
          width: 58px;
          height: 58px;
          margin: -19px 3px 0;
          border: 1px solid rgba(168,248,255,.75);
          border-radius: 50%;
          color: #03131D;
          background: linear-gradient(145deg, #E8FFFF, #00E5FF 58%, #168BFF);
          box-shadow: 0 7px 22px rgba(0,229,255,.38), 0 0 0 5px rgba(0,229,255,.08), inset 0 1px 0 rgba(255,255,255,.8);
          gap: 1px;
          z-index: 5;
          flex-shrink: 0;
          position: relative;
          transform: translateY(-1px);
        }
        .oc-kmf-nav-btn.oc-kmf-post-btn svg { width: 23px; height: 23px; stroke-width: 2.4; }
        .oc-kmf-nav-btn.oc-kmf-post-btn .oc-kmf-nav-label { color: #03131D; font-size: 8px; font-weight: 800; opacity: 1; }
        .oc-kmf-nav-btn.oc-kmf-post-btn:hover { color: #03131D; background: linear-gradient(145deg, #F4FFFF, #42EEFF 58%, #399EFF); transform: translateY(-2px) scale(1.04); }
        @media (max-width: 380px) {
          .oc-kmf-nav-btn.oc-kmf-post-btn { flex-basis: 54px; width: 54px; height: 54px; margin-top: -17px; }
        }

        .oc-kmf-message-badge { right: 8px; }
        }

        /* Preserve the requested navigation entrance and tap animations even when
           Android's global Reduce animations setting is enabled. */
      `}</style>

      <button
        type="button"
        className={`oc-kmf-return${showReturn ? ' visible' : ''}`}
        onClick={onReturn}
        aria-label="Return to home"
      >
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.3" strokeLinecap="round" strokeLinejoin="round">
          <path d="M19 12H5M12 19l-7-7 7-7" />
        </svg>
      </button>

      {!immersive && (
        <nav
          data-oc-app-navigation="true"
          aria-label="Mobile Navigation"
          className={`oc-kmf-bottom-nav${opening ? ' opening' : ''}`}
        >
          <div className="oc-kmf-dock">
            <button
              type="button"
              className={`oc-kmf-nav-btn${activeTab === 'feed' ? ' active' : ''}${animating === 'feed' ? ' anim-feed' : ''}`}
              onClick={() => navigate('feed')}
              onAnimationEnd={() => finishAnimation('feed')}
              aria-label="Home"
              aria-current={activeTab === 'feed' ? 'page' : undefined}
            >
              <svg viewBox="0 0 24 24"><path d="M3 10.5L12 3l9 7.5" /><path d="M5 9.5V21h14V9.5" /><path d="M9 21v-7h6v7" /></svg>
              <span className="oc-kmf-nav-label">Home</span>
            </button>

            <button
              type="button"
              className={`oc-kmf-nav-btn${activeTab === 'explore' ? ' active' : ''}${animating === 'explore' ? ' anim-explore' : ''}`}
              onClick={() => navigate('explore')}
              onAnimationEnd={() => finishAnimation('explore')}
              aria-label="Explore"
              aria-current={activeTab === 'explore' ? 'page' : undefined}
            >
              <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" /><path d="M15.5 8.5l-2.2 4.8-4.8 2.2 2.2-4.8z" /></svg>
              <span className="oc-kmf-nav-label">Explore</span>
            </button>

            <button
              type="button"
              className="oc-kmf-nav-btn oc-kmf-post-btn"
              onClick={() => {
                if (!currentUserProfile) onOpenAuth();
                else onOpenCompose();
              }}
              aria-label="Create Post"
            >
              <svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" /></svg>
              <span className="oc-kmf-nav-label">Post</span>
            </button>

            <button
              type="button"
              className={`oc-kmf-nav-btn${activeTab === 'messages' ? ' active' : ''}${animating === 'messages' ? ' anim-messages' : ''}`}
              onClick={() => navigate('messages')}
              onAnimationEnd={() => finishAnimation('messages')}
              aria-label="Messages"
              aria-current={activeTab === 'messages' ? 'page' : undefined}
            >
              <svg viewBox="0 0 24 24">
                <path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5 8.5 8.5 0 0 1-4-.99L3 21l1.99-5.5A8.5 8.5 0 1 1 21 11.5Z" />
                <path d="M8 12h.01M12 12h.01M16 12h.01" strokeWidth="2.5" />
              </svg>
              <span className="oc-kmf-nav-label">Message</span>
              {count > 0 && <span className="oc-kmf-message-badge">{count > 99 ? '99+' : count}</span>}
            </button>

            <button
              type="button"
              className={`oc-kmf-nav-btn${activeTab === 'profile' ? ' active' : ''}${animating === 'profile' ? ' anim-profile' : ''}`}
              onClick={() => navigate('profile')}
              onAnimationEnd={() => finishAnimation('profile')}
              aria-label="Profile"
              aria-current={activeTab === 'profile' ? 'page' : undefined}
            >
              <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4" /><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7" /></svg>
              <span className="oc-kmf-nav-label">Profile</span>
            </button>
          </div>
        </nav>
      )}
    </>
  );
};
