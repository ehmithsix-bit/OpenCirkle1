import React, { useEffect, useState } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../../lib/firebase';

type MonetagConfig = { enabled: boolean; zoneId: string; scriptUrl: string; adCode: string };

/**
 * Live admin-controlled Monetag slot. The complete code is intentionally executed only
 * inside this dedicated ad slot; only trusted admins should be allowed to edit it.
 */
export const MonetagAdSlot: React.FC = () => {
  const [config, setConfig] = useState<MonetagConfig>({ enabled: false, zoneId: '', scriptUrl: '', adCode: '' });
  const [settingsLoaded, setSettingsLoaded] = useState(false);
  const [loadError, setLoadError] = useState(false);

  useEffect(() => {
    return onSnapshot(doc(db, 'platformSettings', 'global'), (snap) => {
      const data = snap.exists() ? snap.data() : {};
      setConfig({
        enabled: data.monetagEnabled === true,
        zoneId: String(data.monetagZoneId || '').trim(),
        scriptUrl: String(data.monetagScriptUrl || '').trim(),
        adCode: String(data.monetagAdCode || ''),
      });
      setSettingsLoaded(true);
    }, (err) => {
      console.warn('Monetag settings unavailable', err);
      setSettingsLoaded(true);
    });
  }, []);

  useEffect(() => {
    if (!config.enabled) return;
    const hasCode = config.adCode.trim().length > 0;
    if (!hasCode && (!config.zoneId || !config.scriptUrl)) return;

    const slot = document.getElementById('monetag-feed-ad-slot');
    if (!slot) return;
    let cancelled = false;
    slot.replaceChildren();
    setLoadError(false);

    const appendExecutableScript = (original: HTMLScriptElement, target: HTMLElement) => {
      const script = document.createElement('script');
      for (const attr of Array.from(original.attributes)) {
        // Only permit HTTPS external scripts; preserve Monetag data attributes/config attributes.
        if (attr.name.toLowerCase() === 'src') {
          try {
            const url = new URL(attr.value, window.location.href);
            if (url.protocol !== 'https:') { setLoadError(true); continue; }
            script.src = url.href;
          } catch { setLoadError(true); continue; }
        } else {
          script.setAttribute(attr.name, attr.value);
        }
      }
      script.async = original.async;
      script.defer = original.defer;
      if (original.textContent) script.textContent = original.textContent;
      script.onload = () => { if (!cancelled) setLoadError(false); };
      script.onerror = () => { if (!cancelled) setLoadError(true); };
      target.appendChild(script);
    };

    try {
      if (hasCode) {
        const parsed = new DOMParser().parseFromString(config.adCode, 'text/html');
        // Copy markup to the ad slot and recreate scripts so the browser executes them.
        const appendNodes = (nodes: NodeListOf<ChildNode> | ChildNode[], target: HTMLElement) => {
          Array.from(nodes).forEach((node) => {
            if (node.nodeType === Node.TEXT_NODE) {
              if (node.textContent?.trim()) target.appendChild(document.createTextNode(node.textContent));
              return;
            }
            if (!(node instanceof HTMLElement)) return;
            if (node.tagName === 'SCRIPT') { appendExecutableScript(node as HTMLScriptElement, target); return; }
            // Monetag code may use a div/container, iframe, image or link. Reject unsafe URL schemes.
            if (node.tagName === 'IFRAME') {
              const src = node.getAttribute('src');
              if (src) { try { if (new URL(src, window.location.href).protocol !== 'https:') return; } catch { return; } }
            }
            const clone = document.createElement(node.tagName.toLowerCase());
            Array.from(node.attributes).forEach((attr) => {
              const name = attr.name.toLowerCase();
              if (name.startsWith('on')) return;
              if (['src', 'href', 'data'].includes(name) && attr.value.trim()) {
                try { const url = new URL(attr.value, window.location.href); if (url.protocol !== 'https:' && !attr.value.startsWith('#')) return; } catch { return; }
              }
              clone.setAttribute(attr.name, attr.value);
            });
            if (node.tagName === 'STYLE') clone.textContent = node.textContent;
            else if (node.tagName !== 'SCRIPT') appendNodes(Array.from(node.childNodes), clone as HTMLElement);
            target.appendChild(clone);
          });
        };
        appendNodes(Array.from(parsed.body.childNodes), slot);
        // Some Monetag snippets put script-only configuration in the head.
        parsed.head.querySelectorAll('script').forEach((script) => appendExecutableScript(script, slot));
        if (!slot.childNodes.length) setLoadError(true);
      } else {
        let url: URL;
        try { url = new URL(config.scriptUrl); } catch { setLoadError(true); return; }
        if (url.protocol !== 'https:') { setLoadError(true); return; }
        const script = document.createElement('script');
        script.src = url.toString();
        script.async = true;
        script.dataset.zone = config.zoneId;
        script.dataset.monetagZone = config.zoneId;
        script.onload = () => { if (!cancelled) setLoadError(false); };
        script.onerror = () => { if (!cancelled) setLoadError(true); };
        slot.appendChild(script);
      }
    } catch (err) {
      console.warn('Could not mount Monetag ad code', err);
      setLoadError(true);
    }

    return () => { cancelled = true; slot.replaceChildren(); };
  }, [config]);

  const configured = Boolean(config.adCode.trim() || (config.zoneId && config.scriptUrl));
  if (!settingsLoaded || !config.enabled || !configured) return null;
  return <div id="monetag-feed-ad-slot" className="my-4 min-h-[60px] rounded-2xl border border-[#168BFF]/20 bg-[#07152B]/70 p-3 text-center" aria-label="Sponsored advertisement">
    <span className="text-[9px] uppercase tracking-[0.2em] text-[#A8BCD7]">Sponsored</span>
    {loadError && <p className="mt-1 text-[10px] text-amber-200">Monetag code could not load. Check the exact code copied from your Monetag dashboard and the browser console.</p>}
  </div>;
};
