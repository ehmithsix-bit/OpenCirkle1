import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { UserProfile } from '../../types';
import { fetchSuggestedUsers, toggleFollowUser } from '../../services/socialService';
import { CrystalAvatar } from './CrystalAvatar';
import { VerifiedBadge } from './VerifiedBadge';
import { Sparkles, Hash, TrendingUp, Search, UserPlus, CheckCircle2, Shield } from 'lucide-react';

interface TrendingSidebarProps {
  onSearch: (term: string) => void;
  onHashtagClick: (tag: string) => void;
  onUserClick: (username: string) => void;
  onOpenAuth?: () => void;
}

export const TrendingSidebar: React.FC<TrendingSidebarProps> = ({
  onSearch,
  onHashtagClick,
  onUserClick,
  onOpenAuth,
}) => {
  const { currentUserProfile } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [suggestedUsers, setSuggestedUsers] = useState<UserProfile[]>([]);
  const [followingMap, setFollowingMap] = useState<Record<string, boolean>>({});

  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        const users = await fetchSuggestedUsers(currentUserProfile?.uid);
        if (active) setSuggestedUsers(users);
      } catch (err) {
        console.warn('Failed to load suggestions:', err);
      }
    };
    load();
    return () => {
      active = false;
    };
  }, [currentUserProfile?.uid]);

  const handleFollowToggle = async (targetUser: UserProfile) => {
    if (!currentUserProfile) {
      if (onOpenAuth) onOpenAuth();
      return;
    }

    try {
      const res = await toggleFollowUser(currentUserProfile, targetUser);
      setFollowingMap((prev) => ({
        ...prev,
        [targetUser.uid]: res.status === 'following' || res.status === 'requested',
      }));
    } catch (err) {
      console.error('Follow error:', err);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      onSearch(searchTerm.trim());
    }
  };

  const trendingTopics = [
    { tag: 'OpenCirkle', count: '1.4k posts' },
    { tag: 'Cryptography', count: '840 posts' },
    { tag: 'TextOnly', count: '620 posts' },
    { tag: 'DigitalMinimalism', count: '410 posts' },
    { tag: 'NetworkTheory', count: '390 posts' },
  ];

  return (
    <aside className="w-80 shrink-0 py-6 px-4 space-y-6 hidden lg:block">
      {/* Search Input */}
      <form onSubmit={handleSearchSubmit} className="relative">
        <Search className="w-4 h-4 text-[#A8BCD7] absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search thoughts, @users, #tags..."
          className="w-full bg-[#071A38]/70 border border-[#168BFF]/20 rounded-xl pl-10 pr-4 py-2.5 text-xs text-[#F1F8FF] placeholder-[#A8BCD7]/50 focus:outline-none focus:border-[#168BFF] focus:ring-1 focus:ring-[#168BFF] transition-all"
        />
      </form>

      {/* Trending Topics Card */}
      <div className="crystal-card rounded-2xl p-4 border border-[#168BFF]/15">
        <div className="flex items-center gap-2 mb-3">
          <TrendingUp className="w-4 h-4 text-[#8DDCFF]" />
          <h3 className="text-xs font-bold text-[#F1F8FF] uppercase tracking-wider">
            Trending Nodes
          </h3>
        </div>

        <div className="space-y-2.5">
          {trendingTopics.map((item) => (
            <button
              key={item.tag}
              onClick={() => onHashtagClick(item.tag)}
              className="w-full flex items-center justify-between text-left group p-1.5 rounded-lg hover:bg-[#071A38]/60 transition-colors"
            >
              <div>
                <p className="text-xs font-mono font-semibold text-[#8DDCFF] group-hover:text-white transition-colors">
                  #{item.tag}
                </p>
                <p className="text-[10px] text-[#A8BCD7] font-mono">{item.count}</p>
              </div>
              <Hash className="w-3.5 h-3.5 text-[#168BFF]/40 group-hover:text-[#168BFF] transition-colors" />
            </button>
          ))}
        </div>
      </div>

      {/* Recommended Thinkers */}
      {suggestedUsers.length > 0 && (
        <div className="crystal-card rounded-2xl p-4 border border-[#168BFF]/15">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="w-4 h-4 text-[#8DDCFF]" />
            <h3 className="text-xs font-bold text-[#F1F8FF] uppercase tracking-wider">
              Discourse Nodes
            </h3>
          </div>

          <div className="space-y-3">
            {suggestedUsers.slice(0, 4).map((user) => {
              const isFollowed = followingMap[user.uid];
              return (
                <div key={user.uid} className="flex items-center justify-between gap-2">
                  <button
                    onClick={() => onUserClick(user.username)}
                    className="flex items-center gap-2.5 text-left group min-w-0"
                  >
                    <CrystalAvatar
                      displayName={user.displayName}
                      username={user.username}
                      avatarSymbol={user.avatarSymbol}
                          avatarUrl={user.avatarUrl}
                      avatarColor={user.avatarColor}
                      size="sm"
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1">
                        <span className="text-xs font-semibold text-[#F1F8FF] group-hover:text-[#8DDCFF] transition-colors truncate">
                          {user.displayName}
                        </span>
                        {user.verified && <VerifiedBadge size="sm" title="Verified account" />}
                      </div>
                      <span className="text-[10px] font-mono text-[#A8BCD7] truncate block">
                        @{user.username}
                      </span>
                    </div>
                  </button>

                  <button
                    onClick={() => handleFollowToggle(user)}
                    className={`px-3 py-1 text-[11px] font-semibold rounded-lg transition-all shrink-0 ${
                      isFollowed
                        ? 'bg-[#071A38] text-[#8DDCFF] border border-[#168BFF]/30'
                        : 'bg-gradient-to-r from-[#0D47A1] to-[#168BFF] text-white hover:shadow-[0_0_10px_rgba(22,139,255,0.4)]'
                    }`}
                  >
                    {isFollowed ? 'Following' : 'Connect'}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Network Manifesto Card */}
      <div className="p-4 rounded-2xl bg-[#050A18]/80 border border-[#168BFF]/15 text-xs text-[#A8BCD7] space-y-2">
        <div className="flex items-center gap-2 text-[#8DDCFF] font-semibold">
          <Shield className="w-4 h-4 text-[#168BFF]" />
          <span>The Crystal Protocol</span>
        </div>
        <p className="text-[11px] leading-relaxed text-[#A8BCD7]/80">
          Strictly text-only. Pure typography, zero media clutter. Authenticated with Firebase, preserved in Firestore.
        </p>
        <p className="text-[10px] text-[#A8BCD7]/50 pt-1 font-mono">
          OpenCirkle © 2026 · Crystal Crypt Architecture
        </p>
      </div>
    </aside>
  );
};
