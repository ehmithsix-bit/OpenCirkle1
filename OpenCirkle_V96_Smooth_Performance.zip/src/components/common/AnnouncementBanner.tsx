import React, { useState, useEffect } from 'react';
import { PlatformAnnouncement } from '../../types';
import { fetchActiveAnnouncements } from '../../services/moderationService';
import { Sparkles, AlertCircle, Info, Wrench, X } from 'lucide-react';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';

export const AnnouncementBanner: React.FC = () => {
  const [announcements, setAnnouncements] = useState<PlatformAnnouncement[]>([]);
  const [dismissed, setDismissed] = useState<Record<string, boolean>>({});
  const [cardStyle, setCardStyle] = useState<any>({ background:'#071A38', accent:'#168BFF', radius:16, compact:false, showIcon:true });
  useEffect(() => { let active=true; const apply=(c:any)=>{if(c?.announcementCard)setCardStyle((p:any)=>({...p,...c.announcementCard}));}; getDoc(doc(db,'platformSettings','global')).then(s=>{if(active&&s.exists())apply(s.data().appCustomization);}).catch(()=>{}); const onUpdate=(e:Event)=>apply((e as CustomEvent).detail); window.addEventListener('oc-app-customization-updated',onUpdate); return ()=>{active=false;window.removeEventListener('oc-app-customization-updated',onUpdate)}; }, []);

  useEffect(() => {
    let active = true;
    fetchActiveAnnouncements().then((list) => {
      if (active) setAnnouncements(list);
    });
    return () => {
      active = false;
    };
  }, []);

  const activeVisible = announcements.filter((a) => !dismissed[a.id]);
  if (activeVisible.length === 0) return null;

  const current = activeVisible[0];

  const getIcon = () => {
    switch (current.type) {
      case 'alert':
        return <AlertCircle className="w-4 h-4 text-[#FF6B6B]" />;
      case 'maintenance':
        return <Wrench className="w-4 h-4 text-[#FFD166]" />;
      case 'feature':
        return <Sparkles className="w-4 h-4 text-[#8DDCFF]" />;
      case 'info':
      default:
        return <Info className="w-4 h-4 text-[#168BFF]" />;
    }
  };

  return (
    <div className={`mb-6 ${cardStyle.compact ? 'p-2.5' : 'p-4'} flex items-start justify-between gap-3 text-xs shadow-[0_0_20px_rgba(22,139,255,0.15)]`} style={{ borderRadius: `${Math.max(0,Math.min(32,Number(cardStyle.radius)||16))}px`, background: cardStyle.background || '#071A38', border: `1px solid ${cardStyle.accent || '#168BFF'}66` }}>
      <div className="flex items-start gap-3">
        {cardStyle.showIcon !== false && <div className="p-1.5 rounded-lg bg-[#050A18] border shrink-0 mt-0.5" style={{borderColor:cardStyle.accent||'#168BFF'}}>
          {getIcon()}
        </div>}
        <div>
          <span className="font-bold text-[#F1F8FF] block mb-0.5">{current.title}</span>
          <p className="text-[#A8BCD7] leading-relaxed">{current.content}</p>
        </div>
      </div>

      <button
        onClick={() => setDismissed((prev) => ({ ...prev, [current.id]: true }))}
        className="p-1 text-[#A8BCD7] hover:text-[#F1F8FF] rounded-lg transition-colors shrink-0"
        title="Dismiss announcement"
      >
        <X className="w-4 h-4" />
      </button>
    </div>
  );
};
