import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { CrystalAvatar } from './CrystalAvatar';
import {
  MessageSquare,
  Compass,
  Bookmark,
  User,
  Settings,
  ShieldCheck,
  LogOut,
  PenSquare,
  Sparkles,
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenCompose: () => void;
  unreadNotifsCount?: number;
  unreadMessagesCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  onOpenCompose,
  unreadNotifsCount = 0,
  unreadMessagesCount = 0,
}) => {
  const { currentUserProfile, logout, isModerator } = useAuth();

  const navItems = [
    { id: 'feed', label: 'Discourse', icon: Sparkles },
    { id: 'explore', label: 'Explore', icon: Compass },
    ...(currentUserProfile
      ? [
          {
            id: 'messages',
            label: 'Crypt Messages',
            icon: MessageSquare,
            badge: unreadMessagesCount > 0 ? unreadMessagesCount : undefined,
          },
          { id: 'bookmarks', label: 'Saved Vault', icon: Bookmark },
          { id: 'profile', label: 'Crystalline Profile', icon: User },
          { id: 'settings', label: 'Security & Preferences', icon: Settings },
        ]
      : []),
    ...(isModerator
      ? [
          {
            id: 'admin',
            label: 'Admin Control',
            icon: ShieldCheck,
            highlight: true,
          },
        ]
      : []),
  ];

  return (
    <aside className="w-64 shrink-0 hidden lg:flex flex-col justify-between py-6 px-3 border-r border-[#168BFF]/15 min-h-[calc(100vh-65px)]">
      <div className="space-y-6">
        {/* Navigation list */}
        <nav className="space-y-1.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all group ${
                  isActive
                    ? 'bg-gradient-to-r from-[#0D47A1]/60 to-[#168BFF]/20 text-[#8DDCFF] border border-[#168BFF]/40 shadow-[0_0_15px_rgba(22,139,255,0.15)]'
                    : 'text-[#A8BCD7] hover:text-[#F1F8FF] hover:bg-[#071A38]/50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={`w-4 h-4 transition-transform group-hover:scale-110 ${
                      isActive ? 'text-[#8DDCFF]' : 'text-[#A8BCD7] group-hover:text-[#8DDCFF]'
                    }`}
                  />
                  <span className="truncate">{item.label}</span>
                </div>
                {item.badge !== undefined && (
                  <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-[#168BFF] text-white">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Compose CTA */}
        {currentUserProfile && (
          <button
            onClick={onOpenCompose}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 text-sm font-semibold text-white bg-gradient-to-r from-[#0D47A1] via-[#168BFF] to-[#0D47A1] rounded-xl hover:shadow-[0_0_20px_rgba(22,139,255,0.4)] transition-all active:scale-95"
          >
            <PenSquare className="w-4 h-4" />
            <span>Publish Text</span>
          </button>
        )}
      </div>

      {/* User Status Bar at the bottom */}
      {currentUserProfile && (
        <div className="pt-4 border-t border-[#168BFF]/15">
          <div className="p-3 rounded-2xl bg-[#071A38]/50 border border-[#168BFF]/20 flex items-center justify-between">
            <button
              onClick={() => setActiveTab('profile')}
              className="flex items-center gap-3 text-left overflow-hidden group focus:outline-none"
            >
              <CrystalAvatar
                displayName={currentUserProfile.displayName}
                username={currentUserProfile.username}
                avatarSymbol={currentUserProfile.avatarSymbol}
                avatarUrl={currentUserProfile.avatarUrl}
                avatarColor={currentUserProfile.avatarColor}
                size="sm"
              />
              <div className="truncate">
                <p className="text-xs font-semibold text-[#F1F8FF] truncate group-hover:text-[#8DDCFF] transition-colors">
                  {currentUserProfile.displayName}
                </p>
                <p className="text-[11px] font-mono text-[#A8BCD7] truncate">
                  @{currentUserProfile.username}
                </p>
              </div>
            </button>
            <button
              onClick={logout}
              title="Sign Out"
              className="p-1.5 text-[#A8BCD7] hover:text-[#FF6B6B] hover:bg-[#FF6B6B]/10 rounded-lg transition-colors"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </aside>
  );
};
