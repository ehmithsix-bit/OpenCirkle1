import React, { useEffect, useState } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../../lib/firebase';

type SponsorSettings = { sponsorAdsEnabled?: boolean; sponsorClickAdsEnabled?: boolean; sponsorTitle?: string; sponsorDescription?: string; sponsorImageUrl?: string; sponsorTargetUrl?: string };
/** Admin-controlled sponsor placement. Only HTTPS image and destination URLs are rendered; arbitrary code is never executed. */
export const SponsorAdSlot: React.FC = () => {
  const [settings, setSettings] = useState<SponsorSettings>({});
  useEffect(() => onSnapshot(doc(db, 'platformSettings', 'global'), snap => setSettings(snap.exists() ? snap.data() as SponsorSettings : {}), err => console.warn('Sponsor settings unavailable', err)), []);
  if (!settings.sponsorAdsEnabled) return null;
  let target = '', image = '';
  try { target = new URL(settings.sponsorTargetUrl || '').protocol === 'https:' ? new URL(settings.sponsorTargetUrl || '').toString() : ''; } catch {}
  try { image = new URL(settings.sponsorImageUrl || '').protocol === 'https:' ? new URL(settings.sponsorImageUrl || '').toString() : ''; } catch {}
  if (!target || !settings.sponsorTitle) return null;
  const content = <div className="my-4 rounded-2xl border border-[#8DDCFF]/25 bg-[#07152b] p-4"><div className="mb-2 text-[10px] uppercase tracking-widest text-[#8DDCFF]">Sponsored</div>{image && <img src={image} alt="" loading="lazy" className="mb-3 max-h-48 w-full rounded-xl object-cover" />}<strong className="block text-sm text-white">{settings.sponsorTitle}</strong>{settings.sponsorDescription && <p className="mt-1 text-xs text-[#A8BCD7]">{settings.sponsorDescription}</p>}{settings.sponsorClickAdsEnabled && <a href={target} target="_blank" rel="noopener noreferrer sponsored" className="mt-3 inline-flex rounded-xl bg-blue-600 px-4 py-2 text-xs font-bold text-white">Learn more</a>}</div>;
  return <>{content}</>;
};
