import React, { useEffect, useState } from 'react';
import { CrystalAvatar } from '../common/CrystalAvatar';
import { Plus, X, Send, Loader2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { DiscourseSphereItem, DiscourseSphereModal } from './DiscourseSphereModal';
import { addDoc, collection, deleteDoc, doc, limit, onSnapshot, orderBy, query, Timestamp } from 'firebase/firestore';
import { db } from '../../lib/firebase';

// Remove undefined values before sending story data to Firestore. Keep valid
// Firestore Timestamp/Date values intact and recursively sanitize nested data.
const cleanFirestoreData = <T,>(value: T): T => {
  if (value === undefined || typeof value === 'function' || typeof value === 'symbol') return undefined as T;
  if (value === null || typeof value !== 'object') {
    return typeof value === 'number' && !Number.isFinite(value) ? (null as T) : value;
  }
  if (value instanceof Date || (typeof (value as any).toMillis === 'function' && typeof (value as any).seconds === 'number')) return value;
  if (Array.isArray(value)) return value.filter((item) => item !== undefined).map((item) => cleanFirestoreData(item)) as T;
  const cleaned: Record<string, unknown> = {};
  Object.entries(value as Record<string, unknown>).forEach(([key, item]) => {
    if (item !== undefined && typeof item !== 'function' && typeof item !== 'symbol') cleaned[key] = cleanFirestoreData(item);
  });
  return cleaned as T;
};

// Accept Firestore Timestamp values and numeric timestamps stored in seconds or milliseconds.
const toMillis = (value: any): number => {
  if (typeof value === 'number') return value > 0 && value < 1_000_000_000_000 ? value * 1000 : value;
  if (value && typeof value.toMillis === 'function') return value.toMillis();
  if (value && typeof value.seconds === 'number') return value.seconds * 1000;
  return 0;
};

interface IOSStorySpheresProps {
  onOpenCompose: () => void;
  onUserClick: (username: string) => void;
}

export const IOSStorySpheres: React.FC<IOSStorySpheresProps> = ({ onOpenCompose, onUserClick }) => {
  const { currentUserProfile, firebaseUser } = useAuth();
  const [selectedSphere, setSelectedSphere] = useState<DiscourseSphereItem | null>(null);
  const [stories, setStories] = useState<DiscourseSphereItem[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [thought, setThought] = useState('');
  const [photoDataUrl, setPhotoDataUrl] = useState('');
  const [photoName, setPhotoName] = useState('');
  const [tag, setTag] = useState('MyStory');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [publishStatus, setPublishStatus] = useState('');
  const [storyLoadError, setStoryLoadError] = useState(false);
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const openStory = (event: Event) => {
      const id = (event as CustomEvent<{ id?: string }>).detail?.id;
      if (!id) return;
      const story = stories.find(item => item.id === id);
      if (story) setSelectedSphere(story);
    };
    window.addEventListener('opencirkle:open-story', openStory);
    return () => window.removeEventListener('opencirkle:open-story', openStory);
  }, [stories]);

  useEffect(() => {
    // Refresh expiry visibility without requiring a page reload.
    const expiryTimer = window.setInterval(() => setNow(Date.now()), 30_000);
    return () => window.clearInterval(expiryTimer);
  }, []);

  useEffect(() => {
    const q = query(collection(db, 'stories'), orderBy('createdAt', 'desc'), limit(20));
    return onSnapshot(q, (snapshot) => {
      setStoryLoadError(false);
      const docs = snapshot.docs;
      // Best-effort cleanup for this author's expired stories. Configure Firestore TTL on expiresAt for reliable server-side deletion.
      docs.forEach((d) => {
        const v = d.data();
        const created = toMillis(v.createdAt);
        // Enforce a hard 24-hour lifetime from creation even if an old/malformed expiresAt is later.
        const expiry = Math.min(toMillis(v.expiresAt) || (created + 24 * 60 * 60 * 1000), created + 24 * 60 * 60 * 1000);
        if (firebaseUser?.uid && v.authorId === firebaseUser.uid && expiry > 0 && expiry <= Date.now()) {
          deleteDoc(doc(db, 'stories', d.id)).catch(() => {});
        }
      });
      setStories(snapshot.docs.map((d) => {
        const v = d.data();
        return {
          id: d.id,
          authorId: v.authorId || '',
          viewers: Array.isArray(v.viewers) ? v.viewers : [],
          viewerIds: Array.isArray(v.viewerIds) ? v.viewerIds : [],
          authorUsername: v.authorUsername || 'user',
          authorDisplayName: v.authorDisplayName || v.authorUsername || 'OpenCirkle User',
          avatarSymbol: v.avatarSymbol || 'gem',
          avatarColor: v.avatarColor || 'electric',
          avatarUrl: typeof v.avatarUrl === 'string' ? v.avatarUrl : undefined,
          thought: v.thought || '',
          imageDataUrl: typeof v.imageDataUrl === 'string' ? v.imageDataUrl : '',
          tag: v.tag || 'MyStory',
          createdAt: toMillis(v.createdAt),
          expiresAt: toMillis(v.expiresAt) || undefined,
        } as DiscourseSphereItem & { expiresAt?: number };
      }));
    }, (e) => { console.warn('Could not load stories:', e); setStoryLoadError(true); });
  }, [firebaseUser?.uid]);

  // Story documents already contain the author's display fields. Avoid opening
  // one extra realtime users/{uid} listener for every story author; this keeps
  // the story strip to a single bounded Firestore listener.

  const publishStory = async () => {
    const text = thought.trim();
    if (!firebaseUser || !currentUserProfile) { setError('Please sign in to publish a story.'); return; }
    if (!text && !photoDataUrl) { setError('Write something or select a photo before publishing.'); return; }
    if (text.length > 500) { setError('Stories can contain up to 500 characters.'); return; }
    setSaving(true); setError('');
    try {
      const nowMs = Date.now();
      const storyPayload = cleanFirestoreData({
        authorId: firebaseUser.uid,
        authorUsername: currentUserProfile.username || '',
        authorDisplayName: currentUserProfile.displayName || currentUserProfile.username || '',
        avatarSymbol: currentUserProfile.avatarSymbol || 'gem',
        avatarColor: currentUserProfile.avatarColor || 'electric',
        avatarUrl: currentUserProfile.avatarUrl || '',
        thought: text,
        imageDataUrl: photoDataUrl || '',
        tag: tag.trim().replace(/^#/, '').replace(/[^a-zA-Z0-9_]/g, '').slice(0, 24) || 'MyStory',
        createdAt: nowMs,
        expiresAt: Timestamp.fromMillis(nowMs + 24 * 60 * 60 * 1000),
      });
      // Firestore applies writes optimistically, but addDoc() can remain pending until
      // the server acknowledges the write (for example, a slow/offline Android network).
      // Do not leave the composer spinning forever: after 12s, close it and show a clear
      // syncing state while the same write continues in the background. Never retry here,
      // because that could create duplicate stories.
      const writePromise = addDoc(collection(db, 'stories'), storyPayload);
      const result = await Promise.race([
        writePromise.then(() => 'saved' as const),
        new Promise<'pending'>((resolve) => window.setTimeout(() => resolve('pending'), 12_000)),
      ]);
      setThought(''); setPhotoDataUrl(''); setPhotoName(''); setTag('MyStory'); setShowCreate(false);
      if (result === 'saved') {
        setPublishStatus('Story published successfully.');
      } else {
        setPublishStatus('Story is showing on your device and is still syncing with Firebase…');
        // Handle the eventual server result without keeping the publish button spinning.
        void writePromise.then(() => {
          setPublishStatus('Story published successfully.');
        }).catch((writeError) => {
          console.error('Story sync failed:', writeError);
          setPublishStatus('Story could not sync to Firebase. Check your internet connection and Firestore rules, then try again.');
        });
      }
    } catch (e) {
      console.error('Story publish failed:', e);
      setError('Story could not be published to Firebase. Check your connection and Firestore rules.');
    } finally { setSaving(false); }
  };

  // Never show expired stories. expiresAt is preferred; legacy documents fall back to createdAt + 24h.
  // Keep every active story; do not collapse an author's stories into only the latest one.
  const visibleStories = stories.filter((s) => {
    const storedExpiry = (s as DiscourseSphereItem & { expiresAt?: number }).expiresAt;
    // A story must disappear after 24h based on createdAt, even if expiresAt is wrong.
    const hardExpiry = s.createdAt + 24 * 60 * 60 * 1000;
    const expiry = storedExpiry ? Math.min(storedExpiry, hardExpiry) : hardExpiry;
    return s.createdAt > 0 && s.createdAt <= now && expiry > now && hardExpiry > now;
  }).sort((a, b) => b.createdAt - a.createdAt);
  // One story ring per author; opening it lets viewers move through every active story from that author.
  const storyGroups = Array.from(visibleStories.reduce((groups, story) => {
    const key = story.authorId || story.authorUsername;
    const group = groups.get(key) || []; group.push(story); groups.set(key, group); return groups;
  }, new Map<string, DiscourseSphereItem[]>()).values());
  return (
    <div className="w-full mb-6">
      {publishStatus && <p role="status" className={`mb-2 rounded-xl border px-3 py-2 text-xs ${publishStatus.includes('could not') ? 'border-rose-300/20 bg-rose-300/5 text-rose-100' : 'border-emerald-300/20 bg-emerald-300/5 text-emerald-100'}`}>{publishStatus}<button type="button" className="ml-2 underline" onClick={() => setPublishStatus('')} aria-label="Dismiss story status">Dismiss</button></p>}
      {storyLoadError && <p role="status" className="mb-2 rounded-xl border border-amber-300/20 bg-amber-300/5 px-3 py-2 text-xs text-amber-100">Stories couldn’t refresh. Check your connection or Firestore access.</p>}
      <div className="flex items-center gap-4 overflow-x-auto pb-2 scrollbar-none px-1">
        <button onClick={() => { setError(''); setShowCreate(true); }} className="flex flex-col items-center gap-1.5 shrink-0 ios-press group focus:outline-none">
          <div className="relative w-16 h-16 rounded-full p-[3px] story-instagram-ring group-hover:scale-105 transition-transform">
            <div className="w-full h-full rounded-full bg-[#071A38] flex items-center justify-center border border-white/20">
              <Plus className="w-6 h-6 text-white" />
            </div>
          </div>
          <span className="text-[11px] font-medium text-[#A8BCD7] group-hover:text-[#F1F8FF] truncate max-w-[64px]">Your Story</span>
        </button>
        {storyGroups.map((group) => { const sphere = group[0]; return (
          <button key={sphere.authorId || sphere.authorUsername} onClick={() => setSelectedSphere({ ...sphere, storyItems: group } as DiscourseSphereItem)} className="flex flex-col items-center gap-1.5 shrink-0 ios-press group focus:outline-none">
            <div className="relative w-16 h-16 rounded-full p-[3px] story-instagram-ring group-hover:scale-105 transition-transform">
              <div className="w-full h-full rounded-full bg-[#050A18] p-[2px] flex items-center justify-center">
                <CrystalAvatar displayName={sphere.authorDisplayName} username={sphere.authorUsername} avatarSymbol={sphere.avatarSymbol} avatarUrl={sphere.avatarUrl} avatarColor={sphere.avatarColor} size="lg" className="w-full h-full rounded-full" />
              </div>
            </div>
            <span className="text-[11px] font-semibold text-[#F1F8FF] group-hover:text-[#8DDCFF] truncate max-w-[64px]">{sphere.authorDisplayName}</span>
          </button>
        ); })}
      </div>

      {showCreate && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-md rounded-3xl border border-[#168BFF]/40 bg-[#071A38] p-5 shadow-2xl">
            <div className="flex items-center justify-between mb-4"><h2 className="text-lg font-bold text-white">Create a story</h2><button onClick={() => setShowCreate(false)} className="p-2 rounded-full text-slate-300 hover:bg-white/10" aria-label="Close"><X className="w-5 h-5" /></button></div>
            <p className="text-xs text-[#A8BCD7] mb-3">Photo and/or text story · visible for 24 hours · up to 500 characters. Photos are compressed and saved in the story document; Firebase Storage is not used.</p>
            <textarea value={thought} onChange={(e) => setThought(e.target.value)} maxLength={500} rows={4} placeholder="What would you like to share? (optional if you add a photo)" className="w-full resize-none rounded-2xl bg-[#050A18] border border-white/10 focus:border-[#168BFF] outline-none p-4 text-white placeholder:text-slate-500" />
            <label className="mt-3 flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-[#168BFF]/40 bg-[#050A18]/70 px-3 py-3 text-sm text-[#8DDCFF]">📷 Add photo (JPG / PNG / WebP)<input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={async (e) => { const input=e.currentTarget; const file=input.files?.[0]; if(!file)return; try { if(!file.type.startsWith('image/')) throw new Error('Choose an image file.'); const bitmap=await createImageBitmap(file); const scale=Math.min(1,900/Math.max(bitmap.width,bitmap.height)); const canvas=document.createElement('canvas'); canvas.width=Math.max(1,Math.round(bitmap.width*scale)); canvas.height=Math.max(1,Math.round(bitmap.height*scale)); const ctx=canvas.getContext('2d'); if(!ctx)throw new Error('Could not process this photo.'); ctx.drawImage(bitmap,0,0,canvas.width,canvas.height); bitmap.close(); let quality=.65; let data=canvas.toDataURL('image/jpeg',quality); while(data.length*0.75>260*1024 && quality>.28){quality-=.07;data=canvas.toDataURL('image/jpeg',quality);} if(data.length*0.75>300*1024)throw new Error('Photo is too large after compression. Try a smaller image.'); setPhotoDataUrl(data);setPhotoName(file.name);setError(''); } catch(err:any){setError(err?.message||'Could not load photo.');setPhotoDataUrl('');setPhotoName('');} input.value=''; }} /></label>
            {photoDataUrl && <div className="mt-2 flex items-center gap-3 rounded-xl bg-black/20 p-2"><img src={photoDataUrl} alt="Story preview" className="h-16 w-16 rounded-lg object-cover"/><span className="min-w-0 flex-1 truncate text-xs text-[#A8BCD7]">{photoName||'Selected photo'}</span><button type="button" onClick={()=>{setPhotoDataUrl('');setPhotoName('');}} className="rounded-lg p-2 text-rose-300" aria-label="Remove photo">Remove</button></div>}
            <div className="flex items-center justify-between mt-2 mb-3"><input value={tag} onChange={(e) => setTag(e.target.value)} maxLength={24} placeholder="Story tag" className="w-2/3 rounded-xl bg-[#050A18] border border-white/10 focus:border-[#168BFF] outline-none px-3 py-2 text-sm text-white" /><span className="text-xs text-slate-400">{thought.length}/500</span></div>
            {error && <p className="text-sm text-rose-300 mb-3">{error}</p>}
            {!firebaseUser && <p className="text-sm text-amber-200 mb-3">Sign in before posting a story.</p>}
            <button onClick={publishStory} disabled={saving || (!thought.trim() && !photoDataUrl)} className="w-full rounded-2xl py-3 bg-gradient-to-r from-[#833AB4] via-[#E1306C] to-[#FCAF45] text-white font-bold flex items-center justify-center gap-2 disabled:opacity-50">{saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}{saving ? 'Publishing…' : 'Share story'}</button>
          </div>
        </div>
      )}
      {selectedSphere && <DiscourseSphereModal sphere={selectedSphere} onClose={() => setSelectedSphere(null)} onUserClick={onUserClick} />}
    </div>
  );
};
