# OpenCirkle V94 — consistent verified badge coverage

- Reused the shared, admin-configurable `VerifiedBadge` artwork in Trending suggestions, comment author names, and share-recipient search results.
- Conversation participant snapshots now retain the verified flag, so verified accounts show the same badge in the chat list and active chat header.
- The live story author header now displays the blue badge based on the author's current Firestore verification status.
- Existing badge rendering in feed posts, Explore, profiles, and follower/following lists remains unchanged.
- Verification is shown only when the relevant user record explicitly has `verified: true`.
- Dependency installation timed out in this environment; production build/type-check could not be completed.
