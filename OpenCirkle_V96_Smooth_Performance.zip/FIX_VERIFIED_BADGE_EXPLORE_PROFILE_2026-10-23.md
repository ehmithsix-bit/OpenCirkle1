# Verified badge and profile layout fix — 2026-10-23

- Explore / Discourse Thinkers now uses the shared `VerifiedBadge` component instead of the legacy Lucide `CheckCircle2` icon, so it uses the same configurable artwork as Home.
- Profile header shows the verified badge next to the display name only. The username is rendered on its own line immediately below the name, without a badge.
- Static source checks performed; a full production build and live Firebase test were not run in this environment.
