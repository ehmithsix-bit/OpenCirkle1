# OpenCirkle v58 — Mandatory Update + Offline UI

## Admin setup
1. Open Admin Control Center → App Update Distribution.
2. Enable **Show app update to users**.
3. Set the HTTPS APK/release download URL.
4. Set **Required Android version code** to the versionCode built into the APK (this project is set to `58` in `android/app/build.gradle`).
5. Save platform settings.

Users whose installed Android `versionCode` is lower than the required code see the supplied mandatory App Update artwork. The Update Now hotspot opens the configured URL. Users with versionCode equal to or higher than the required code continue normally.

For the next release, increment `versionCode` in `android/app/build.gradle`, build and publish that APK, then set the same number as the admin required version code. Do not set the admin required code higher than the APK currently available to users.

## Offline UI
When the device reports offline, the supplied network-error artwork replaces the app UI. The Try again hotspot reloads if connectivity is back; otherwise it remains on the offline screen. When the browser/native WebView emits the online event, the app returns to its normal gate flow and checks for mandatory updates.

## Native bridge
`AppVersionPlugin` reads the actual installed Android package versionCode using PackageManager. It is registered in MainActivity and exposed to React via Capacitor's `AppVersion` plugin.

## Notes
- This enforces the minimum version inside the client UI; protect sensitive APIs/data separately with backend policy if old clients must be blocked server-side.
- The update URL must be HTTPS and publicly reachable.
- Android package installation still requires Android's user/system install confirmation. The app cannot silently install an APK.
- Offline detection uses the platform/browser online/offline events. Some Wi-Fi networks report online even when upstream internet is unavailable.
