# OpenCirkle v78 — Firestore read/listener optimization

Changes based on v77 source:

- Story strip query reduced from 60 to 20 recent story documents.
- Removed one realtime `users/{uid}` listener per distinct story author. Story documents already include display name/avatar snapshots; the strip now uses one bounded stories listener instead of up to 20 additional user listeners.
- Removed one realtime author-profile listener per visible PostCard. Feed posts already contain denormalized author name/avatar/verification fields, so cards render from the post snapshot. This avoids multiplying user document reads/listeners by the number of visible posts.
- `createPost` now reads `platformSettings/global` only when collaborators were actually invited; ordinary text posts no longer perform that extra read.
- Share-to-user modal initial directory query reduced from 80 users to 25 to avoid a large burst of reads when opening the modal.

Safety:
- No Firestore collections or live database documents/fields were deleted.
- No user posts, messages, profiles, stories, follows, notifications, or counters were removed.
- This is source-code query/listener optimization only. It does not clean existing Firebase data.

Validation:
- Static source edits completed. Build/tests were not run because dependencies are not installed in this workspace. Please run `npm install`, `npm run lint`, and `npm run build` in your development environment before release.
