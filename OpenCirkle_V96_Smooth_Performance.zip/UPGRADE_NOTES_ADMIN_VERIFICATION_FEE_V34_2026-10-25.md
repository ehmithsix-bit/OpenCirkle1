# OpenCirkle v34 — Admin-controlled verification fee

- The profile's “Get Your Profile Verified” button now reads `platformSettings/global.verificationFee` live from Firestore and displays the saved amount instead of a hard-coded ৳120.
- The verification form already reads the same Firestore setting for the form heading, Continue to Pay button, Send Money amount, and instructions.
- Admin Control Center → App settings → Verification fee (BDT ৳) lets an authorized admin save a fee from ৳1 to ৳100,000.
- New requests store the current `paymentAmount`; existing requests retain their submitted amount.
- The verification review panel no longer claims every payment is ৳120.

Deploy the updated app and use the same Firebase project/document (`platformSettings/global`) for the admin panel and app. The setting requires valid Firestore read/write rules for authorized admins and app reads.
