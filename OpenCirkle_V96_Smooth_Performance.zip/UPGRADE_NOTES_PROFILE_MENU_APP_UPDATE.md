# OpenCirkle Profile More Menu + App Update Link

## Changes
- Added a three-dot menu to the profile action row.
- Menu options include Update This App, Edit profile settings, Monetize & Wallet, Public/Private account toggle, Refresh app, and Report this profile when viewing another user's profile.
- The profile subscribes to `platformSettings/global` so app update availability/version/notes update live.
- Admin Platform Parameters and the standalone Admin Panel now let authorized admins set `appUpdateEnabled`, `appUpdateUrl`, `appUpdateVersion`, and `appUpdateNotes`.
- Update URLs must use HTTPS; the app opens the configured release/download URL in a new tab/window.

## Important behavior
- This is a web app. The Update This App action can open/download an APK, ZIP, or release page; it cannot silently replace the currently deployed website source. Website code updates still require a new Netlify deployment. Android APK installation requires user confirmation.
- The profile app reads the public update link from the existing Firestore document `platformSettings/global`.
- Admin settings are stored in Firestore and must be saved after editing.

## Validation
- Standalone admin HTML inline JavaScript passed `node --check`.
- Full TypeScript/Vite build could not be verified because the project dependencies are not installed in this environment (`vite/client` type definitions missing).
