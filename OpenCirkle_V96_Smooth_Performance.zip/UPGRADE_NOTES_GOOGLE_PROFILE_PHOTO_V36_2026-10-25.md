# OpenCirkle v36 — Google Profile Photo Sync

## Changes
- Google Sign-In/Sign-Up now reads the photo URL from Firebase Auth's `photoURL` or Google provider data.
- New Google profiles save the photo URL to `users/{uid}.avatarUrl`.
- On subsequent Google sign-ins, the current Google profile photo URL is synced to the existing Firestore user profile when it changes.
- CrystalAvatar renders the user's photo URL when available, with the existing crystal avatar as the no-photo fallback.
- The profile photo is passed through key profile surfaces, header/navigation, profile cards, posts (including old posts via the live author listener), comments, stories, conversations created after this update, and notification payloads.
- Email/password accounts without a photo URL keep their existing crystal avatar.

## Deployment notes
- Deploy the updated web app after building the project.
- Google profile photos are read from Firebase Authentication/provider data; this does not upload photos to Firebase Storage.
- This environment could not complete dependency installation, so a full Vite build/type-check has not been verified here.
