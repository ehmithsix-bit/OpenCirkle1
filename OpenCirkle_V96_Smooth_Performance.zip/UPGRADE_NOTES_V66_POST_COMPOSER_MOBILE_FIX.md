# OpenCirkle v66 — Mobile Post Composer Viewport Fix

- The post composer modal now respects the dynamic viewport height and device safe-area insets.
- The modal content has its own vertical scrolling (`overflow-y-auto`, `overscroll-contain`) so the entire form is reachable on small screens.
- The close (X) button is enlarged for touch use and has an accessible label; Escape closes the modal on keyboard devices.
- The modal overlay itself can scroll, preventing long forms from being clipped on smaller phones.
- No post/user data or publishing logic was intentionally changed.

Validation: source-level changes only; run `npm run build` and test on a small Android viewport before release.
